# AI Agent Bootstrap Guide - Project Vana

**Version**: 1.0.0  
**Last Updated**: 2025-01-11  
**Target Audience**: AI Agents contributing to Vana codebase

---

## 🎯 Project Overview

### What is Vana?
**Vana** (Virtual Autonomous Network Agents) is a comprehensive multi-agent AI research platform that transforms complex research questions into professional-grade reports. Built on Google's Agent Development Kit (ADK), Vana orchestrates 8 specialized AI agents working collaboratively to deliver comprehensive research in minutes.

### Core Value Proposition
- **Enterprise-Grade Foundation**: Built on Google's ADK 1.8.0 for reliability and scalability
- **Multi-Agent Intelligence**: 8 specialized AI agents working in parallel
- **Real-time Streaming**: Live research progress via Server-Sent Events (SSE)
- **Production Ready**: 342+ comprehensive tests ensuring reliability
- **Flexible AI Models**: Primary OpenRouter/Qwen 3 Coder (free) with Gemini fallback

### Target Users
- Researchers needing comprehensive literature reviews
- Analysts requiring multi-source data synthesis
- Students working on academic projects
- Professionals needing market research and competitive analysis
- Developers building AI-powered research tools

---

## 🏗️ Technical Architecture

### Technology Stack
```
Frontend (🚧 REBUILDING): React + Vite + TypeScript + shadcn/ui
Backend (✅ FULLY FUNCTIONAL): FastAPI + Python 3.10+
AI Framework: Google ADK 1.8.0
AI Models: LiteLLM + OpenRouter (Primary), Google Gemini (Fallback)
Authentication: OAuth2/JWT + Firebase Auth
Database: SQLite (dev), PostgreSQL (prod)
Deployment: Google Cloud Run + Cloud Storage
Testing: pytest + 342+ comprehensive tests
```

### Architecture Patterns
1. **Multi-Agent Orchestration**: 8 specialized agents with defined roles
2. **Event-Driven**: Real-time updates via SSE broadcasting
3. **Session Persistence**: Backup/restore for Cloud Run deployments
4. **Security-First**: Multiple auth methods with role-based access
5. **Cloud-Native**: Full Google Cloud Platform integration

---

## 📁 Project Structure

### Root Directory (`/Users/nick/Development/vana/`)
```
vana/
├── app/                      # 🏠 Main FastAPI backend application
│   ├── server.py            # FastAPI server with ADK integration
│   ├── agent.py             # 8-agent research pipeline definitions
│   ├── models.py            # AI model configuration (OpenRouter/Gemini)
│   ├── config.py            # Application configuration
│   ├── enhanced_callbacks.py # Agent coordination callbacks
│   ├── auth/                # 🔐 OAuth2/JWT authentication system
│   ├── tools/               # 🛠️ Agent tools (Brave Search API)
│   └── utils/               # 🔧 Utilities (SSE, GCS, tracing, sessions)
├── tests/                   # 🧪 Comprehensive test suite (342+ tests)
│   ├── unit/               # Unit tests for components
│   ├── integration/        # API and agent integration tests
│   ├── performance/        # Memory leak and benchmark tests
│   └── utils/              # Test helper utilities
├── docs/                   # 📚 Documentation
│   ├── API.md             # Complete API reference
│   └── images/            # Architecture diagrams
├── deployment/             # 🚀 Terraform and Cloud Run config
├── scripts/               # 🔨 Setup and utility scripts
├── memory/               # 💾 Agent session storage
├── notebooks/           # 📓 Jupyter notebooks for ADK testing
├── .claude_workspace/   # 🤖 Claude-specific workspace
│   ├── planning/       # Active planning documents
│   ├── reports/        # Implementation reports
│   └── archive/        # Completed documentation
└── Configuration Files:
    ├── Makefile          # 🏗️ Build, test, and dev commands
    ├── pyproject.toml    # Python dependencies and tooling
    ├── README.md         # Project documentation
    ├── CONTRIBUTING.md   # Contribution guidelines
    └── .env.local       # Local development configuration
```

### Key Backend Modules (`/app/`)
```
app/
├── server.py                 # 🌐 FastAPI app with ADK integration
├── agent.py                 # 🤖 8-agent research pipeline
├── models.py                # 🧠 AI model configuration
├── config.py                # ⚙️ Research configuration
├── enhanced_callbacks.py    # 📡 Agent coordination & SSE broadcasting
├── auth/                    # 🔐 Complete authentication system
│   ├── config.py           # Auth settings and validation
│   ├── database.py         # SQLAlchemy models and initialization
│   ├── models.py           # User, Role, Permission models
│   ├── routes.py           # Authentication endpoints
│   ├── security.py         # JWT and password utilities
│   ├── middleware.py       # Security, rate limiting, audit logging
│   └── schemas.py          # Pydantic request/response models
├── tools/                   # 🛠️ Agent tools
│   └── brave_search.py     # Web search integration
└── utils/                   # 🔧 Core utilities
    ├── sse_broadcaster.py  # Real-time event streaming
    ├── session_backup.py   # Session persistence for Cloud Run
    ├── gcs.py              # Google Cloud Storage integration
    ├── tracing.py          # OpenTelemetry tracing
    └── agent_progress.py   # Agent progress tracking
```

---

## 🔑 Key Files to Inspect First

### Essential Backend Files (Priority Order)
1. **`/app/server.py`** - FastAPI application entry point with ADK integration
2. **`/app/agent.py`** - 8-agent research pipeline definitions and workflows
3. **`/app/models.py`** - AI model configuration (OpenRouter vs Gemini selection)
4. **`/app/config.py`** - Application configuration and settings
5. **`/app/auth/routes.py`** - OAuth2/JWT authentication endpoints
6. **`/app/utils/sse_broadcaster.py`** - Real-time event streaming system

### Configuration Files
1. **`/Makefile`** - Build, test, and development commands
2. **`/pyproject.toml`** - Python dependencies, linting, and tooling configuration
3. **`/.env.local`** - Local development environment variables (create from README)
4. **`/README.md`** - Comprehensive project documentation

### Documentation
1. **`/docs/API.md`** - Complete API reference with examples
2. **`/CONTRIBUTING.md`** - Development guidelines and contribution process
3. **`/CLAUDE.md`** - Claude Code development environment configuration

### Test Files (Understanding System Behavior)
1. **`/tests/integration/test_adk_integration.py`** - ADK agent tests
2. **`/tests/integration/test_sse_connections.py`** - Real-time streaming tests
3. **`/tests/unit/test_auth.py`** - Authentication system tests
4. **`/tests/performance/benchmark_sse_memory.py`** - Memory leak prevention

---

## ⚙️ Development Workflow

### Prerequisites
```bash
# Required tools
- Python 3.10+
- uv (Python package manager)
- Google Cloud SDK
- make
- git
```

### Initial Setup
```bash
# 1. Clone and enter directory
git clone https://github.com/NickB03/vana.git
cd vana

# 2. Install dependencies
make install

# 3. Google Cloud authentication
gcloud auth application-default login
gcloud config set project your-project-id

# 4. Create local environment file
cp .env.example .env.local
# Edit .env.local with required API keys
```

### Required Environment Variables (`.env.local`)
```bash
# Required API keys
BRAVE_API_KEY=your-brave-search-api-key
GOOGLE_CLOUD_PROJECT=your-project-id

# PRIMARY Model Provider (Recommended - FREE tier)
OPENROUTER_API_KEY=your-openrouter-key  # Enables free Qwen 3 Coder model

# Authentication (choose one)
JWT_SECRET_KEY=your-jwt-secret-key    # For JWT auth
# OR set AUTH_REQUIRED=false for development

# Optional: Force Gemini instead of OpenRouter
# USE_OPENROUTER=false  # Only if you want to use Gemini fallback

# CORS for local development
ALLOW_ORIGINS=http://localhost:5173,http://localhost:5174,http://localhost:3000
```

### Development Commands
```bash
# Backend development
make dev-backend          # Start FastAPI server (port 8000)
make playground          # Start ADK playground (port 8501)

# Frontend development (when available)
make dev-frontend        # Start React dev server (port 5173)
make dev                 # Start both backend and frontend

# Code quality
make test               # Run all tests (unit + integration)
make lint               # Code formatting and linting
make typecheck          # Type checking with mypy

# All quality checks
make test && make lint && make typecheck
```

### Development URLs
- **Backend API**: http://localhost:8000
- **Interactive API Docs**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health
- **Frontend** (when available): http://localhost:5173
- **ADK Playground**: http://localhost:8501

---

## 🤖 Core Components

### The 8-Agent Research Pipeline

#### Phase 1: Planning & Setup
1. **`plan_generator`** - Creates strategic research plans from user requests
2. **`section_planner`** - Breaks plans into structured markdown report sections

#### Phase 2: Research Execution
3. **`section_researcher`** - Executes comprehensive web research using Brave Search
4. **`research_evaluator`** - Quality assurance and gap analysis (uses critic model)
5. **`enhanced_search_executor`** - Refinement searches based on feedback

#### Phase 3: Quality & Composition
6. **`escalation_checker`** - Loop control agent that stops when research passes QA
7. **`report_composer`** - Synthesizes findings into professional reports with citations
8. **`interactive_planner_agent`** - Main orchestrator managing user interaction flow

### AI Model Configuration
```python
# Automatic model selection based on environment
if OPENROUTER_API_KEY and not USE_OPENROUTER_OVERRIDE:
    # PRIMARY: Free tier with excellent performance
    CRITIC_MODEL = LiteLlm(model="openrouter/qwen/qwen-3-coder:free")
    WORKER_MODEL = LiteLlm(model="openrouter/qwen/qwen-3-coder:free")
else:
    # FALLBACK: Google Gemini (requires GCP auth)
    CRITIC_MODEL = "gemini-2.5-pro"     # Planning, evaluation
    WORKER_MODEL = "gemini-2.5-flash"   # Research, content generation
```

### Authentication System
- **OAuth2/JWT Compliant**: Industry-standard token authentication
- **Multiple Auth Methods**: JWT, Firebase Auth, API keys, development mode
- **Role-Based Access Control**: Fine-grained permissions system
- **Security Middleware**: Rate limiting, audit logging, security headers

### Real-time Streaming (SSE)
- **Agent Progress**: Live updates on research progress
- **Event Types**: connection, agent_start, agent_complete, research_sources, heartbeat
- **Authentication**: Optional (configurable via `REQUIRE_SSE_AUTH`)
- **Memory Management**: Optimized for long-running connections without leaks

---

## 🔧 Configuration

### AI Model Priority System
1. **Check for OpenRouter API Key**: If `OPENROUTER_API_KEY` is set → Use Qwen 3 Coder (FREE)
2. **Explicit Override**: If `USE_OPENROUTER=false` → Force Gemini models
3. **Fallback**: No OpenRouter key → Use Gemini models (requires GCP auth)

### Session Storage Strategies
```python
# Production: Cloud Run with persistent volume
if os.getenv("CLOUD_RUN_SESSION_DB_PATH"):
    session_service_uri = setup_cloud_run_persistence()

# Custom database: Cloud SQL, etc.
elif os.getenv("SESSION_DB_URI"):
    session_service_uri = os.getenv("SESSION_DB_URI")

# Development: Local SQLite with GCS backup
else:
    session_service_uri = "sqlite:///tmp/vana_sessions.db"
    # Automatic backup to GCS every 6 hours
```

### Google Cloud Integration
- **Project**: `analystai-454200` (default)
- **Services**: Cloud Storage, Cloud Logging, Cloud Trace, Vertex AI
- **Buckets**: `{project-id}-vana-logs-data`, `{project-id}-vana-session-storage`
- **Authentication**: Application Default Credentials (ADC)

---

## 🧪 Testing Strategy

### Test Categories (342+ Total Tests)
```
tests/
├── unit/                    # Component isolation tests
│   ├── test_auth.py        # Authentication logic
│   ├── test_sse_broadcaster.py  # SSE implementation
│   └── test_enhanced_callbacks.py  # Agent callbacks
├── integration/             # Component interaction tests
│   ├── test_adk_integration.py     # ADK agent workflows
│   ├── test_api_endpoints.py       # FastAPI endpoints
│   ├── test_sse_connections.py     # Real-time streaming
│   └── test_session_management.py  # Session persistence
├── performance/            # Memory and speed tests
│   └── benchmark_sse_memory.py    # Memory leak prevention
└── utils/                  # Test helpers
    └── backend_test_helpers.py
```

### Test Execution
```bash
# Run all tests
make test

# Run specific test categories
uv run pytest tests/unit -v              # Unit tests only
uv run pytest tests/integration -v       # Integration tests only
uv run pytest tests/performance -v       # Performance tests only

# Run with coverage
uv run pytest --cov=app --cov-report=html tests/
```

### Mandatory Testing Before Completion
Every task MUST pass these tests before completion:
1. **Static Analysis**: `make lint` (ruff, mypy, codespell)
2. **Unit Tests**: `make test` 
3. **Runtime Smoke Tests**: Backend (port 8000) and Frontend (port 5173) health checks
4. **End-to-End Validation**: Playwright MCP tests for UI verification

---

## 📜 Code Conventions

### Python Code Style
- **PEP 8 Compliance**: Enforced by ruff
- **Type Hints**: Required for all function parameters and returns
- **Line Length**: 88 characters (ruff configuration)
- **Import Organization**: isort with first-party packages (app, frontend)

### Documentation Standards
- **Docstrings**: Google-style docstrings for all public functions/classes
- **Comments**: Clear comments for complex logic
- **API Documentation**: OpenAPI/Swagger via FastAPI automatic generation

### Testing Conventions
```python
# Example test structure
import pytest
from app.agent import ResearchAgent

class TestResearchAgent:
    @pytest.fixture
    def agent(self):
        return ResearchAgent()
    
    @pytest.mark.asyncio
    async def test_research_query(self, agent):
        """Test agent's research capability."""
        result = await agent.research("test query")
        assert result is not None
        assert "citations" in result
```

### Commit Message Format
```
type(scope): description

[optional body]

[optional footer]
```

Types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`

Example:
```
feat(agent): add data analysis capabilities

Implements new agent type for CSV/JSON processing with 
statistical analysis and visualization support.

Closes #123
```

---

## 📋 Important Context

### Current Development Status
- **Backend**: ✅ **FULLY FUNCTIONAL** - Production-ready FastAPI with 8-agent system
- **Frontend**: 🚧 **REBUILDING** (2025-08-09 to 2025-08-15) - Modern React + shadcn/ui
- **Deployment**: Local development only in this profile (no production deployments)

### Google ADK Integration
- **Version**: ADK 1.8.0
- **Pattern**: Follow ADK Starter Pack "Getting Started" guide exactly
- **ChromaDB Collections**: Query for official Google ADK documentation before implementation
  - `adk_documentation` - Official Google ADK docs
  - `adk_knowledge_base_v2` - ADK examples and best practices

### Memory Management
- **SSE Optimization**: Fixed memory leaks for long-running connections
- **Session Persistence**: Automatic backup/restore for Cloud Run deployments
- **Agent Coordination**: Efficient event broadcasting without memory accumulation

### Security Considerations
- **Environment Variables**: Never commit `.env.local` files (in `.gitignore`)
- **API Keys**: Store sensitive data in Google Secret Manager for production
- **Authentication**: Multiple methods supported with OAuth2 compliance
- **Rate Limiting**: Configured per endpoint with appropriate limits

---

## 🚀 Quick Start for AI Agents

### 1. Immediate Actions
```bash
# Enter project directory (critical for correct CWD)
cd /Users/nick/Development/vana

# Check current status
make health-check || echo "Run make install first"

# Review recent changes
git log --oneline -5

# Check environment
cat .env.local 2>/dev/null || echo "Create .env.local from README"
```

### 2. Understanding the System
```bash
# Read key files in order
cat app/server.py | head -50      # FastAPI setup
cat app/agent.py | head -100      # Agent pipeline
cat app/models.py                 # AI model config
cat Makefile                      # Available commands
```

### 3. Running Tests
```bash
# Essential test commands
make test           # Full test suite
make lint           # Code quality
make typecheck      # Type checking

# Development server
make dev-backend    # Start backend (port 8000)
```

### 4. Making Changes
```bash
# Create feature branch
git checkout -b feature/your-change

# Make changes, then validate
make test && make lint && make typecheck

# Commit with conventional format
git commit -m "feat(component): description"
```

---

## 🛠️ Troubleshooting

### Common Issues

#### 1. Authentication Errors
```bash
# Fix Google Cloud auth
gcloud auth application-default login
gcloud config set project analystai-454200
```

#### 2. Missing Dependencies
```bash
# Reinstall dependencies
make install
```

#### 3. Model Configuration Issues
Check logs for model selection:
```bash
make dev-backend
# Look for:
# ✅ PRIMARY: Using OpenRouter with Qwen 3 Coder model (FREE tier)
# ⚠️ FALLBACK: Using Gemini models (OpenRouter API key not configured)
```

#### 4. Test Failures
```bash
# Run specific test categories
uv run pytest tests/unit -v -x          # Stop on first failure
uv run pytest tests/integration -v -k "test_auth"  # Run auth tests only
```

#### 5. SSE Connection Issues
- Check `REQUIRE_SSE_AUTH` setting in environment
- Verify JWT token validity for authenticated connections
- Monitor memory usage with performance tests

---

## 📚 Additional Resources

### Documentation
- [Google ADK Documentation](https://cloud.google.com/products/ai)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [LiteLLM Documentation](https://docs.litellm.ai/)

### Project Resources
- **GitHub Repository**: https://github.com/NickB03/vana
- **Issues**: https://github.com/NickB03/vana/issues
- **API Documentation**: http://localhost:8000/docs (when running locally)

### Development Tools
- **uv Package Manager**: https://docs.astral.sh/uv/
- **Google Cloud SDK**: https://cloud.google.com/sdk/docs/install
- **OpenRouter**: https://openrouter.ai/ (for free Qwen 3 Coder access)

---

**Remember**: Always launch Claude Code from `/Users/nick/Development/vana/` to ensure correct working directory for all operations. The project follows a multi-agent architecture with real-time streaming, comprehensive testing, and production-ready deployment patterns.

**Next Steps**: Review the key files listed above, run the test suite to understand system behavior, and consult the ChromaDB collections for official Google ADK patterns before implementing new features.