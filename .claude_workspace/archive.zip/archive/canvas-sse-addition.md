perfect—let’s make the Canvas **SSE-first** and show exactly how it plugs into a Google ADK (Gemini) streaming agent. I’ll give you:

* SSE hub (server) with **per-user channels**, **event IDs**, **heartbeats**, and **replay**
* Stream endpoint the browser connects to
* Updated Canvas provider (no UI change) + **ActionStream** client with **robust reconnect** and **debounced patching**
* ADK runner: how to consume **tool/function calls** from Gemini and publish Canvas actions over SSE
* Clear notes on auth, scale, and production swaps (Redis etc.)

You can paste these blocks into a Next.js **App Router** project.

---

# 1) Types (unchanged, plus a “log” event type)

`/types/canvas.ts`

```ts
import { z } from "zod";

export type ArtifactType = "markdown" | "site" | "code" | "diagram" | "svg";

export type VFile = { path: string; content: string; language?: string };
export type VFS = Record<string, VFile>;

export type SiteManifest = {
  type: "site";
  entry: string;
  files: VFS;
  requires?: ("bundler" | "npm" | "node" | "ssr" | "server-bundle")[];
  title?: string;
};

export type MarkdownDoc = { type: "markdown"; content: string; title?: string };
export type CodeArtifact = { type: "code"; files: VFS; entry?: string; title?: string };

export type CanvasArtifact =
  | SiteManifest
  | MarkdownDoc
  | CodeArtifact
  | { type: "diagram" | "svg"; content: string; title?: string };

export type ToolId = "sandbox" | "markdown" | "code" | "diff" | "formatter";

export const OpenCanvasAction = z.object({
  type: z.literal("open_canvas"),
  tool: z.custom<ToolId>(),
  title: z.string().optional(),
  payload: z.any(),
  selection: z
    .object({ start: z.number().int().nonnegative(), end: z.number().int().nonnegative() })
    .optional(),
});

export const UpdateCanvasAction = z.object({
  type: z.literal("update_canvas"),
  payloadPatch: z.any(),
});

export const CreateVersionAction = z.object({
  type: z.literal("create_version"),
  note: z.string().optional(),
});

export type OpenCanvasActionT = z.infer<typeof OpenCanvasAction>;
export type UpdateCanvasActionT = z.infer<typeof UpdateCanvasAction>;
export type CreateVersionActionT = z.infer<typeof CreateVersionAction>;

export type CanvasAction = OpenCanvasActionT | UpdateCanvasActionT | CreateVersionActionT;

// Optional: SSE “log” events to surface tool/model logs in the Canvas sidebar.
export type CanvasLog = { level?: "info" | "warn" | "error"; message: string; ts?: number };
```

---

# 2) Server-Side SSE Hub (per-user channels, IDs, replay, heartbeat)

> In dev, this uses in-memory maps. In prod, swap the storage with Redis Pub/Sub or Cloud Run + Redis.

`/lib/sse-hub.ts`

```ts
import { CanvasAction, CanvasLog } from "@/types/canvas";

/** Envelope we put on the wire (SSE “data: …”). */
export type SSEEnvelope =
  | { kind: "action"; id: string; data: CanvasAction }
  | { kind: "log";    id: string; data: CanvasLog }
  | { kind: "ping";   id: string; data?: {} };

type Client = {
  controller: ReadableStreamDefaultController<string>;
  lastId?: string | null;
};

type Channel = {
  // last N events for replay (lightweight ring buffer)
  backlog: SSEEnvelope[];
  clients: Set<Client>;
  nextSeq: number;
};

const channels = new Map<string, Channel>();
const BACKLOG_SIZE = 200;
const HEARTBEAT_MS = 15000;

function getChannel(userId: string): Channel {
  let ch = channels.get(userId);
  if (!ch) {
    ch = { backlog: [], clients: new Set(), nextSeq: 1 };
    channels.set(userId, ch);
  }
  return ch;
}

function asLine(env: SSEEnvelope) {
  // SSE lines; include event id for reconnection replay.
  return `id: ${env.id}\nevent: ${env.kind}\ndata: ${JSON.stringify(env)}\n\n`;
}

function pushBacklog(ch: Channel, env: SSEEnvelope) {
  ch.backlog.push(env);
  if (ch.backlog.length > BACKLOG_SIZE) ch.backlog.shift();
}

export function publishAction(userId: string, action: CanvasAction) {
  const ch = getChannel(userId);
  const env: SSEEnvelope = { kind: "action", id: String(ch.nextSeq++), data: action };
  pushBacklog(ch, env);
  for (const c of ch.clients) c.controller.enqueue(asLine(env));
}

export function publishLog(userId: string, log: CanvasLog) {
  const ch = getChannel(userId);
  const env: SSEEnvelope = { kind: "log", id: String(ch.nextSeq++), data: { ts: Date.now(), ...log } };
  pushBacklog(ch, env);
  for (const c of ch.clients) c.controller.enqueue(asLine(env));
}

export function subscribe(userId: string, controller: ReadableStreamDefaultController<string>, lastEventId?: string | null) {
  const ch = getChannel(userId);
  const client: Client = { controller, lastId: lastEventId ?? null };
  ch.clients.add(client);

  // If client sent Last-Event-ID, replay missed events
  if (lastEventId) {
    const last = Number(lastEventId);
    for (const env of ch.backlog) {
      if (Number(env.id) > last) controller.enqueue(asLine(env));
    }
  }

  // Heartbeats
  const timer = setInterval(() => {
    const ping: SSEEnvelope = { kind: "ping", id: String(ch.nextSeq++), data: {} };
    pushBacklog(ch, ping);
    controller.enqueue(asLine(ping));
  }, HEARTBEAT_MS);

  return () => {
    clearInterval(timer);
    ch.clients.delete(client);
  };
}
```

---

# 3) SSE Stream Route (browser connects here)

`/app/api/canvas/stream/route.ts`

```ts
import { NextRequest } from "next/server";
import { subscribe } from "@/lib/sse-hub";

// Example auth extractor. Replace with your session/token logic.
function getUserId(req: NextRequest): string {
  // Prefer your session cookie or Authorization header
  return req.headers.get("x-user-id") ?? "anon";
}

export async function GET(req: NextRequest) {
  const userId = getUserId(req);
  const lastEventId = req.headers.get("last-event-id"); // browsers auto-send if server sets `id:`
  const stream = new ReadableStream<string>({
    start(controller) {
      const unsubscribe = subscribe(userId, controller, lastEventId);

      // Initial headers note:
      // The connection remains open; we don't call `controller.close()` here.
      // Unsubscribe on teardown:
      (controller as any)._cleanup = unsubscribe;
    },
    cancel(reason) {
      const cleanup = (this as any)._cleanup as (() => void) | undefined;
      if (cleanup) cleanup();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      // Allow proxies/CDNs to keep it open
      "X-Accel-Buffering": "no",
    },
  });
}
```

> **Production tip:** put the user ID in the SSE URL (e.g., `/api/canvas/stream?uid=…`) or sign it; terminate at the same region as your ADK runner to reduce latency.

---

# 4) Client: robust SSE listener with reconnect + debounced patches

`/components/agent/ActionStream.tsx`

```tsx
"use client";

import { useEffect, useRef } from "react";
import { useCanvas } from "@/components/canvas/CanvasProvider";
import type { CanvasAction } from "@/types/canvas";
import { OpenCanvasAction, UpdateCanvasAction, CreateVersionAction } from "@/types/canvas";

type Envelope = { kind: "action" | "log" | "ping"; id: string; data: any };

export function ActionStream({ userId }: { userId?: string }) {
  const { dispatchAction, appendLog } = useCanvas();
  const backoffRef = useRef(1000);
  const abortRef = useRef<AbortController | null>(null);
  const patchQueue = useRef<any[]>([]);
  const patchTimer = useRef<any>(null);

  useEffect(() => {
    let closed = false;

    const connect = () => {
      if (closed) return;
      const ctrl = new AbortController();
      abortRef.current = ctrl;

      const url = "/api/canvas/stream"; // you can append ?uid=...
      const es = new EventSource(url, { withCredentials: true });

      es.onopen = () => {
        backoffRef.current = 1000; // reset backoff
      };

      es.onmessage = (ev) => {
        // default "message" event if server doesn't set `event:`
        handlePayload(ev.data);
      };

      es.addEventListener("action", (ev) => handlePayload((ev as MessageEvent).data));
      es.addEventListener("log", (ev) => handlePayload((ev as MessageEvent).data));
      es.addEventListener("ping", () => { /* ignore */ });

      es.onerror = () => {
        es.close();
        if (!closed) {
          const wait = Math.min(backoffRef.current, 15000);
          setTimeout(connect, wait);
          backoffRef.current *= 2;
        }
      };

      function handlePayload(raw: string) {
        try {
          const env = JSON.parse(raw) as Envelope;
          if (env.kind === "log") {
            appendLog(env.data);
            return;
          }
          if (env.kind !== "action") return;

          const obj = env.data as CanvasAction;
          // zod validate (optional but recommended)
          if (obj.type === "open_canvas") OpenCanvasAction.parse(obj);
          if (obj.type === "update_canvas") {
            UpdateCanvasAction.parse(obj);
            // batch patches to reduce thrash
            patchQueue.current.push(obj);
            if (!patchTimer.current) {
              patchTimer.current = setTimeout(flushPatches, 150); // debounce
            }
            return;
          }
          if (obj.type === "create_version") CreateVersionAction.parse(obj);

          dispatchAction(obj);
        } catch (e) {
          console.error("SSE action parse error", e);
        }
      }

      function flushPatches() {
        const merged = mergePatches(patchQueue.current);
        patchQueue.current = [];
        patchTimer.current = null;
        dispatchAction({ type: "update_canvas", payloadPatch: merged } as any);
      }
    };

    connect();
    return () => {
      closed = true;
      abortRef.current?.abort();
    };
  }, [dispatchAction, appendLog]);

  return null;
}

// Deep merge multiple update_canvas patches into one patch
function mergePatches(list: Array<{ type: "update_canvas"; payloadPatch: any }>) {
  const out = {};
  for (const p of list) deepMerge(out, p.payloadPatch);
  return out;
}

function deepMerge(target: any, src: any) {
  if (typeof src !== "object" || src === null) return src;
  for (const [k, v] of Object.entries(src)) {
    if (v && typeof v === "object" && !Array.isArray(v)) {
      target[k] ??= {};
      deepMerge(target[k], v);
    } else {
      target[k] = v;
    }
  }
  return target;
}
```

> Drop `<ActionStream />` once on your chat page. It listens for **CanvasAction** events and applies them, with debounced `update_canvas` merges so Sandpack/preview doesn’t thrash.

---

# 5) Canvas Provider updates (logs + dispatch unchanged)

Just add a simple log buffer and an `appendLog` method the stream can call.

`/components/canvas/CanvasProvider.tsx` (only the changed bits shown)

```tsx
// ...imports unchanged...
type CanvasState = {
  open: boolean;
  tool?: ToolId;
  title?: string;
  payload?: any;
  versions: Array<{ id: string; note?: string; snapshot: any; createdAt: number }>;
  logs: Array<{ level?: "info"|"warn"|"error"; message: string; ts: number }>;
};

type CanvasCtx = {
  state: CanvasState;
  openCanvas: (opts: { tool: ToolId; title?: string; payload: any }) => void;
  updateCanvas: (payloadPatch: any) => void;
  createVersion: (note?: string) => void;
  closeCanvas: () => void;
  dispatchAction: (action: CanvasAction) => void;
  appendLog: (log: { level?: "info"|"warn"|"error"; message: string; ts?: number }) => void;
};

export function CanvasProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<CanvasState>({
    open: false,
    versions: [],
    logs: [],
  });

  const openCanvas = useCallback(({ tool, title, payload }) => {
    setState({ open: true, tool, title, payload, versions: [], logs: [] });
  }, []);

  const updateCanvas = useCallback((patch) => {
    setState((s) => ({ ...s, payload: deepMerge(s.payload, patch) }));
  }, []);

  const createVersion = useCallback((note?: string) => {
    setState((s) => ({
      ...s,
      versions: [...s.versions, { id: nanoid(), note, snapshot: structuredClone(s.payload), createdAt: Date.now() }],
    }));
  }, []);

  const appendLog = useCallback((log) => {
    setState((s) => ({ ...s, logs: [...s.logs, { ts: Date.now(), ...log }] }));
  }, []);

  const closeCanvas = useCallback(() => setState({ open: false, versions: [], logs: [] }), []);

  const dispatchAction = useCallback((action: CanvasAction) => {
    if (action.type === "open_canvas") openCanvas(action);
    else if (action.type === "update_canvas") updateCanvas(action.payloadPatch);
    else if (action.type === "create_version") createVersion(action.note);
  }, [openCanvas, updateCanvas, createVersion]);

  const value = useMemo(() => ({
    state, openCanvas, updateCanvas, createVersion, closeCanvas, dispatchAction, appendLog
  }), [state, openCanvas, updateCanvas, createVersion, closeCanvas, appendLog]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <CanvasSheet />
    </Ctx.Provider>
  );
}

// In Sidebar() replace "Tool logs" with rendering:
function Sidebar() {
  const { state, createVersion } = useCanvas();
  // ... other tabs unchanged
  // Logs tab:
  // <TabsContent value="logs" ...>
  //   <ScrollArea className="h-full p-3">
  //     <ul className="space-y-1 text-xs">
  //       {state.logs.map((l, i) => (<li key={i} className="font-mono">{new Date(l.ts).toLocaleTimeString()} — {l.message}</li>))}
  //     </ul>
  //   </ScrollArea>
  // </TabsContent>
}
```

---

# 6) ADK (Gemini) → SSE bridge

You have two good patterns. Most ADK wrappers support **function/tool calls** + **streaming**. We’ll listen for those and publish to SSE.

## 6.1 Declare Canvas tools in your Gemini agent (function calling)

> Pseudocode—adapt names to your specific Google ADK wrapper.

`/adk/canvas-tools.ts`

```ts
export const canvasFunctionDeclarations = [
  {
    name: "open_canvas",
    description: "Open slide-out Canvas with a tool & payload.",
    parameters: {
      type: "object",
      properties: {
        tool: { type: "string", enum: ["sandbox", "markdown", "code", "diff", "formatter"] },
        title: { type: "string" },
        payload: { type: "object" },
        selection: {
          type: "object",
          properties: { start: { type: "number" }, end: { type: "number" } },
        },
      },
      required: ["tool", "payload"],
    },
  },
  {
    name: "update_canvas",
    description: "Patch current Canvas payload (deep merge).",
    parameters: {
      type: "object",
      properties: { payloadPatch: { type: "object" } },
      required: ["payloadPatch"],
    },
  },
  {
    name: "create_version",
    description: "Create a named snapshot of current artifact.",
    parameters: {
      type: "object",
      properties: { note: { type: "string" } },
    },
  },
];
```

## 6.2 Run loop: consume ADK stream and publish to SSE

`/adk/run-agent.ts` (skeleton with clear hook points)

```ts
import type { CanvasAction } from "@/types/canvas";
import { publishAction, publishLog } from "@/lib/sse-hub";
import { canvasFunctionDeclarations } from "./canvas-tools";

// Replace with your actual ADK client (Vertex/Gemini)
// import { GoogleGenerativeAI } from "@google/generative-ai"; // example

type RunParams = {
  userId: string;
  messages: Array<{ role: "user"|"assistant"|"system"; content: string }>;
};

export async function runAgentWithCanvas({ userId, messages }: RunParams) {
  // 1) Create model with tools enabled (pseudo)
  // const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
  // const model = genAI.getGenerativeModel({ model: "models/gemini-2.0", tools: { functionDeclarations: canvasFunctionDeclarations }});

  // 2) Start a streaming call (pseudo)
  // const stream = await model.generateContentStream({ contents: toGeminiContents(messages) });

  // 3) Iterate streamed chunks:
  for await (const chunk of adkStream(messages)) {
    if (chunk.type === "tool-call") {
      const { name, args } = chunk; // args is JSON
      if (name === "open_canvas" || name === "update_canvas" || name === "create_version") {
        publishAction(userId, { type: name, ...args } as CanvasAction);
        // Optionally send a tool result back to Gemini to continue reasoning
        // await model.submitToolOutputs([...]);
      }
      continue;
    }

    // Optional: forward textual logs
    if (chunk.type === "text") publishLog(userId, { message: chunk.text });
    if (chunk.type === "error") publishLog(userId, { level: "error", message: String(chunk.error) });
  }
}

/** Demo generator to illustrate expected shapes. Replace with your real ADK stream. */
async function* adkStream(_messages: any[]) {
  // open canvas
  yield {
    type: "tool-call",
    name: "open_canvas",
    args: {
      tool: "sandbox",
      title: "Landing Prototype",
      payload: {
        type: "site",
        entry: "/index.html",
        files: {
          "/index.html": { path: "/index.html", content: "<h1>Hello</h1>" },
          "/style.css": { path: "/style.css", content: "body{font:14px system-ui}" },
        },
        requires: [],
      },
    },
  };
  await new Promise((r) => setTimeout(r, 800));
  yield { type: "tool-call", name: "update_canvas", args: { payloadPatch: { files: { "/index.html": { content: "<h1>Hello, world!</h1>" } } } } };
  await new Promise((r) => setTimeout(r, 500));
  yield { type: "tool-call", name: "create_version", args: { note: "First draft" } };
}
```

> **Where do I call `runAgentWithCanvas`?** In your “send message” action on the server (e.g., `/app/api/chat/send/route.ts`). The ADK stream loops and **publishes SSE events** to the user’s channel; the browser is already connected and will update the Canvas in real time.

---

# 7) Putting it together (client)

* Mount the **CanvasProvider** in `app/layout.tsx` (you already have it).
* Render `<ActionStream />` **once** in your chat page so the UI reacts to SSE:

`/app/(chat)/page.tsx`

```tsx
import { ActionStream } from "@/components/agent/ActionStream";

export default function ChatPage() {
  return (
    <>
      {/* your chat UI */}
      <ActionStream />
    </>
  );
}
```

When your chat form posts, your server calls `runAgentWithCanvas(...)`. As the ADK emits tool calls, your SSE hub publishes **`CanvasAction`** events; the browser **receives, debounces**, and **dispatches** them to the Canvas.

---

# 8) Notes (so you don’t get bit later)

* **Auth:** replace `getUserId()` with real session lookup; include a signed user ID in `x-user-id` or query param.
* **Scale:** in-memory hub is fine for local/dev. In prod, use **Redis**:

  * Publisher: `PUBLISH canvas:<userId> {json}`
  * Stream route: `SUBSCRIBE canvas:<userId>` and replay from a Redis stream or KV for `Last-Event-ID`.
* **CORS/proxies:** set `X-Accel-Buffering: no` (already done) to keep SSE live behind Nginx/Cloudflare.
* **Backpressure:** we keep a small backlog (200). Adjust per needs.
* **Debounce patches:** already implemented (150ms). Adjust for Sandpack/WebContainers.
* **Event IDs:** we send `id:` on every event, browsers will include `Last-Event-ID` on reconnect automatically.

---

## TL;DR

* The **Canvas Tool Registry stays the same**.
* We added a solid **SSE pipeline**: server hub → `/api/canvas/stream` → client `ActionStream`.
* Your **Google ADK** runner simply **publishes Canvas tool calls** as `CanvasAction` SSE messages (`open_canvas`, `update_canvas`, `create_version`).
* The browser handles reconnects, debounces patches, and updates the Canvas instantly.

If you want, I can swap the ADK pseudo with concrete code for the exact Google SDK you’re using (Node/Go/Python), but this wiring stays identical either way.
