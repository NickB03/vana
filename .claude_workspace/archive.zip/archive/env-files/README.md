# Archived Environment Files

**Date Archived:** 2025-08-09

## Files Archived

### 1. `.env.openrouter`
- **Status:** Not referenced anywhere in codebase
- **Contents:** OpenRouter API key and Brave API key (same as backups)
- **Reason for archive:** Redundant, functionality now in `.env.local`

### 2. `.env.backup`
- **Status:** Backup of old `.env` file
- **Contents:** Same as current `.env.local`
- **Reason for archive:** Outdated backup, no longer needed

### 3. `.env.backup.save`
- **Status:** Another backup of old `.env` file
- **Contents:** Identical to `.env.backup`
- **Reason for archive:** Duplicate backup, no longer needed

## Security Notes

All archived files contain:
- OpenRouter API keys (multiple versions)
- Brave Search API key (exposed in source code - needs rotation)

These files are kept in the archive for reference but should not be used. The active configuration is now in `.env.local` files.

## Current Configuration

Active environment files:
- `/Users/nick/Development/vana/.env.local` - Root directory config
- `/Users/nick/Development/vana/app/.env.local` - App directory config

Both are loaded via `uv run --env-file .env.local` in the Makefile.