# Vana Development Environment Scripts

This directory contains scripts to manage the Vana development environment, especially useful after system sleep or crashes.

## 🚀 Quick Start

```bash
# Start all services
./start-vana.sh

# Check status
./status-vana.sh

# Stop all services
./stop-vana.sh

# Stop and clean logs
./stop-vana.sh --clean
```

## Scripts Overview

### `start-vana.sh`
Starts both frontend and backend services with automatic:
- Port conflict detection and cleanup
- Health checks with retries
- Virtual environment activation
- Missing dependencies installation
- Process tracking via PID files

### `stop-vana.sh`
Gracefully stops all services:
- Sends SIGTERM first, then SIGKILL if needed
- Cleans up PID files
- Optional log cleanup with `--clean` flag

### `status-vana.sh`
Shows detailed status of all services:
- Port usage and process information
- Health check results
- Detects orphaned processes
- Shows URLs for accessing services

## Common Issues and Solutions

### After System Sleep
When your Mac goes to sleep, the frontend (Vite) often stops while the backend (Python) survives:
```bash
./start-vana.sh  # Will detect and restart only what's needed
```

### Port Already in Use
The scripts automatically detect and handle port conflicts:
- If a service is healthy, it won't be restarted
- If unhealthy or not responding, it will be killed and restarted

### Can't Connect to Server
This is the most common issue. Just run:
```bash
./start-vana.sh
```

### Check What's Running
```bash
./status-vana.sh
```

## Service URLs
- Frontend: http://localhost:5173
- Backend API: http://localhost:8000
- API Documentation: http://localhost:8000/docs

## Logs
- Backend: `/Users/nick/Development/vana/backend.log`
- Frontend: `/Users/nick/Development/vana/frontend/frontend.log`

## Tips
- The scripts are idempotent - safe to run multiple times
- Services are started with auto-reload for development
- Backend uses SQLite for session storage (survives restarts)
- All scripts show colored output for easy reading