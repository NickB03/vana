# Comprehensive Test Plan Execution Guide

## Overview

This document provides a complete guide for executing the comprehensive test suite created for the Vana codebase. The test suite covers all critical integration points including API endpoints, WebSocket/SSE connections, ADK service integration, session management, frontend-backend communication, and error handling.

## Test Structure

### Backend Tests (Python/pytest)
```
tests/
├── integration/
│   ├── test_api_endpoints.py          # FastAPI endpoint testing
│   ├── test_sse_connections.py        # SSE/WebSocket testing
│   ├── test_adk_integration.py        # ADK service integration
│   ├── test_session_management.py     # Session lifecycle testing
│   └── test_error_handling.py         # Error scenarios & edge cases
├── unit/
│   ├── test_enhanced_callbacks.py     # Existing unit tests
│   └── test_sse_broadcaster.py        # Existing unit tests
└── utils/
    └── backend_test_helpers.py        # Comprehensive test utilities
```

### Frontend Tests (TypeScript/Vitest)
```
frontend/src/test/
├── integration/
│   ├── frontend-backend-communication.test.tsx  # E2E communication
│   └── context-service-integration.test.tsx     # Existing integration
├── utils/
│   ├── comprehensive-test-helpers.ts             # Complete test utilities
│   ├── render-helpers.tsx                        # Existing helpers
│   └── mock-services.ts                          # Existing mocks
└── suites/
    ├── adk-integration.test.ts                   # Existing ADK tests
    └── authentication.test.ts                    # Existing auth tests
```

## Test Categories

### 1. API Endpoint Tests (`test_api_endpoints.py`)

**Coverage:**
- Health check endpoint validation
- Feedback collection endpoint
- Agent network SSE endpoint initialization
- ADK integration endpoint testing
- CORS configuration validation
- Session creation through ADK endpoints

**Key Features:**
- Request/response validation
- Timeout handling
- Concurrent request testing
- Performance benchmarks
- Malformed data handling

### 2. SSE Connection Tests (`test_sse_connections.py`)

**Coverage:**
- Event broadcasting functionality
- Streaming lifecycle management
- Multiple session isolation
- Event history management
- Concurrent event broadcasting
- Connection timeout handling
- Memory management under load

**Key Features:**
- Real-time event processing
- High-frequency event streams
- Burst event handling
- Connection recovery testing
- Performance under load

### 3. ADK Integration Tests (`test_adk_integration.py`)

**Coverage:**
- ADK agent creation and initialization
- Configuration management
- Message transformation and formatting
- Real-time integration scenarios
- Concurrent ADK requests
- Session persistence across requests
- Error recovery mechanisms

**Key Features:**
- ADK-specific message formats
- Streaming performance characteristics
- Multi-part message handling
- Metadata preservation

### 4. Session Management Tests (`test_session_management.py`)

**Coverage:**
- Session persistence and backup functionality
- Cloud Run session persistence setup
- Complete session lifecycle management
- Session storage mechanisms and performance
- Session security and data protection
- Concurrent session operations

**Key Features:**
- GCS backup/restore testing
- SQLite and memory storage performance
- Session data sanitization
- Access control validation
- Boundary value testing

### 5. Frontend-Backend Communication Tests (`frontend-backend-communication.test.tsx`)

**Coverage:**
- Session creation through backend API
- SSE connection establishment and management
- Message sending via SSE
- Real-time event processing
- Error handling and recovery
- Performance and load testing

**Key Features:**
- Mock EventSource implementation
- Complete message flow testing
- Connection lifecycle management
- Data consistency validation
- Memory usage monitoring

### 6. Error Handling Tests (`test_error_handling.py`)

**Coverage:**
- Network error conditions (timeouts, connection failures)
- SSE error scenarios (connection drops, malformed events)
- Data validation errors (injection attacks, oversized requests)
- Edge cases and boundary conditions
- System limits and resource exhaustion

**Key Features:**
- Comprehensive error simulation
- Security attack prevention testing
- Resource limit validation
- Concurrent access testing
- Performance under stress

## Execution Instructions

### Prerequisites

1. **Backend Dependencies:**
```bash
cd /Users/nick/Development/vana
pip install pytest pytest-asyncio pytest-cov requests psutil
```

2. **Frontend Dependencies:**
```bash
cd /Users/nick/Development/vana/frontend
npm install --save-dev @testing-library/jest-dom @testing-library/user-event
```

### Running Backend Tests

#### Full Test Suite
```bash
# Run all backend tests
pytest tests/ -v

# Run with coverage
pytest tests/ -v --cov=app --cov-report=html --cov-report=term

# Run specific test categories
pytest tests/integration/ -v
pytest tests/unit/ -v
```

#### Individual Test Files
```bash
# API endpoint tests
pytest tests/integration/test_api_endpoints.py -v

# SSE connection tests  
pytest tests/integration/test_sse_connections.py -v

# ADK integration tests
pytest tests/integration/test_adk_integration.py -v

# Session management tests
pytest tests/integration/test_session_management.py -v

# Error handling tests
pytest tests/integration/test_error_handling.py -v
```

#### Performance Testing
```bash
# Run with performance markers
pytest tests/integration/ -v -m "performance"

# Run load tests
pytest tests/integration/test_api_endpoints.py::TestPerformanceAndLimits -v
```

### Running Frontend Tests

#### Full Test Suite
```bash
cd frontend

# Run all tests
npm run test

# Run with coverage
npm run test:coverage

# Run with UI
npm run test:ui
```

#### Integration Tests
```bash
# Frontend-backend communication
npm run test -- frontend-backend-communication.test.tsx

# Context-service integration
npm run test -- context-service-integration.test.tsx
```

#### Specific Test Categories
```bash
# ADK integration
npm run test -- adk-integration.test.ts

# Authentication
npm run test -- authentication.test.ts

# Service layer tests
npm run test -- src/services/__tests__/
```

### Running Complete Integration Tests

#### End-to-End Testing
```bash
# Start backend server
cd /Users/nick/Development/vana
python -m uvicorn app.server:app --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!

# Start frontend dev server
cd frontend
npm run dev &
FRONTEND_PID=$!

# Wait for services to start
sleep 5

# Run integration tests
pytest tests/integration/test_server_e2e.py -v

# Run frontend E2E tests
npm run test -- integration/

# Cleanup
kill $BACKEND_PID $FRONTEND_PID
```

## Test Configuration Files

### Backend Configuration (`pytest.ini`)
```ini
[tool:pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = 
    -v 
    --tb=short
    --strict-markers
    --disable-warnings
markers =
    integration: Integration tests
    unit: Unit tests  
    performance: Performance tests
    slow: Slow running tests
asyncio_mode = auto
```

### Frontend Configuration (`vitest.config.ts`)
```typescript
import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html', 'lcov'],
      exclude: [
        'node_modules/',
        'src/test/',
        '**/*.d.ts',
        'vite.config.ts'
      ]
    }
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  }
})
```

## Coverage Requirements

### Backend Coverage Targets
- **Overall Coverage:** 80% minimum
- **Integration Tests:** 70% minimum  
- **Critical Paths:** 95% minimum
- **Error Handling:** 90% minimum

### Frontend Coverage Targets
- **Overall Coverage:** 80% minimum
- **Service Layer:** 90% minimum
- **Context Providers:** 85% minimum
- **Critical Components:** 95% minimum

## Performance Benchmarks

### Backend Performance Targets
- **Health endpoint:** < 100ms response time
- **Feedback endpoint:** < 500ms response time
- **SSE connection:** < 1s establishment time
- **Concurrent requests:** 50+ simultaneous connections
- **Memory usage:** < 200MB increase under load

### Frontend Performance Targets
- **Initial render:** < 100ms
- **Context initialization:** < 50ms
- **SSE connection:** < 500ms
- **Message processing:** < 100ms latency
- **Memory usage:** < 10MB/hour growth

## Debugging Test Failures

### Backend Debugging
```bash
# Run with detailed output
pytest tests/ -v -s --tb=long

# Run specific failing test
pytest tests/integration/test_api_endpoints.py::TestAPIEndpoints::test_health_check_endpoint -v -s

# Debug with pdb
pytest tests/ --pdb

# Run with logging
pytest tests/ -v --log-cli-level=DEBUG
```

### Frontend Debugging
```bash
# Run with debug output
npm run test -- --reporter=verbose

# Run single test file
npm run test -- src/test/integration/frontend-backend-communication.test.tsx

# Debug mode
npm run test:debug
```

## Continuous Integration

### GitHub Actions Configuration
```yaml
name: Test Suite
on: [push, pull_request]

jobs:
  backend-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      - run: pip install -r requirements.txt
      - run: pytest tests/ --cov=app --cov-report=xml
      - uses: codecov/codecov-action@v3

  frontend-tests:
    runs-on: ubuntu-latest  
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: cd frontend && npm ci
      - run: cd frontend && npm run test:coverage
      - uses: codecov/codecov-action@v3
```

## Test Maintenance

### Regular Maintenance Tasks
1. **Weekly:** Review test performance and flaky tests
2. **Monthly:** Update test data and mock services
3. **Quarterly:** Review coverage gaps and add missing tests
4. **After major changes:** Update integration tests and benchmarks

### Test Data Management
- Use factories for consistent test data generation
- Implement proper cleanup for temporary files and databases
- Mock external services to ensure test isolation
- Rotate test credentials and sensitive data

## Troubleshooting Common Issues

### Backend Issues
- **Import errors:** Check Python path and virtual environment
- **Database errors:** Ensure test database cleanup
- **Port conflicts:** Use different ports for parallel test runs
- **Timeout errors:** Increase timeout values for slow CI environments

### Frontend Issues
- **Mock failures:** Update mock implementations when APIs change
- **Async test issues:** Use proper async/await patterns
- **Memory leaks:** Implement proper cleanup in test teardown
- **Browser compatibility:** Test across different environments

## Success Metrics

### Test Quality Indicators
- **Test coverage:** Above minimum thresholds
- **Test execution time:** Under 5 minutes for full suite
- **Flaky test rate:** Below 2%
- **False positive rate:** Below 1%

### Integration Success
- **API compatibility:** All endpoints properly tested
- **Real-time communication:** SSE flows validated
- **Error resilience:** Failure scenarios covered
- **Performance compliance:** Benchmarks met consistently

---

This comprehensive test plan provides complete coverage of the Vana codebase's critical integration points. Execute tests regularly to maintain code quality and catch issues early in the development process.