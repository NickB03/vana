awesome—here’s the **copy-paste code pack** to stand up the slide-out Canvas and make it LLM-drivable. I’m giving you:

* install commands
* types & action schema the agent will use
* Canvas provider + shell (right slide-out)
* Tool registry and “Open in Canvas” hook/button
* Engines: **Iframe** (default), **Sandpack** (optional)
* Tools: **Sandbox**, **Markdown**, **Code**, **Diff**, **Formatter**
* SSE stream wiring so your agent can `open_canvas`, `update_canvas`, `create_version` in real time

> All files are TypeScript/React for **Next.js (App Router)** using **shadcn/ui** primitives.

---

# 0) Install

```bash
# shadcn primitives you’ll use (run via shadcn CLI if you haven’t copied them yet)
# sheet, resizable, tabs, scroll-area, button, separator, menubar, tooltip, textarea
# https://ui.shadcn.com
# Example:
# npx shadcn@latest add sheet resizable tabs scroll-area button separator menubar tooltip textarea

# editors / engines
npm i @codesandbox/sandpack-react monaco-editor @monaco-editor/react
npm i react-markdown remark-gfm
npm i codemirror @codemirror/lang-markdown @codemirror/language-data
npm i prettier prettier-plugin-markdown
npm i zod nanoid
```

---

# 1) Types & LLM Action Schema

`/types/canvas.ts`

```ts
import { z } from "zod";

export type ArtifactType = "markdown" | "site" | "code" | "diagram" | "svg";

export type VFile = { path: string; content: string; language?: string };
export type VFS = Record<string, VFile>; // key: absolute path like "/index.html"

export type SiteManifest = {
  type: "site";
  entry: string;                // "/index.html"
  files: VFS;
  requires?: ("bundler" | "npm" | "node" | "ssr" | "server-bundle")[];
  title?: string;
};

export type MarkdownDoc = { type: "markdown"; content: string; title?: string };

export type CodeArtifact = { type: "code"; files: VFS; entry?: string; title?: string };

export type CanvasArtifact = SiteManifest | MarkdownDoc | CodeArtifact | {
  type: "diagram" | "svg";
  content: string;
  title?: string;
};

export type ArtifactVersion = {
  id: string;            // nanoid
  createdAt: number;     // epoch ms
  note?: string;
  artifact: CanvasArtifact;
};

export type ToolId = "sandbox" | "markdown" | "code" | "diff" | "formatter";

export const OpenCanvasAction = z.object({
  type: z.literal("open_canvas"),
  tool: z.custom<ToolId>(),
  title: z.string().optional(),
  payload: z.any(), // validated inside tools
  selection: z
    .object({ start: z.number().int().nonnegative(), end: z.number().int().nonnegative() })
    .optional(),
});

export const UpdateCanvasAction = z.object({
  type: z.literal("update_canvas"),
  payloadPatch: z.any(), // shallow/deep merges inside tools
});

export const CreateVersionAction = z.object({
  type: z.literal("create_version"),
  note: z.string().optional(),
});

export type OpenCanvasActionT = z.infer<typeof OpenCanvasAction>;
export type UpdateCanvasActionT = z.infer<typeof UpdateCanvasAction>;
export type CreateVersionActionT = z.infer<typeof CreateVersionAction>;

export type CanvasAction = OpenCanvasActionT | UpdateCanvasActionT | CreateVersionActionT;
```

**Agent contract (what the LLM emits):**

* `open_canvas` → open slide-out with `{tool, payload}`
* `update_canvas` → patch current tool’s payload (streamed or batched)
* `create_version` → freeze current artifact as a restorable version

---

# 2) Canvas Provider, API, and Shell

`/components/canvas/CanvasProvider.tsx`

```tsx
"use client";

import { createContext, useCallback, useContext, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import type { CanvasAction, ToolId } from "@/types/canvas";
import { nanoid } from "nanoid";

// UI primitives
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

// ---------- Canvas Context ----------

type CanvasState = {
  open: boolean;
  tool?: ToolId;
  title?: string;
  payload?: any;
  // Basic versioning for active artifact (per tool instance)
  versions: Array<{ id: string; note?: string; snapshot: any; createdAt: number }>;
};

type CanvasCtx = {
  state: CanvasState;
  openCanvas: (opts: { tool: ToolId; title?: string; payload: any }) => void;
  updateCanvas: (payloadPatch: any) => void;
  createVersion: (note?: string) => void;
  closeCanvas: () => void;
  dispatchAction: (action: CanvasAction) => void; // <-- LLM entry point
};

const Ctx = createContext<CanvasCtx | null>(null);
export const useCanvas = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCanvas must be used within <CanvasProvider/>");
  return ctx;
};

// Lazy Tool Registry
const ToolSandbox  = dynamic(() => import("./tools/SandboxTool"),  { ssr: false });
const ToolMarkdown = dynamic(() => import("./tools/MarkdownTool"), { ssr: false });
const ToolCode     = dynamic(() => import("./tools/CodeTool"),     { ssr: false });
const ToolDiff     = dynamic(() => import("./tools/DiffTool"),     { ssr: false });
const ToolFormatter= dynamic(() => import("./tools/FormatterTool"),{ ssr: false });

const REGISTRY: Record<ToolId, React.ComponentType<{ payload: any }>> = {
  sandbox: ToolSandbox,
  markdown: ToolMarkdown,
  code: ToolCode,
  diff: ToolDiff,
  formatter: ToolFormatter,
};

export function CanvasProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<CanvasState>({ open: false, versions: [] });

  const openCanvas: CanvasCtx["openCanvas"] = useCallback(({ tool, title, payload }) => {
    setState({ open: true, tool, title, payload, versions: [] });
  }, []);

  const updateCanvas: CanvasCtx["updateCanvas"] = useCallback((patch) => {
    setState((s) => ({ ...s, payload: deepMerge(s.payload, patch) }));
  }, []);

  const createVersion: CanvasCtx["createVersion"] = useCallback((note) => {
    setState((s) => ({
      ...s,
      versions: [...s.versions, { id: nanoid(), note, snapshot: structuredClone(s.payload), createdAt: Date.now() }],
    }));
  }, []);

  const closeCanvas = useCallback(() => setState({ open: false, versions: [] }), []);

  const dispatchAction: CanvasCtx["dispatchAction"] = useCallback((action) => {
    if (action.type === "open_canvas") openCanvas(action);
    else if (action.type === "update_canvas") updateCanvas(action.payloadPatch);
    else if (action.type === "create_version") createVersion(action.note);
  }, [openCanvas, updateCanvas, createVersion]);

  const value = useMemo<CanvasCtx>(() => ({
    state, openCanvas, updateCanvas, createVersion, closeCanvas, dispatchAction
  }), [state, openCanvas, updateCanvas, createVersion, closeCanvas]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <CanvasSheet />
    </Ctx.Provider>
  );
}

// ---------- Shell (right slide-out) ----------

function CanvasSheet() {
  const { state, closeCanvas } = useCanvas();
  const Tool = state.tool ? REGISTRY[state.tool] : null;

  return (
    <Sheet open={state.open} onOpenChange={(o) => (!o ? closeCanvas() : null)}>
      <SheetContent side="right" className="w-[min(960px,100vw)] p-0">
        <SheetHeader className="border-b px-4 py-3">
          <SheetTitle className="text-base">{state.title ?? "Canvas"}</SheetTitle>
        </SheetHeader>

        <ResizablePanelGroup direction="horizontal" className="h-[calc(100vh-3.25rem)]">
          <ResizablePanel defaultSize={34} minSize={20}>
            <Sidebar />
          </ResizablePanel>

          <ResizableHandle withHandle />

          <ResizablePanel defaultSize={66} minSize={30}>
            <div className="h-full">
              {Tool ? <Tool payload={state.payload} /> : <EmptyState />}
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </SheetContent>
    </Sheet>
  );
}

function Sidebar() {
  const { state, createVersion } = useCanvas();

  return (
    <Tabs defaultValue="activity" className="h-full">
      <div className="flex items-center justify-between px-3 py-2">
        <TabsList>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="assets">Assets</TabsTrigger>
          <TabsTrigger value="versions">Versions</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
        </TabsList>
      </div>
      <Separator />
      <TabsContent value="activity" className="h-[calc(100%-3rem)] m-0">
        <ScrollArea className="h-full p-3">
          <p className="text-sm text-muted-foreground">Agent steps / comments will appear here.</p>
        </ScrollArea>
      </TabsContent>
      <TabsContent value="assets" className="h-[calc(100%-3rem)] m-0">
        <ScrollArea className="h-full p-3">Files / images / attachments</ScrollArea>
      </TabsContent>
      <TabsContent value="versions" className="h-[calc(100%-3rem)] m-0">
        <ScrollArea className="h-full p-3">
          {state.versions.length === 0 ? (
            <p className="text-sm text-muted-foreground">No versions yet.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {state.versions.map(v => (
                <li key={v.id} className="rounded border p-2">
                  <div className="font-medium">{new Date(v.createdAt).toLocaleString()}</div>
                  <div className="text-muted-foreground">{v.note ?? "—"}</div>
                </li>
              ))}
            </ul>
          )}
          <div className="pt-3">
            <button className="text-xs underline" onClick={() => createVersion("Snapshot")}>Create version</button>
          </div>
        </ScrollArea>
      </TabsContent>
      <TabsContent value="logs" className="h-[calc(100%-3rem)] m-0">
        <ScrollArea className="h-full p-3">Tool logs</ScrollArea>
      </TabsContent>
    </Tabs>
  );
}

function EmptyState() {
  return (
    <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
      Nothing selected yet.
    </div>
  );
}

// simple deep merge for patches
function deepMerge<T>(base: T, patch: Partial<T>): T {
  if (Array.isArray(base) || Array.isArray(patch)) return patch as T;
  if (typeof base !== "object" || base === null) return patch as T;
  const out: any = { ...base };
  for (const [k, v] of Object.entries(patch as any)) {
    out[k] = typeof v === "object" && v != null && typeof (base as any)[k] === "object"
      ? deepMerge((base as any)[k], v)
      : v;
  }
  return out;
}
```

**What the agent needs to know:** it can send `CanvasAction` JSON to the client; the client calls `dispatchAction(action)` (see §4) to open/patch/version the Canvas.

Mount the provider once:

`/app/layout.tsx`

```tsx
import type { Metadata } from "next";
import "./globals.css";
import { CanvasProvider } from "@/components/canvas/CanvasProvider";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <CanvasProvider>{children}</CanvasProvider>
      </body>
    </html>
  );
}
```

---

# 3) Tool Registry & “Open in Canvas” helpers

`/components/canvas/OpenInCanvas.tsx`

```tsx
"use client";
import { Button } from "@/components/ui/button";
import { useCanvas } from "./CanvasProvider";
import type { ToolId } from "@/types/canvas";

export function OpenInCanvasButton({ tool, title, payload }:{
  tool: ToolId; title?: string; payload: any;
}) {
  const { openCanvas } = useCanvas();
  return (
    <Button size="sm" variant="secondary" onClick={() => openCanvas({ tool, title, payload })}>
      Open in Canvas
    </Button>
  );
}
```

Use it next to any assistant artifact in the chat.

---

# 4) Streaming actions from your agent (SSE)

**Server:** `/app/api/agent/stream/route.ts`

```ts
import { NextRequest } from "next/server";

// This is just a stub that emits a demo open_canvas and a patch.
// Replace with your real agent loop, streaming CanvasAction JSON strings.

export async function GET(_req: NextRequest) {
  const stream = new ReadableStream({
    start(controller) {
      const send = (obj: unknown) => controller.enqueue(`data: ${JSON.stringify(obj)}\n\n`);
      // Open Canvas with a tiny site
      send({
        type: "open_canvas",
        tool: "sandbox",
        title: "One-shot Preview",
        payload: {
          type: "site",
          entry: "/index.html",
          files: {
            "/index.html": { path: "/index.html", content: "<h1>Hello Canvas</h1>" },
            "/style.css": { path: "/style.css", content: "body{font:14px system-ui;padding:2rem}" },
            "/script.js": { path: "/script.js", content: "console.log('hi')" },
          },
          requires: [],
        },
      });

      // Patch after 2s
      setTimeout(() => send({
        type: "update_canvas",
        payloadPatch: { files: { "/index.html": { content: "<h1>Hello from Agent</h1>" } } },
      }), 2000);

      // Close
      setTimeout(() => controller.close(), 4000);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
```

**Client listener:** `/components/agent/ActionStream.tsx`

```tsx
"use client";
import { useEffect } from "react";
import { useCanvas } from "@/components/canvas/CanvasProvider";
import type { CanvasAction } from "@/types/canvas";
import { OpenCanvasAction, UpdateCanvasAction, CreateVersionAction } from "@/types/canvas";

export function ActionStream() {
  const { dispatchAction } = useCanvas();

  useEffect(() => {
    const es = new EventSource("/api/agent/stream");
    es.onmessage = (e) => {
      try {
        const obj = JSON.parse(e.data) as CanvasAction;
        // optional schema guard (zod)
        if (obj.type === "open_canvas") OpenCanvasAction.parse(obj);
        if (obj.type === "update_canvas") UpdateCanvasAction.parse(obj);
        if (obj.type === "create_version") CreateVersionAction.parse(obj);
        dispatchAction(obj);
      } catch (err) {
        console.error("invalid action", err);
      }
    };
    return () => es.close();
  }, [dispatchAction]);

  return null;
}
```

Mount `<ActionStream />` once (e.g., in your chat page).

---

# 5) Tools

## 5.1 Sandbox Tool (engine switcher: Iframe default → Sandpack on demand)

`/components/canvas/tools/SandboxTool.tsx`

```tsx
"use client";

import { useMemo } from "react";
import type { SiteManifest, VFS } from "@/types/canvas";

// Engines
import { IframeEngine } from "./engines/IframeEngine";
const SandpackEngine = typeof window !== "undefined"
  ? require("./engines/SandpackEngine").SandpackEngine
  : undefined;

export default function SandboxTool({ payload }: { payload: SiteManifest }) {
  const manifest: SiteManifest = useMemo(() => payload, [payload]);
  const needsBundler = (manifest.requires ?? []).some(r => r === "bundler" || r === "npm");

  if (needsBundler && SandpackEngine) {
    const files = mapToSandpackFiles(manifest.files);
    return <SandpackEngine files={files} entry={manifest.entry} />;
  }

  return <IframeEngine files={manifest.files} entry={manifest.entry} />;
}

function mapToSandpackFiles(vfs: VFS) {
  const out: Record<string, { content: string }> = {};
  for (const [p, f] of Object.entries(vfs)) out[p] = { content: f.content };
  return out;
}
```

### 5.1.a Iframe engine (fastest “one-shot” path)

`/components/canvas/tools/engines/IframeEngine.tsx`

```tsx
"use client";
import { useEffect, useMemo, useRef } from "react";
import type { VFS } from "@/types/canvas";

export function IframeEngine({ files, entry = "/index.html" }:{ files: VFS; entry?: string }) {
  const urlRef = useRef<string | null>(null);

  const html = useMemo(() => {
    const index = files[entry]?.content ?? "<h1>Missing index.html</h1>";
    const css   = files["/style.css"]?.content ?? "";
    const js    = files["/script.js"]?.content ?? "";
    // Tight CSP; extend if your agent needs external CDNs
    return `<!doctype html><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy"
 content="default-src 'none'; img-src data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; frame-ancestors 'none'">
<style>${css}</style>${index}<script>${js}<\/script>`;
  }, [files, entry]);

  const src = useMemo(() => URL.createObjectURL(new Blob([html], { type: "text/html" })), [html]);

  useEffect(() => {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    urlRef.current = src;
    return () => { if (urlRef.current) URL.revokeObjectURL(urlRef.current); };
  }, [src]);

  return (
    <iframe
      src={src}
      className="h-full w-full bg-white"
      sandbox="allow-scripts allow-forms allow-pointer-lock allow-downloads"
      referrerPolicy="no-referrer"
    />
  );
}
```

### 5.1.b Sandpack engine (when JSX/TSX bundling is needed)

`/components/canvas/tools/engines/SandpackEngine.tsx`

```tsx
"use client";
import {
  SandpackProvider,
  SandpackLayout,
  SandpackCodeEditor,
  SandpackPreview,
  SandpackConsole
} from "@codesandbox/sandpack-react";

export function SandpackEngine({ files, entry = "/index.html" }:{
  files: Record<string, { content: string }>;
  entry?: string;
}) {
  return (
    <SandpackProvider template="vanilla" files={files} options={{ activeFile: entry }}>
      <SandpackLayout>
        <SandpackCodeEditor />
        <SandpackPreview />
        <SandpackConsole />
      </SandpackLayout>
    </SandpackProvider>
  );
}
```

> If you prefer **Kibo Sandbox**, swap this file for its component; the rest of the Canvas stays the same.

---

## 5.2 Markdown Tool (CodeMirror + preview)

`/components/canvas/tools/MarkdownTool.tsx`

```tsx
"use client";
import { useEffect, useRef, useState } from "react";
import { basicSetup, EditorView } from "codemirror";
import { markdown, markdownLanguage } from "@codemirror/lang-markdown";
import { languages } from "@codemirror/language-data";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function MarkdownTool({ payload }: { payload: { type: "markdown"; content: string } }) {
  const [doc, setDoc] = useState<string>(payload?.content ?? "# Untitled");
  const host = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!host.current) return;
    const view = new EditorView({
      doc,
      extensions: [
        basicSetup,
        markdown({ base: markdownLanguage, codeLanguages: languages }),
        EditorView.updateListener.of((u) => { if (u.docChanged) setDoc(u.state.doc.toString()); }),
      ],
      parent: host.current,
    });
    return () => view.destroy();
  }, []); // mount once

  useEffect(() => { /* sync from agent patches */ setDoc(payload?.content ?? doc); }, [payload?.content]);

  return (
    <Tabs defaultValue="edit" className="h-full">
      <div className="flex items-center justify-between px-3 py-2">
        <TabsList>
          <TabsTrigger value="edit">Edit</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
        </TabsList>
      </div>
      <TabsContent value="edit" className="h-[calc(100%-3rem)] m-0">
        <div ref={host} className="h-full" />
      </TabsContent>
      <TabsContent value="preview" className="h-[calc(100%-3rem)] m-0 overflow-auto p-4">
        <ReactMarkdown remarkPlugins={[remarkGfm]} className="prose prose-invert">
          {doc}
        </ReactMarkdown>
      </TabsContent>
    </Tabs>
  );
}
```

---

## 5.3 Code Tool (Monaco)

`/components/canvas/tools/CodeTool.tsx`

```tsx
"use client";
import { useState } from "react";
import Editor from "@monaco-editor/react";
import type { VFS } from "@/types/canvas";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function CodeTool({ payload }: { payload: { type: "code"; files: VFS; entry?: string } }) {
  const [active, setActive] = useState<string>(payload.entry ?? Object.keys(payload.files)[0]);
  const [files, setFiles] = useState<VFS>(payload.files);

  return (
    <div className="h-full flex">
      <div className="w-56 border-r">
        <ScrollArea className="h-full">
          <ul className="p-2 text-sm">
            {Object.keys(files).sort().map((p) => (
              <li key={p}>
                <button className={`w-full text-left rounded px-2 py-1 hover:bg-muted ${active===p?"bg-muted":""}`} onClick={() => setActive(p)}>
                  {p}
                </button>
              </li>
            ))}
          </ul>
        </ScrollArea>
      </div>
      <div className="flex-1">
        <Tabs defaultValue="code" className="h-full">
          <div className="flex items-center justify-between px-3 py-2">
            <TabsList>
              <TabsTrigger value="code">Code</TabsTrigger>
              <TabsTrigger value="preview" disabled>Preview</TabsTrigger>
            </TabsList>
          </div>
          <TabsContent value="code" className="h-[calc(100%-3rem)] m-0">
            <Editor
              height="100%"
              defaultLanguage={files[active]?.language ?? guessLang(active)}
              value={files[active]?.content ?? ""}
              onChange={(v) => {
                setFiles((prev) => ({ ...prev, [active]: { ...(prev[active]||{path:active}), content: v ?? "" } }));
              }}
              options={{ minimap: { enabled: false }, fontSize: 13 }}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function guessLang(p: string) {
  if (p.endsWith(".ts") || p.endsWith(".tsx")) return "typescript";
  if (p.endsWith(".js") || p.endsWith(".jsx")) return "javascript";
  if (p.endsWith(".css")) return "css";
  if (p.endsWith(".md")) return "markdown";
  if (p.endsWith(".json")) return "json";
  if (p.endsWith(".html")) return "html";
  return "plaintext";
}
```

---

## 5.4 Diff Tool (Monaco Diff Editor)

`/components/canvas/tools/DiffTool.tsx`

```tsx
"use client";
import { DiffEditor } from "@monaco-editor/react";

export default function DiffTool({ payload }:{
  payload: { original: string; modified: string; language?: string }
}) {
  return (
    <DiffEditor
      height="100%"
      language={payload.language ?? "markdown"}
      original={payload.original}
      modified={payload.modified}
      options={{ renderSideBySide: true, readOnly: false }}
    />
  );
}
```

---

## 5.5 Formatter Tool (Prettier in-browser)

`/components/canvas/tools/FormatterTool.tsx`

```tsx
"use client";
import { useState } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

// Prettier standalone (no Node runtime)
import prettier from "prettier/standalone";
import markdownPlugin from "prettier/plugins/markdown";
import babelPlugin from "prettier/plugins/babel";

export default function FormatterTool({ payload }: { payload: { content: string; language?: "markdown" | "javascript" } }) {
  const [text, setText] = useState(payload.content ?? "");

  const format = async () => {
    const isMd = (payload.language ?? "markdown") === "markdown";
    const plugins = isMd ? [markdownPlugin] : [babelPlugin];
    const parser = isMd ? "markdown" : "babel";
    const out = await prettier.format(text, { parser, plugins });
    setText(out);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="border-b p-2">
        <Button size="sm" onClick={format}>Format</Button>
      </div>
      <div className="flex-1 p-2">
        <Textarea className="h-full" value={text} onChange={(e) => setText(e.target.value)} />
      </div>
    </div>
  );
}
```

---

# 6) Using it from Chat (LLM → Canvas)

**In your chat component**, render the stream listener:

```tsx
// app/(chat)/page.tsx
import { ActionStream } from "@/components/agent/ActionStream";

export default function ChatPage() {
  return (
    <>
      {/* ... your chat UI ... */}
      <ActionStream />
    </>
  );
}
```

**Example: showing “Open in Canvas” next to an assistant artifact**

```tsx
import { OpenInCanvasButton } from "@/components/canvas/OpenInCanvas";

function AssistantCardSite({ html, css, js }:{
  html: string; css: string; js: string;
}) {
  const payload = {
    type: "site",
    entry: "/index.html",
    files: {
      "/index.html": { path: "/index.html", content: html },
      "/style.css":  { path: "/style.css",  content: css },
      "/script.js":  { path: "/script.js",  content: js },
    },
    requires: [], // set ["bundler"] when using JSX/TSX
  };
  return <OpenInCanvasButton tool="sandbox" title="Preview site" payload={payload} />;
}
```

---

# 7) What the AI Agent must do (cheat-sheet)

1. **Detect** when the user is writing/coding → emit `open_canvas`.

   * tool `"markdown"` with `{ type:"markdown", content }`
   * tool `"sandbox"` with `{ type:"site", entry, files, requires? }`
   * tool `"code"` with `{ type:"code", files, entry? }`
2. **Stream updates** as `update_canvas` patches (e.g., modify `files["/index.html"].content`).
3. **Checkpoint** with `create_version` after big changes.
4. **Respect selection** (if provided). You can include `{selection:{start,end}}` in `open_canvas` or subsequent updates to scope edits.

**Sample agent actions (JSON)**

```json
{"type":"open_canvas","tool":"markdown","title":"Intro Doc","payload":{"type":"markdown","content":"# Hello"}} 
{"type":"update_canvas","payloadPatch":{"content":"# Hello\n\nThis is updated."}}
{"type":"create_version","note":"Polished intro"}
{"type":"open_canvas","tool":"sandbox","title":"Landing Page","payload":{"type":"site","entry":"/index.html","files":{"/index.html":{"path":"/index.html","content":"<h1>Hi</h1>"}},"requires":[]}}
{"type":"update_canvas","payloadPatch":{"files":{"/style.css":{"path":"/style.css","content":"body{font:14px system-ui}"}}}}
```

---

# 8) Optional: Server bundling route (esbuild) for heavier projects

If you outgrow Sandpack for some cases, add a route that returns a built artifact URL for the Iframe engine.

`/app/api/bundle/route.ts` (skeleton)

```ts
import { NextRequest } from "next/server";
// import * as esbuild from "esbuild"; // if bundling server-side

export async function POST(req: NextRequest) {
  const manifest = await req.json(); // { files: Record<string,{content:string}>, entry: "/index.html" }
  // 1) run esbuild here (or in a background job)
  // 2) upload to object storage, return signed URL for iframe
  return Response.json({ url: "https://your-cdn/preview/abc123.html" });
}
```

---

## That’s it

* The **Canvas shell** slides out on the right and hosts tools.
* The **Tool registry** lets you add/remove tools freely.
* The **Sandbox tool** supports **Iframe** (default) and **Sandpack** (optional) engines.
* The **ActionStream** turns LLM JSON messages into Canvas operations.
* You’ve got **Markdown**, **Code**, **Diff**, and **Formatter** tools ready to go.

If you want, I can add: selection-aware “shortcuts” (Shorten, Fix Bug) that call your agent with exact ranges, ZIP export for site assets, and a tiny “Assets” file tree synced with the Sandbox.
