  🚨 Gaps That Need Backend Team Input:

  1. API Endpoint Specifications

  // Need exact URLs and payloads for:
  POST /api/sessions - Create session endpoint
  GET /api/chat/stream - SSE streaming endpoint
  POST /api/canvas/save - Canvas persistence
  POST /api/files/upload - File processing
  GET /api/sessions - List sessions
  DELETE /api/sessions/:id - Delete session
  PATCH /api/sessions/:id - Update session

  2. SSE Event Protocol

  // Need exact event names and payload structures:
  - message_token: { ? }
  - canvas_open: { ? }
  - task_update: { ? }
  - error: { ? }
  - agent_switch: { ? }

  3. ADK Agent Tool Registration

  // How are these Canvas tools registered in the backend?
  - open_canvas(type, content)
  - update_canvas(content)
  - create_version(data)

  4. File Upload Processing

  // Backend file handling:
  - Where are files stored?
  - What processing happens server-side?
  - What's returned after upload?
  - File size/type validation rules?

  5. Authentication Integration

  // Firebase or custom JWT?
  - Token validation endpoint?
  - User profile endpoint?
  - Session association with user?

  6. Multi-Agent Orchestration Data

  // Agent task structure:
  - How are agents identified?
  - Task dependency format?
  - Progress tracking protocol?

  7. Session Persistence

  // Backend session storage:
  - How are sessions stored?
  - Message pagination?
  - Canvas state persistence?

  8. Error Response Format

  // Standard error structure:
  - Error codes?
  - Error messages?
  - Retry information?
