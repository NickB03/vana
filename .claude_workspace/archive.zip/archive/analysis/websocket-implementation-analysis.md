# WebSocket Implementation Analysis - Vana Frontend

## Executive Summary

The Vana frontend has a custom WebSocket implementation that expects real-time updates from the backend. However, the current backend (based on ADK's FastAPI template) does not implement WebSocket endpoints. This analysis documents the expected WebSocket behavior to maintain UI/UX consistency when migrating to SSE.

## WebSocket Architecture

### 1. Service Layer (`/frontend/src/services/websocket.ts`)

**Connection Management:**
- Uses Socket.io client library
- Connects to backend at `/ws` path
- Supports both WebSocket and polling transports
- Auto-reconnection with 5 attempts, 1-second delay
- Singleton pattern for global access

**Event Types:**
```typescript
interface ThinkingUpdate {
  stepId: string
  agent: string
  action: string
  status: 'pending' | 'active' | 'complete'
  duration?: string  // In milliseconds when complete
}

interface MessageUpdate {
  messageId: string
  content: string
  isComplete: boolean
}
```

**Key Events:**
- `connect` → emits `connected: true`
- `disconnect` → emits `connected: false`
- `thinking_update` → Agent activity updates
- `message_update` → Streaming message content
- `error` → Connection errors
- `user_message` → Outbound user messages

### 2. React Hook (`/frontend/src/hooks/useWebSocket.ts`)

**Provides:**
- `isConnected`: Boolean connection status
- `error`: Connection error state
- `sendMessage(message: string)`: Send user messages
- `onThinkingUpdate(callback)`: Subscribe to agent activity
- `onMessageUpdate(callback)`: Subscribe to message streaming

**Lifecycle:**
- Auto-connects on component mount
- Cleans up listeners on unmount
- Returns unsubscribe functions for event listeners

### 3. ChatInterface Component

**WebSocket Integration:**
- Displays connection status (yellow warning when disconnected)
- Falls back to props-based handlers when WebSocket unavailable
- Manages message streaming and thinking step updates

**Message Flow:**
1. User sends message → creates placeholder AI message
2. Assigns `currentMessageIdRef` to track active streaming
3. Updates message content as `message_update` events arrive
4. Marks complete when `isComplete: true` received
5. Clears `isTyping` state and `currentMessageIdRef`

**Thinking Steps Management:**
- Maintains local state for thinking steps
- Updates existing steps by `stepId`
- Adds new steps if not found
- Associates steps with current message being streamed

### 4. ThinkingPanel Component

**Display Features:**
- Fixed right sidebar with expand/collapse
- Shows active/completed step counts
- Animated transitions using Framer Motion
- Empty state with instructions
- Real-time updates via AIReasoning component

**Visual States:**
- Expanded: 384px wide panel with full details
- Collapsed: Small tab showing active count
- Smooth spring animations on state changes

### 5. UI Components

**AIReasoning Component:**
- Displays thinking steps with status icons
- Animated list with staggered entry animations
- Status indicators: pending (clock), active (spinner), complete (check)
- Shows agent name, action, duration, and details
- Emoji mapping for different action types

**Timeline Component:**
- Used in AIMessage for collapsed thinking steps
- Vertical timeline with connected dots
- Animated drawing of connection lines
- Color-coded status indicators

**AIMessage Component:**
- User messages: Right-aligned bubbles
- Assistant messages: Left-aligned, no bubble (Gemini style)
- Collapsible "Show Agent activity" section
- Integrates Timeline for thinking steps
- Loading states during streaming

## Critical Behaviors to Preserve

### 1. **Message Streaming**
- Content updates character by character or in chunks
- Message marked as "sending" during stream
- Status changes to "sent" when complete
- Only one message streams at a time

### 2. **Thinking Step Updates**
- Steps can be added dynamically
- Existing steps update status: pending → active → complete
- Duration added when step completes
- Steps associated with specific messages

### 3. **Connection Handling**
- Visual indicator when disconnected
- Automatic reconnection attempts
- Graceful fallback to non-WebSocket mode
- No data loss during reconnections

### 4. **UI Animations**
- Smooth transitions for all state changes
- Staggered animations for list items
- Spring physics for panel movements
- Fade and slide effects for messages

### 5. **State Management**
- Local thinking steps sync with WebSocket updates
- Message history persists across reconnections
- Current streaming message tracked globally
- Error states properly displayed

## Migration Considerations for SSE

### 1. **Event Format Compatibility**
SSE events must match WebSocket format exactly:
```typescript
// Thinking Update Event
data: {
  "type": "thinking_update",
  "stepId": "unique-id",
  "agent": "Agent Name",
  "action": "Performing action...",
  "status": "active",
  "duration": "1234"  // Only when complete
}

// Message Update Event
data: {
  "type": "message_update",
  "messageId": "msg-id",
  "content": "Accumulated content...",
  "isComplete": false
}
```

### 2. **Connection State**
- SSE auto-reconnects by default (good!)
- Need to emit connection state changes
- Handle reconnection gracefully

### 3. **Message Ordering**
- Preserve order of thinking steps
- Ensure message chunks arrive in sequence
- Complete messages before starting new ones

### 4. **Performance**
- Current WebSocket uses binary frames
- SSE is text-only, may need optimization
- Consider chunking strategies for large responses

### 5. **Error Handling**
- Match current error event format
- Preserve retry logic
- Maintain fallback behavior

## Recommendations

1. **Create SSE Adapter**: Build a service that mimics WebSocket API but uses SSE internally
2. **Preserve Event Names**: Keep exact same event types and data structures
3. **Test Animations**: Ensure all transitions work smoothly with SSE timing
4. **Monitor Performance**: Watch for any latency differences in real-time updates
5. **Gradual Migration**: Consider feature flag to toggle between WebSocket and SSE

## Current Gaps

**Backend Implementation Missing:**
- No WebSocket server implementation found
- Backend uses standard ADK FastAPI setup
- Frontend expects WebSocket but backend doesn't provide it
- This suggests the WebSocket feature is either:
  - Not yet implemented in backend
  - Implemented in a different service
  - Part of a planned future feature

**Next Steps:**
1. Implement SSE endpoints in backend
2. Create adapter layer in frontend
3. Maintain exact event formats
4. Test thoroughly with real agent workflows