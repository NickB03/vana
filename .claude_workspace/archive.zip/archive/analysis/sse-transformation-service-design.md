# SSE Event Transformation Service Design

**Date**: 2025-07-28  
**Phase**: Backend Team - Service Architecture Design  
**Status**: Complete  

## Overview

Based on the ADK SSE analysis, this document outlines the design for the `ADKEventTransformationService` that will process ADK events into frontend-compatible format while maintaining reliability and observability.

## Architecture Principles

### 1. Minimal Transformation
- **Pass-through Design**: ADK events are already compatible with frontend
- **Enrich, Don't Replace**: Add metadata and reliability without changing core structure
- **Preserve Semantics**: Maintain all ADK event information for debugging

### 2. Reliability First
- **Error Recovery**: Handle malformed events gracefully
- **State Consistency**: Ensure session state remains coherent
- **Monitoring**: Track event processing performance and errors

### 3. ADK Compliance
- **Follow ADK Patterns**: Use established ADK service patterns
- **Integration Ready**: Compatible with ADK session management
- **Future-Proof**: Extensible for ADK updates

## Service Architecture

### Core Service Structure

```python
# app/services/sse_transformation.py
from typing import Optional, List, Dict, Any, AsyncGenerator
from dataclasses import dataclass
from google.adk.events import Event
from google.adk.agents.invocation_context import InvocationContext
import logging
import time

@dataclass
class ProcessedEvent:
    """Frontend-compatible event format"""
    title: str
    data: Dict[str, Any]
    timestamp: Optional[float] = None
    agent: Optional[str] = None
    session_id: Optional[str] = None

@dataclass
class TransformationMetrics:
    """Service performance metrics"""
    events_processed: int = 0
    errors_encountered: int = 0
    avg_processing_time: float = 0.0
    last_error: Optional[str] = None

class ADKEventTransformationService:
    """
    Transforms ADK events into frontend-compatible format with reliability and monitoring.
    
    Key Features:
    - Minimal transformation preserving ADK event semantics
    - Agent name mapping for consistent UI display
    - Error handling and recovery
    - Session state tracking
    - Performance monitoring
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.metrics = TransformationMetrics()
        self.agent_name_mapping = self._load_agent_mappings()
        self.session_states: Dict[str, Dict[str, Any]] = {}
    
    async def transform_event_stream(
        self, 
        adk_events: AsyncGenerator[Event, None],
        session_id: str
    ) -> AsyncGenerator[str, None]:
        """
        Transform ADK event stream to SSE format for frontend consumption.
        
        Args:
            adk_events: Stream of ADK events from agent execution
            session_id: Session identifier for state tracking
            
        Yields:
            SSE-formatted event strings ready for frontend
        """
        async for event in adk_events:
            try:
                start_time = time.time()
                
                # Transform single event
                transformed_event = await self.transform_single_event(event, session_id)
                
                # Update session state if needed
                if event.actions and event.actions.state_delta:
                    await self.update_session_state(session_id, event.actions.state_delta)
                
                # Format as SSE
                sse_data = self._format_as_sse(transformed_event)
                
                # Update metrics
                processing_time = time.time() - start_time
                self._update_metrics(processing_time)
                
                yield sse_data
                
            except Exception as e:
                self.logger.error(f"Event transformation error: {e}", exc_info=True)
                self.metrics.errors_encountered += 1
                self.metrics.last_error = str(e)
                
                # Yield error event to frontend
                error_event = self._create_error_event(e, session_id)
                yield self._format_as_sse(error_event)
    
    async def transform_single_event(self, event: Event, session_id: str) -> Dict[str, Any]:
        """
        Transform a single ADK event while preserving all information.
        
        Args:
            event: ADK Event object
            session_id: Session identifier
            
        Returns:
            Dictionary ready for JSON serialization
        """
        # Start with the raw event data (preserves all ADK fields)
        transformed = {
            "content": event.content.model_dump() if event.content else None,
            "grounding_metadata": event.grounding_metadata.model_dump() if event.grounding_metadata else None,
            "usage_metadata": event.usage_metadata.model_dump() if event.usage_metadata else None,
            "invocation_id": event.invocation_id,
            "author": event.author,
            "actions": event.actions.model_dump() if event.actions else None,
            "long_running_tool_ids": list(event.long_running_tool_ids) if event.long_running_tool_ids else [],
            "id": event.id,
            "timestamp": event.timestamp,
            "partial": event.partial,
            "turn_complete": event.turn_complete,
            "error_code": event.error_code,
            "error_message": event.error_message,
            "interrupted": event.interrupted,
            "custom_metadata": event.custom_metadata,
            "branch": event.branch
        }
        
        # Add transformation metadata for frontend
        transformed["_transformation"] = {
            "session_id": session_id,
            "agent_display_name": self.map_agent_name(event.author),
            "processed_at": time.time(),
            "service_version": "1.0.0"
        }
        
        return transformed
    
    def map_agent_name(self, agent_name: str) -> str:
        """Map ADK agent names to frontend display names."""
        return self.agent_name_mapping.get(agent_name, f"Processing ({agent_name})")
    
    async def update_session_state(self, session_id: str, state_delta: Dict[str, Any]) -> None:
        """
        Update tracked session state with delta changes.
        
        Args:
            session_id: Session identifier
            state_delta: State changes from ADK event
        """
        if session_id not in self.session_states:
            self.session_states[session_id] = {}
        
        # Merge state delta
        for key, value in state_delta.items():
            self.session_states[session_id][key] = value
        
        self.logger.debug(f"Updated session {session_id} state: {list(state_delta.keys())}")
    
    def get_session_state(self, session_id: str) -> Dict[str, Any]:
        """Get current session state."""
        return self.session_states.get(session_id, {})
    
    def _load_agent_mappings(self) -> Dict[str, str]:
        """Load agent name to display name mappings."""
        return {
            "plan_generator": "Planning Research Strategy",
            "section_planner": "Structuring Report Outline",
            "section_researcher": "Initial Web Research",
            "research_evaluator": "Evaluating Research Quality",
            "escalation_checker": "Quality Assessment", 
            "enhanced_search_executor": "Enhanced Web Research",
            "research_pipeline": "Executing Research Pipeline",
            "iterative_refinement_loop": "Refining Research",
            "interactive_planner_agent": "Interactive Planning",
            "report_composer_with_citations": "Composing Final Report",
            "root_agent": "Interactive Planning"
        }
    
    def _format_as_sse(self, event_data: Dict[str, Any]) -> str:
        """Format event data as SSE message."""
        import json
        json_data = json.dumps(event_data, default=str)
        return f"data: {json_data}\n\n"
    
    def _create_error_event(self, error: Exception, session_id: str) -> Dict[str, Any]:
        """Create error event for frontend display."""
        return {
            "content": {
                "parts": [{"text": f"Processing error: {str(error)}"}],
                "role": "model"
            },
            "author": "transformation_service",
            "error_code": "TRANSFORMATION_ERROR",
            "error_message": str(error),
            "timestamp": time.time(),
            "id": f"error-{int(time.time())}", 
            "actions": {"stateDelta": {}, "artifactDelta": {}},
            "_transformation": {
                "session_id": session_id,
                "agent_display_name": "System Error",
                "processed_at": time.time(),
                "service_version": "1.0.0"
            }
        }
    
    def _update_metrics(self, processing_time: float) -> None:
        """Update service performance metrics."""
        self.metrics.events_processed += 1
        
        # Update running average
        if self.metrics.avg_processing_time == 0:
            self.metrics.avg_processing_time = processing_time
        else:
            # Exponential moving average
            alpha = 0.1
            self.metrics.avg_processing_time = (
                alpha * processing_time + 
                (1 - alpha) * self.metrics.avg_processing_time
            )
    
    def get_metrics(self) -> TransformationMetrics:
        """Get current service metrics."""
        return self.metrics
    
    def reset_metrics(self) -> None:
        """Reset service metrics."""
        self.metrics = TransformationMetrics()
```

## Integration with FastAPI

### Updated Server Integration

```python
# app/server.py - Updated SSE endpoint
from app.services.sse_transformation import ADKEventTransformationService

# Global service instance
transformation_service = ADKEventTransformationService()

@app.get("/transformation/metrics")
async def get_transformation_metrics():
    """Get transformation service performance metrics."""
    return transformation_service.get_metrics()

# The existing /run_sse endpoint from ADK will be enhanced with transformation
```

### ADK Integration Pattern

```python
# app/services/adk_integration.py
from google.adk.cli.fast_api import get_fast_api_app
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
import asyncio

async def enhanced_run_sse(request: AgentRunRequest):
    """
    Enhanced SSE endpoint that adds transformation service.
    
    This wraps the existing ADK SSE functionality with our transformation layer.
    """
    # Get the original ADK app instance
    adk_app = get_fast_api_app(
        agents_dir=AGENT_DIR,
        web=True,
        artifact_service_uri=bucket_name,
        allow_origins=allow_origins,
        session_service_uri=session_service_uri,
    )
    
    # Create transformation service
    transform_service = ADKEventTransformationService()
    
    async def event_generator():
        # This would integrate with ADK's internal event streaming
        # The exact integration depends on ADK's internal architecture
        # For now, this shows the pattern
        
        try:
            # Get ADK event stream (this is conceptual - actual implementation 
            # would need to hook into ADK's internal event generation)
            adk_events = get_adk_event_stream(request)
            
            # Transform and yield events
            async for sse_data in transform_service.transform_event_stream(
                adk_events, 
                request.sessionId
            ):
                yield sse_data
                
        except Exception as e:
            # Error handling
            error_sse = transform_service._format_as_sse(
                transform_service._create_error_event(e, request.sessionId)
            )
            yield error_sse
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )
```

## Error Handling Strategy

### Recovery Mechanisms
1. **Malformed Event Recovery**: Continue processing with error event
2. **State Consistency**: Maintain session state even during errors
3. **Circuit Breaker**: Stop processing if error rate exceeds threshold
4. **Graceful Degradation**: Fall back to raw ADK events if transformation fails

### Monitoring Integration

```python
# app/services/monitoring.py
from google.cloud import logging as google_cloud_logging
from opentelemetry import trace

class TransformationMonitoring:
    """Monitoring integration for transformation service."""
    
    def __init__(self):
        self.logger = google_cloud_logging.Client().logger("sse-transformation")
        self.tracer = trace.get_tracer(__name__)
    
    def log_event_processed(self, session_id: str, agent: str, processing_time: float):
        """Log successful event processing."""
        self.logger.log_struct({
            "event": "sse_event_processed",
            "session_id": session_id,
            "agent": agent,
            "processing_time_ms": processing_time * 1000,
            "timestamp": time.time()
        }, severity="INFO")
    
    def log_error(self, session_id: str, error: Exception, event_data: Dict[str, Any]):
        """Log transformation errors."""
        self.logger.log_struct({
            "event": "sse_transformation_error", 
            "session_id": session_id,
            "error": str(error),
            "event_author": event_data.get("author"),
            "event_id": event_data.get("id"),
            "timestamp": time.time()
        }, severity="ERROR")
```

## File Structure Plan

```
app/
├── services/
│   ├── __init__.py
│   ├── sse_transformation.py       # Main transformation service
│   ├── adk_integration.py          # ADK integration patterns  
│   └── monitoring.py               # Monitoring and observability
├── schemas/
│   ├── __init__.py
│   └── sse_events.py              # Event type definitions
└── server.py                       # Updated with transformation endpoints
```

## Testing Strategy

### Unit Tests
```python
# tests/unit/test_sse_transformation.py
import pytest
from app.services.sse_transformation import ADKEventTransformationService
from google.adk.events import Event

class TestSSETransformation:
    def test_agent_name_mapping(self):
        service = ADKEventTransformationService()
        assert service.map_agent_name("plan_generator") == "Planning Research Strategy"
    
    def test_error_event_creation(self):
        service = ADKEventTransformationService()
        error = ValueError("Test error")
        event = service._create_error_event(error, "test-session")
        assert event["error_code"] == "TRANSFORMATION_ERROR"
        assert "Test error" in event["error_message"]
    
    async def test_session_state_tracking(self):
        service = ADKEventTransformationService()
        await service.update_session_state("test", {"key": "value"})
        state = service.get_session_state("test")
        assert state["key"] == "value"
```

### Integration Tests
```python
# tests/integration/test_sse_endpoint.py
import pytest
from fastapi.testclient import TestClient
from app.server import app

class TestSSEEndpoint:
    def test_sse_stream_format(self):
        client = TestClient(app)
        # Test actual SSE streaming with mock ADK events
        pass
    
    def test_error_handling(self):
        # Test error recovery and graceful degradation
        pass
```

## Deployment Considerations

### Configuration
```python
# app/config.py - Enhanced configuration
@dataclass
class ResearchConfiguration:
    # ... existing fields ...
    
    # SSE Transformation Settings
    transformation_enabled: bool = True
    max_events_per_session: int = 1000
    session_state_ttl: int = 3600  # 1 hour
    error_threshold: float = 0.1   # 10% error rate triggers circuit breaker
    monitoring_enabled: bool = True
```

### Health Checks
```python
@app.get("/health/transformation")
async def transformation_health():
    """Health check for transformation service."""
    metrics = transformation_service.get_metrics()
    
    if metrics.errors_encountered > 0:
        error_rate = metrics.errors_encountered / max(metrics.events_processed, 1)
        if error_rate > 0.1:  # 10% error threshold
            return {"status": "degraded", "error_rate": error_rate}
    
    return {"status": "healthy", "metrics": metrics}
```

## Conclusion

This design provides a robust, reliable transformation service that enhances ADK's SSE implementation without breaking existing functionality. The service focuses on reliability, observability, and maintainability while preserving full compatibility with both ADK patterns and the existing frontend implementation.

**Key Benefits:**
- ✅ Preserves existing frontend compatibility
- ✅ Adds comprehensive error handling and monitoring  
- ✅ Follows ADK architectural patterns
- ✅ Provides extensibility for future enhancements
- ✅ Maintains session state consistency
- ✅ Offers performance metrics and observability