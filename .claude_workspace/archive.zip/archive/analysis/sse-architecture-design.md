# SSE Architecture Design: Event Transformation Layer & Client Implementation

## 1. Event Transformation Mapping

### 1.1 ADK SSE Event Structure
```typescript
interface ADKEvent {
  content?: {
    parts: Array<{
      text?: string
      functionCall?: {
        name: string
        args: Record<string, any>
      }
      functionResponse?: {
        name: string
        content: any
      }
    }>
  }
  author: 'user' | 'model'
  actions?: {
    stateDelta?: {
      state: string
      [key: string]: any
    }
  }
}
```

### 1.2 Event Transformation Rules

#### Thinking Updates (ThinkingStep)
```typescript
// ADK Event → ThinkingUpdate transformation
function transformToThinkingUpdate(event: ADKEvent): ThinkingUpdate | null {
  // Function calls represent thinking steps
  if (event.content?.parts) {
    for (const part of event.content.parts) {
      if (part.functionCall) {
        return {
          stepId: generateStepId(part.functionCall),
          agent: extractAgentName(part.functionCall.name),
          action: formatActionName(part.functionCall.name),
          status: 'active',
          duration: undefined // Will be calculated on completion
        }
      }
      
      if (part.functionResponse) {
        // Mark previous step as complete
        return {
          stepId: generateStepId(part.functionResponse),
          agent: extractAgentName(part.functionResponse.name),
          action: formatActionName(part.functionResponse.name),
          status: 'complete',
          duration: calculateDuration(part.functionResponse)
        }
      }
    }
  }
  
  // State changes can also represent thinking steps
  if (event.actions?.stateDelta) {
    return {
      stepId: generateStateStepId(event.actions.stateDelta),
      agent: 'Planning Agent',
      action: event.actions.stateDelta.state,
      status: 'pending',
      duration: undefined
    }
  }
  
  return null
}
```

#### Message Updates
```typescript
// ADK Event → MessageUpdate transformation
function transformToMessageUpdate(event: ADKEvent): MessageUpdate | null {
  if (event.author === 'model' && event.content?.parts) {
    const textParts = event.content.parts
      .filter(part => part.text)
      .map(part => part.text)
      .join('')
    
    if (textParts) {
      return {
        messageId: generateMessageId(),
        content: textParts,
        isComplete: isStreamComplete(event)
      }
    }
  }
  
  return null
}
```

### 1.3 Event Stream Parser
```typescript
class SSEEventParser {
  private buffer: string = ''
  private currentMessage: Partial<MessageUpdate> = {}
  private activeSteps: Map<string, ThinkingUpdate> = new Map()
  
  parseEvent(data: string): Array<ThinkingUpdate | MessageUpdate> {
    const events: Array<ThinkingUpdate | MessageUpdate> = []
    
    try {
      const adkEvent = JSON.parse(data) as ADKEvent
      
      // Extract thinking updates
      const thinkingUpdate = transformToThinkingUpdate(adkEvent)
      if (thinkingUpdate) {
        this.trackStepLifecycle(thinkingUpdate)
        events.push(thinkingUpdate)
      }
      
      // Extract message updates
      const messageUpdate = transformToMessageUpdate(adkEvent)
      if (messageUpdate) {
        this.aggregateMessage(messageUpdate)
        events.push(this.currentMessage as MessageUpdate)
      }
      
    } catch (error) {
      console.error('Failed to parse SSE event:', error)
    }
    
    return events
  }
  
  private trackStepLifecycle(update: ThinkingUpdate) {
    if (update.status === 'active') {
      this.activeSteps.set(update.stepId, {
        ...update,
        startTime: Date.now()
      })
    } else if (update.status === 'complete') {
      const activeStep = this.activeSteps.get(update.stepId)
      if (activeStep) {
        update.duration = `${Date.now() - activeStep.startTime}ms`
        this.activeSteps.delete(update.stepId)
      }
    }
  }
  
  private aggregateMessage(update: MessageUpdate) {
    if (!this.currentMessage.messageId) {
      this.currentMessage = update
    } else {
      this.currentMessage.content += update.content
      this.currentMessage.isComplete = update.isComplete
    }
    
    if (update.isComplete) {
      this.currentMessage = {}
    }
  }
}
```

## 2. SSE Client Architecture

### 2.1 Core SSE Service
```typescript
// services/sse.ts
import { EventEmitter } from 'events'

export class SSEService extends EventEmitter {
  private eventSource: EventSource | null = null
  private parser: SSEEventParser = new SSEEventParser()
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectDelay = 1000
  private connectionState: 'connecting' | 'connected' | 'disconnected' = 'disconnected'
  
  connect(url?: string) {
    if (this.eventSource?.readyState === EventSource.OPEN) {
      return
    }
    
    const sseUrl = url || `${import.meta.env.VITE_API_URL || ''}/api/sse`
    this.connectionState = 'connecting'
    this.emit('connected', false)
    
    this.eventSource = new EventSource(sseUrl, {
      withCredentials: true
    })
    
    this.eventSource.onopen = () => {
      console.log('SSE connected')
      this.connectionState = 'connected'
      this.reconnectAttempts = 0
      this.emit('connected', true)
    }
    
    this.eventSource.onmessage = (event) => {
      const events = this.parser.parseEvent(event.data)
      
      events.forEach(evt => {
        if ('stepId' in evt) {
          this.emit('thinking_update', evt)
        } else if ('messageId' in evt) {
          this.emit('message_update', evt)
        }
      })
    }
    
    this.eventSource.onerror = (error) => {
      console.error('SSE error:', error)
      this.connectionState = 'disconnected'
      this.emit('connected', false)
      this.emit('error', new Error('SSE connection error'))
      
      // Auto-reconnect logic
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        setTimeout(() => {
          this.reconnectAttempts++
          this.connect(url)
        }, this.reconnectDelay * Math.pow(2, this.reconnectAttempts))
      }
    }
    
    // Handle specific event types from ADK
    this.eventSource.addEventListener('agent_state', (event) => {
      this.handleAgentStateEvent(event)
    })
    
    this.eventSource.addEventListener('stream_end', (event) => {
      this.handleStreamEnd(event)
    })
  }
  
  disconnect() {
    if (this.eventSource) {
      this.eventSource.close()
      this.eventSource = null
      this.connectionState = 'disconnected'
      this.emit('connected', false)
    }
  }
  
  sendMessage(message: string) {
    // SSE is read-only, so we need to send via regular HTTP
    fetch(`${import.meta.env.VITE_API_URL || ''}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ content: message }),
      credentials: 'include'
    }).catch(error => {
      this.emit('error', error)
    })
  }
  
  isConnected(): boolean {
    return this.connectionState === 'connected'
  }
  
  getConnectionState(): string {
    return this.connectionState
  }
}

export const sseService = new SSEService()
```

### 2.2 Drop-in Replacement Hook
```typescript
// hooks/useSSE.ts
import { useEffect, useState, useCallback } from 'react'
import { sseService } from '../services/sse'
import type { ThinkingUpdate, MessageUpdate } from '../services/websocket'

export function useSSE() {
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  
  useEffect(() => {
    // Connect on mount
    sseService.connect()
    
    // Set up listeners (identical to WebSocket)
    const handleConnected = (connected: boolean) => {
      setIsConnected(connected)
      if (connected) {
        setError(null)
      }
    }
    
    const handleError = (err: Error) => {
      setError(err)
    }
    
    sseService.on('connected', handleConnected)
    sseService.on('error', handleError)
    
    // Cleanup
    return () => {
      sseService.off('connected', handleConnected)
      sseService.off('error', handleError)
    }
  }, [])
  
  const sendMessage = useCallback((message: string) => {
    sseService.sendMessage(message)
  }, [])
  
  const onThinkingUpdate = useCallback((callback: (update: ThinkingUpdate) => void) => {
    sseService.on('thinking_update', callback)
    return () => sseService.off('thinking_update', callback)
  }, [])
  
  const onMessageUpdate = useCallback((callback: (update: MessageUpdate) => void) => {
    sseService.on('message_update', callback)
    return () => sseService.off('message_update', callback)
  }, [])
  
  return {
    isConnected,
    error,
    sendMessage,
    onThinkingUpdate,
    onMessageUpdate,
  }
}

// Alias for seamless migration
export const useWebSocket = useSSE
```

## 3. Visual Preservation Strategy

### 3.1 Animation Continuity
```typescript
// Ensure Framer Motion animations remain unchanged
const ThinkingStepAnimation = {
  initial: { opacity: 0, x: -20 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: 20 },
  transition: { type: 'spring', damping: 20 }
}

// Preserve timeline behavior with buffering
class AnimationBuffer {
  private queue: ThinkingUpdate[] = []
  private isProcessing = false
  
  addUpdate(update: ThinkingUpdate, callback: (update: ThinkingUpdate) => void) {
    this.queue.push(update)
    
    if (!this.isProcessing) {
      this.processQueue(callback)
    }
  }
  
  private async processQueue(callback: (update: ThinkingUpdate) => void) {
    this.isProcessing = true
    
    while (this.queue.length > 0) {
      const update = this.queue.shift()!
      callback(update)
      
      // Maintain 60fps animation cadence
      await new Promise(resolve => requestAnimationFrame(resolve))
    }
    
    this.isProcessing = false
  }
}
```

### 3.2 Performance Optimization
```typescript
// Optimize SSE parsing for 60fps
class OptimizedSSEParser {
  private worker: Worker
  
  constructor() {
    // Offload parsing to Web Worker
    this.worker = new Worker('/sse-parser-worker.js')
  }
  
  parseAsync(data: string): Promise<Array<ThinkingUpdate | MessageUpdate>> {
    return new Promise((resolve) => {
      this.worker.postMessage({ type: 'parse', data })
      this.worker.onmessage = (e) => {
        if (e.data.type === 'parsed') {
          resolve(e.data.events)
        }
      }
    })
  }
}
```

## 4. Connection Status UI

### 4.1 Subtle Connection Indicator
```tsx
// components/ConnectionStatus.tsx
import { motion, AnimatePresence } from 'framer-motion'
import { useSSE } from '@/hooks/useSSE'

export function ConnectionStatus() {
  const { isConnected } = useSSE()
  
  return (
    <AnimatePresence>
      {!isConnected && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 0.6, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="fixed top-4 right-4 z-50"
        >
          <div className="flex items-center gap-2 px-3 py-1.5 bg-yellow-500/10 border border-yellow-500/20 rounded-full backdrop-blur-sm">
            <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
            <span className="text-xs text-yellow-500/80">Reconnecting...</span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
```

### 4.2 Connection State Management
```typescript
// Enhanced connection state with degradation handling
interface ConnectionState {
  status: 'connected' | 'connecting' | 'disconnected' | 'degraded'
  quality: 'excellent' | 'good' | 'poor'
  latency: number
}

class ConnectionMonitor {
  private state: ConnectionState = {
    status: 'disconnected',
    quality: 'excellent',
    latency: 0
  }
  
  private pingInterval: NodeJS.Timer | null = null
  
  startMonitoring() {
    this.pingInterval = setInterval(() => {
      this.measureLatency()
    }, 5000)
  }
  
  private async measureLatency() {
    const start = performance.now()
    
    try {
      await fetch('/api/ping')
      const latency = performance.now() - start
      
      this.state.latency = latency
      this.state.quality = 
        latency < 100 ? 'excellent' :
        latency < 300 ? 'good' : 'poor'
        
    } catch (error) {
      this.state.status = 'degraded'
    }
  }
}
```

## 5. Migration Strategy

### 5.1 Feature Flag Implementation
```typescript
// config/features.ts
export const features = {
  useSSE: import.meta.env.VITE_USE_SSE === 'true' || false
}

// hooks/useConnection.ts
import { useWebSocket as useWS } from './useWebSocket'
import { useSSE } from './useSSE'
import { features } from '@/config/features'

export const useConnection = features.useSSE ? useSSE : useWS
```

### 5.2 Gradual Rollout Plan
1. **Phase 1**: Deploy with feature flag disabled
2. **Phase 2**: Enable for 10% of users, monitor metrics
3. **Phase 3**: Increase to 50% if metrics are stable
4. **Phase 4**: Full rollout with WebSocket fallback
5. **Phase 5**: Remove WebSocket code after 2 weeks of stability

## 6. Testing Strategy

### 6.1 Visual Regression Tests
```typescript
// tests/visual/thinking-panel.spec.ts
import { test, expect } from '@playwright/test'

test.describe('ThinkingPanel animations', () => {
  test('maintains 60fps during updates', async ({ page }) => {
    await page.goto('/test-harness')
    
    // Start performance recording
    await page.evaluate(() => performance.mark('animation-start'))
    
    // Trigger rapid thinking updates
    await page.evaluate(() => {
      for (let i = 0; i < 20; i++) {
        window.dispatchEvent(new CustomEvent('thinking_update', {
          detail: { stepId: `step-${i}`, status: 'active' }
        }))
      }
    })
    
    // Measure frame rate
    const fps = await page.evaluate(() => {
      const entries = performance.getEntriesByType('measure')
      // Calculate FPS from performance entries
      return calculateFPS(entries)
    })
    
    expect(fps).toBeGreaterThan(58) // Allow small variance
  })
})
```

### 6.2 Event Transformation Tests
```typescript
// tests/unit/event-parser.spec.ts
describe('SSEEventParser', () => {
  it('preserves exact thinking update structure', () => {
    const parser = new SSEEventParser()
    const adkEvent = {
      content: {
        parts: [{
          functionCall: {
            name: 'search_web',
            args: { query: 'test' }
          }
        }]
      },
      author: 'model'
    }
    
    const [update] = parser.parseEvent(JSON.stringify(adkEvent))
    
    expect(update).toMatchObject({
      stepId: expect.any(String),
      agent: expect.any(String),
      action: 'search_web',
      status: 'active'
    })
  })
})
```

## 7. Performance Benchmarks

### Target Metrics
- **Connection Time**: < 500ms (vs WebSocket ~200ms)
- **Message Latency**: < 50ms processing time
- **Animation FPS**: Consistent 60fps
- **Memory Usage**: < 50MB for 1000 events
- **CPU Usage**: < 5% during active streaming

### Monitoring Implementation
```typescript
class PerformanceMonitor {
  private metrics = {
    fps: new Array(60).fill(60),
    latency: [],
    memory: []
  }
  
  recordFrame() {
    const fps = 1000 / (performance.now() - this.lastFrame)
    this.metrics.fps.push(fps)
    this.metrics.fps.shift()
    
    if (this.metrics.fps.every(f => f < 50)) {
      console.warn('Performance degradation detected')
      this.optimizeRendering()
    }
  }
  
  private optimizeRendering() {
    // Reduce animation complexity
    // Batch DOM updates
    // Throttle event processing
  }
}
```

## 8. Implementation Checklist

### Phase 1: Core Infrastructure
- [ ] Implement SSEService class
- [ ] Create SSEEventParser with ADK mapping
- [ ] Build useSSE hook with identical interface
- [ ] Add feature flag system
- [ ] Set up performance monitoring

### Phase 2: Visual Preservation
- [ ] Implement AnimationBuffer for smooth updates
- [ ] Create ConnectionStatus component
- [ ] Add latency compensation
- [ ] Optimize for 60fps performance
- [ ] Test all Framer Motion animations

### Phase 3: Testing & Validation
- [ ] Write comprehensive unit tests
- [ ] Create visual regression test suite
- [ ] Performance benchmark suite
- [ ] A/B testing infrastructure
- [ ] Rollback mechanism

### Phase 4: Deployment
- [ ] Deploy with feature flag off
- [ ] Monitor key metrics
- [ ] Gradual rollout (10% → 50% → 100%)
- [ ] Document any issues
- [ ] Remove WebSocket code after stability

## Conclusion

This architecture ensures:
1. **Zero visual regression** - All animations and UI behaviors remain identical
2. **Seamless migration** - Drop-in replacement with feature flags
3. **Performance parity** - Maintains 60fps with optimized parsing
4. **Graceful degradation** - Handles connection issues elegantly
5. **Future-proof** - Ready for ADK event evolution

The key innovation is the event transformation layer that perfectly maps ADK's event structure to the existing UI expectations, while the performance optimizations ensure the beautiful, fluid interface remains responsive even under high event load.