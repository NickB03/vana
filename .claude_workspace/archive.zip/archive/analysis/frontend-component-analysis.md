# ADK Frontend Component Analysis

## Component Dependency Graph

```mermaid
graph TD
    App[App.tsx] --> WelcomeScreen[WelcomeScreen.tsx]
    App --> ChatMessagesView[ChatMessagesView.tsx]
    App --> utils[utils.ts]
    
    WelcomeScreen --> InputForm[InputForm.tsx]
    WelcomeScreen --> UI_Components[UI Components]
    
    ChatMessagesView --> InputForm
    ChatMessagesView --> ActivityTimeline[ActivityTimeline.tsx]
    ChatMessagesView --> ReactMarkdown[react-markdown]
    ChatMessagesView --> UI_Components
    
    InputForm --> UI_Components
    ActivityTimeline --> UI_Components
    
    UI_Components --> Badge[badge.tsx]
    UI_Components --> Button[button.tsx]
    UI_Components --> Card[card.tsx]
    UI_Components --> Input[input.tsx]
    UI_Components --> ScrollArea[scroll-area.tsx]
    UI_Components --> Select[select.tsx]
    UI_Components --> Tabs[tabs.tsx]
    UI_Components --> Textarea[textarea.tsx]
```

## 1. Core Application Component (App.tsx)

### Dependencies
- **External Libraries**:
  - `react` (hooks: useState, useRef, useCallback, useEffect)
  - `uuid` (v4 for ID generation) - Note: Not in package.json, needs to be added

- **Internal Components**:
  - `WelcomeScreen`
  - `ChatMessagesView`

### Key Responsibilities
1. **State Management**:
   - User/Session IDs
   - Message history
   - Loading states
   - Event timeline data
   - Backend health status

2. **API Integration**:
   - Session creation
   - SSE event handling
   - Backend health checking

3. **Data Processing**:
   - SSE event parsing
   - Message accumulation
   - Agent activity tracking

### Integration Points
```typescript
// Key interfaces used by App.tsx
interface MessageWithAgent {
  type: "human" | "ai";
  content: string;
  id: string;
  agent?: string;
  finalReportWithCitations?: boolean;
}

interface ProcessedEvent {
  title: string;
  data: any;
}

interface AgentResponse {
  content: AgentMessage;
  usageMetadata: UsageMetadata;
  author: string;
  actions: {
    stateDelta: Record<string, any>;
  };
}
```

## 2. Welcome Screen Component

### Dependencies
- **Internal Components**:
  - `InputForm`
  - `Card` (from ui/)
  - `Badge` (from ui/)

### Props Interface
```typescript
interface WelcomeScreenProps {
  handleSubmit: (query: string) => void;
  isLoading: boolean;
  onCancel: () => void;
}
```

### Features
- Landing page UI
- Example queries display
- Input form integration
- Loading state handling

## 3. Chat Messages View Component

### Dependencies
- **External Libraries**:
  - `react-markdown`
  - `remark-gfm`
  - `lucide-react` (icons)

- **Internal Components**:
  - `InputForm`
  - `ActivityTimeline`
  - `ScrollArea` (from ui/)
  - `Button` (from ui/)
  - `Badge` (from ui/)

### Props Interface
```typescript
interface ChatMessagesViewProps {
  messages: MessageWithAgent[];
  isLoading: boolean;
  scrollAreaRef: React.RefObject<HTMLDivElement>;
  onSubmit: (query: string) => void;
  onCancel: () => void;
  displayData: string | null;
  messageEvents: Map<string, ProcessedEvent[]>;
  websiteCount: number;
}
```

### Key Features
1. **Message Rendering**:
   - Human/AI message bubbles
   - Markdown support with custom components
   - Copy functionality
   - Agent attribution

2. **Activity Timeline Integration**:
   - Shows agent processing steps
   - Real-time updates
   - Event visualization

## 4. Input Form Component

### Dependencies
- **Internal UI Components**:
  - `Button`
  - `Textarea`

- **External Libraries**:
  - `lucide-react` (icons: Loader2, Send)

### Props Interface
```typescript
interface InputFormProps {
  onSubmit: (query: string) => void;
  isLoading: boolean;
  context?: 'homepage' | 'chat';
}
```

### Features
- Text input with auto-resize
- Enter key submission
- Context-aware placeholders
- Loading state handling

## 5. Activity Timeline Component

### Dependencies
- **Internal UI Components**:
  - `Tabs`
  - `Badge`
  - `Button`
  - `ScrollArea`

### Expected Props (inferred)
```typescript
interface ActivityTimelineProps {
  events: ProcessedEvent[];
  websiteCount: number;
}
```

### Features
- Agent activity visualization
- Event grouping by type
- Source tracking
- Timeline navigation

## 6. UI Component Library (shadcn/ui)

### Component Inventory
1. **Badge**: Status indicators, labels
2. **Button**: Interactive elements
3. **Card**: Container components
4. **Input**: Form inputs
5. **ScrollArea**: Scrollable containers
6. **Select**: Dropdown selections
7. **Tabs**: Tab navigation
8. **Textarea**: Multi-line text input

### Dependencies
- `@radix-ui/react-*` components
- `class-variance-authority`
- `clsx`
- `tailwind-merge`

## Integration Considerations

### 1. State Flow
```
App.tsx (Global State)
  ├── WelcomeScreen
  │   └── InputForm → triggers handleSubmit
  └── ChatMessagesView
      ├── Message Display
      ├── ActivityTimeline → displays messageEvents
      └── InputForm → triggers handleSubmit
```

### 2. Event Flow
```
User Input → InputForm → App.handleSubmit → API Call
API Response (SSE) → App.processSseEventData → State Updates
State Updates → Component Re-renders → UI Updates
```

### 3. Critical Data Structures

#### Message Flow
```typescript
// User creates message
const userMessage = {
  type: "human",
  content: "User's question",
  id: "timestamp_string"
};

// AI response accumulates
const aiMessage = {
  type: "ai",
  content: "Accumulated response text",
  id: "timestamp_ai",
  agent: "interactive_planner_agent",
  finalReportWithCitations?: boolean
};
```

#### Event Processing
```typescript
// Events linked to messages
const messageEvents = new Map([
  ["message_id", [
    {
      title: "Planning Research Strategy",
      data: { type: 'text', content: '...' }
    },
    {
      title: "Function Call: google_search",
      data: { type: 'functionCall', name: '...', args: {} }
    }
  ]]
]);
```

## Migration Requirements

### 1. Core Dependencies to Maintain
- React 19+ (for latest hooks)
- TypeScript for type safety
- SSE event handling logic
- Message/Event state management

### 2. Component Extraction Strategy

#### Minimal Extraction (Reuse Core Logic)
```typescript
// Extract core hooks
export const useADKSession = () => {
  const [sessionId, setSessionId] = useState<string | null>(null);
  // Session management logic
  return { sessionId, createSession };
};

export const useADKMessages = () => {
  const [messages, setMessages] = useState<MessageWithAgent[]>([]);
  // Message handling logic
  return { messages, addMessage, updateMessage };
};
```

#### Component Wrapper Pattern
```typescript
// Wrap ADK components with custom styling
export const CustomChatView = (props: ChatViewProps) => {
  return (
    <div className="custom-wrapper">
      <ChatMessagesView {...props} />
    </div>
  );
};
```

### 3. API Integration Layer

```typescript
// Abstract API calls for easier customization
interface ADKApiAdapter {
  createSession(): Promise<SessionData>;
  sendMessage(params: MessageParams): Promise<EventSource>;
  checkHealth(): Promise<boolean>;
}

class DefaultADKApiAdapter implements ADKApiAdapter {
  // Implementation following ADK patterns
}
```

### 4. Styling Customization Points

1. **CSS Variables** (in global.css):
   - Color schemes
   - Typography scales
   - Spacing systems

2. **Component Classes**:
   - Override shadcn/ui defaults
   - Custom component variants
   - Theme-specific styles

3. **Tailwind Configuration**:
   - Custom color palette
   - Font families
   - Animation presets

## Testing Considerations

### 1. Component Testing
```typescript
// Test message rendering
describe('ChatMessagesView', () => {
  it('renders human and AI messages', () => {
    const messages = [
      { type: 'human', content: 'Test', id: '1' },
      { type: 'ai', content: 'Response', id: '2', agent: 'test_agent' }
    ];
    render(<ChatMessagesView messages={messages} {...otherProps} />);
    expect(screen.getByText('Test')).toBeInTheDocument();
    expect(screen.getByText('Response')).toBeInTheDocument();
  });
});
```

### 2. Integration Testing
```typescript
// Test SSE event processing
describe('SSE Event Processing', () => {
  it('processes agent events correctly', () => {
    const { result } = renderHook(() => useSSEEventProcessor());
    
    act(() => {
      result.current.processEvent({
        content: { parts: [{ text: 'Test' }] },
        author: 'plan_generator'
      });
    });
    
    expect(result.current.events).toContainEqual(
      expect.objectContaining({
        title: 'Planning Research Strategy'
      })
    );
  });
});
```

## Conclusion

The ADK frontend is built with a clear separation of concerns:
1. **App.tsx** handles all state and API integration
2. **Components** are mostly presentational with clear props
3. **UI library** provides consistent styling
4. **Event processing** is centralized and predictable

For successful migration:
1. Preserve the SSE event handling logic
2. Maintain agent name mappings
3. Keep state management patterns
4. Reuse or replicate UI component interfaces
5. Test thoroughly with real ADK backend responses