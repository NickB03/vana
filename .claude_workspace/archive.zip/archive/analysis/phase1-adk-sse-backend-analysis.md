# Phase 1 ADK Backend SSE Analysis

**Date**: 2025-07-28  
**Author**: Claude Code  
**Phase**: Backend Team - SSE Implementation Analysis  
**Status**: Complete  

## Executive Summary

This analysis documents the existing ADK SSE implementation, event structures, and provides the design foundation for transforming ADK events to frontend-compatible format while preserving the visual design and agent workflows.

## 1. ADK SSE Implementation Analysis

### Current Architecture
- **Endpoint**: `/run_sse` (POST)
- **Provider**: Google ADK CLI via `get_fast_api_app()` function
- **Protocol**: Server-Sent Events (SSE) with `data:` prefixed JSON messages
- **Session Management**: RESTful session creation via `/apps/{app_name}/users/{user_id}/sessions`

### Request Format
```typescript
interface AgentRunRequest {
  appName: string;     // Application identifier
  userId: string;      // User identifier  
  sessionId: string;   // Session UUID
  newMessage: {        // User message content
    parts: [{text: string}];
    role: "user";
  };
  streaming: boolean;  // SSE streaming control (default: false)
  stateDelta?: object; // Optional state modifications
}
```

### Session Management
- **Create Session**: `POST /apps/{app_name}/users/{user_id}/sessions`
- **Session Response**: 
  ```json
  {
    "id": "uuid-session-id",
    "appName": "app", 
    "userId": "user_id",
    "state": {},
    "events": [],
    "lastUpdateTime": timestamp
  }
  ```

## 2. ADK Event Structure Documentation

### Core Event Schema
Based on `google.adk.events.Event` class analysis and live SSE capture:

```typescript
interface ADKEvent {
  // Core Content
  content?: {
    parts: ContentPart[];
    role: "model" | "user";
  };
  
  // Grounding & Sources  
  grounding_metadata?: {
    grounding_chunks?: GroundingChunk[];
    grounding_supports?: GroundingSupport[];
  };
  
  // Usage Statistics
  usageMetadata?: {
    candidatesTokenCount: number;
    candidatesTokensDetails: [{modality: string, tokenCount: number}];
    promptTokenCount: number;
    promptTokensDetails: [{modality: string, tokenCount: number}];
    thoughtsTokenCount?: number;
    totalTokenCount: number;
    trafficType: string;
  };
  
  // Agent Context
  invocationId: string;  // Unique execution ID
  author: string;        // Agent name (plan_generator, section_researcher, etc.)
  id: string;           // Event UUID
  timestamp: number;    // Unix timestamp
  
  // State Management
  actions: {
    stateDelta: Record<string, any>;        // State changes
    artifactDelta: Record<string, number>;  // Artifact changes  
    requestedAuthConfigs: Record<string, any>;
    skipSummarization?: boolean;
    transferToAgent?: string;
    escalate?: boolean;
  };
  
  // Agent Execution
  longRunningToolIds: string[];
  
  // Error Handling
  error_code?: string;
  error_message?: string;
  interrupted?: boolean;
  
  // Flow Control
  partial?: boolean;
  turn_complete?: boolean;
  branch?: string;
  custom_metadata?: Record<string, any>;
}
```

### ContentPart Types
```typescript
type ContentPart = 
  | { text: string }
  | { functionCall: { id: string; name: string; args: Record<string, any> } }
  | { functionResponse: { id: string; name: string; response: { result: string } } };
```

### Key State Delta Fields (from Vana Agent)
```typescript
interface VanaStateDelta {
  research_plan?: string;                    // Updated research plan
  final_report_with_citations?: string;     // Final report content
  url_to_short_id?: Record<string, string>; // URL mappings for citations
  sources?: Record<string, {               // Research sources
    short_id: string;
    title: string;
    url: string;
    domain: string;
    supported_claims: Array<{
      text_segment: string;
      confidence: number;
    }>;
  }>;
  section_research_findings?: string;        // Research content
  research_evaluation?: {                    // Quality assessment
    grade: "pass" | "fail";
    comment: string;
    follow_up_queries?: Array<{ search_query: string }>;
  };
}
```

## 3. Agent Name Mapping

The frontend expects specific agent display names. Current mapping from agent code:

```typescript
const agentNameMapping = {
  "plan_generator": "Planning Research Strategy",
  "section_planner": "Structuring Report Outline", 
  "section_researcher": "Initial Web Research",
  "research_evaluator": "Evaluating Research Quality",
  "escalation_checker": "Quality Assessment",
  "enhanced_search_executor": "Enhanced Web Research", 
  "research_pipeline": "Executing Research Pipeline",
  "iterative_refinement_loop": "Refining Research",
  "interactive_planner_agent": "Interactive Planning",
  "report_composer_with_citations": "Composing Final Report",
  "root_agent": "Interactive Planning"
};
```

## 4. Critical Integration Points

### Source Tracking via Grounding Metadata
- ADK provides `grounding_metadata.grounding_chunks` with web sources
- Each chunk contains: `{web: {uri, title, domain}}`
- `grounding_supports` maps confidence scores to text segments
- Vana callback `collect_research_sources_callback` processes these into `sources` state

### Session State Management
- ADK maintains session state via `actions.stateDelta`
- Key fields: `research_plan`, `sources`, `final_report_with_citations`
- State is cumulative across agent invocations

### Function Call Tracking
- ADK agents use function calls for tool invocations (google_search, sub-agents)
- Format: `{functionCall: {id, name, args}}` → `{functionResponse: {id, name, response}}`
- Frontend displays these as timeline activities

## 5. Event Transformation Requirements

### Timeline Event Processing
Current frontend expects `ProcessedEvent[]`:
```typescript
interface ProcessedEvent {
  title: string;  // Human-readable activity name
  data: {
    type: 'text' | 'functionCall' | 'functionResponse' | 'sources';
    content?: string;
    name?: string;
    args?: any;
    response?: any;
  };
}
```

### Key Transformations Needed:
1. **Agent Name Translation**: `author` field → display names
2. **Content Extraction**: `content.parts[].text` → timeline text
3. **Function Call Parsing**: Extract tool invocations for timeline
4. **Source Aggregation**: Process `grounding_metadata` → source counts
5. **State Delta Processing**: Extract key state changes for UI updates

## 6. Current Frontend Compatibility

### Existing SSE Processing
The frontend in `App.tsx` already:
- ✅ Handles SSE protocol correctly (`data:` prefixed JSON)
- ✅ Parses ADK event structure
- ✅ Extracts `content.parts`, `author`, `actions.stateDelta`
- ✅ Maps agent names to display titles
- ✅ Processes function calls/responses
- ✅ Tracks source counts from `url_to_short_id`
- ✅ Handles final report rendering

### No Breaking Changes Required
The frontend is **already compatible** with ADK SSE format. The analysis shows:
- Event parsing logic matches ADK event structure
- Agent name mapping is correct
- Timeline processing handles ADK function calls
- Source tracking uses correct state delta fields

## 7. Design Recommendations

### Event Transformation Service Architecture
Since the frontend is already compatible, the transformation service should:

1. **Minimal Processing**: Pass-through ADK events with minimal transformation
2. **Agent Name Enrichment**: Ensure consistent agent name mapping
3. **Error Handling**: Wrap ADK events with error recovery
4. **Session State Tracking**: Maintain session context for frontend
5. **Monitoring Integration**: Add observability for event processing

### Service Design Pattern
```typescript
class ADKEventTransformationService {
  // Transform ADK event to frontend-compatible format
  transformEvent(adkEvent: ADKEvent): ProcessedEvent[];
  
  // Handle session state changes
  processStateDelta(stateDelta: any, sessionId: string): void;
  
  // Map agent names to display names
  mapAgentName(agentName: string): string;
  
  // Extract and format sources
  extractSources(groundingMetadata?: any): SourceInfo[];
}
```

## 8. Next Steps for Implementation

### Phase 2: Backend Implementation
1. Create `ADKEventTransformationService` in `app/services/`
2. Implement middleware for SSE event processing
3. Add session state management integration
4. Create monitoring and error handling layers

### Phase 3: Frontend Integration  
1. Update SSE endpoint to use transformation service
2. Add enhanced error handling and recovery
3. Implement session state synchronization
4. Add performance monitoring

### Phase 4: Testing & Validation
1. Unit tests for transformation service
2. Integration tests with live ADK events
3. End-to-end testing with frontend
4. Performance benchmarking

## Conclusion

The analysis shows that ADK's SSE implementation is robust and the current frontend is already well-designed for compatibility. The transformation service can focus on reliability, monitoring, and enhancing the developer experience rather than major structural changes.

**Key Finding**: The existing frontend SSE processing in `App.tsx` already correctly handles ADK event formats, requiring minimal backend transformation logic.