# 🔧 VANA Backend Update Plan

## Executive Summary
Comprehensive backend updates to support the new frontend architecture while maintaining ADK compliance and adding real-time agent visualization capabilities.

---

## 📊 Current State Analysis

### Working Components ✅
- Google ADK FastAPI framework (`get_fast_api_app`)
- `/run` and `/run_sse` endpoints
- Session persistence with GCS backup
- Agent execution pipeline
- Cloud logging and tracing

### Critical Issues 🔴
1. **Agent events not broadcasting to SSE streams**
2. **Response format mismatch** (snake_case vs camelCase)
3. **Missing callback-to-SSE integration**
4. **No session cleanup or timeout handling**
5. **Development support gaps**

---

## 🎯 PHASE 1: SSE Event Broadcasting Fix (Priority: CRITICAL)

### 1.1 Enhanced SSE Broadcaster
```python
# app/utils/sse_broadcaster.py - UPDATE EXISTING

import asyncio
import json
from typing import Dict, List, Set
from datetime import datetime
from collections import defaultdict

class EnhancedSSEBroadcaster:
    """Session-aware SSE broadcasting with proper event routing"""
    
    def __init__(self):
        # Session-specific subscriber queues
        self._subscribers: Dict[str, List[asyncio.Queue]] = defaultdict(list)
        self._event_history: Dict[str, List[dict]] = defaultdict(list)
        self._max_history_size = 100
        
    async def add_subscriber(self, session_id: str) -> asyncio.Queue:
        """Add a new SSE subscriber for a session"""
        queue = asyncio.Queue(maxsize=50)
        self._subscribers[session_id].append(queue)
        
        # Send recent history to new subscriber
        for event in self._event_history[session_id][-10:]:
            await queue.put(f"data: {json.dumps(event)}\n\n")
        
        return queue
    
    async def remove_subscriber(self, session_id: str, queue: asyncio.Queue):
        """Remove an SSE subscriber"""
        if session_id in self._subscribers:
            try:
                self._subscribers[session_id].remove(queue)
                if not self._subscribers[session_id]:
                    del self._subscribers[session_id]
            except ValueError:
                pass
    
    async def broadcast_event(self, session_id: str, event_data: dict):
        """Broadcast event to all subscribers of a session"""
        # Add timestamp if not present
        if 'timestamp' not in event_data:
            event_data['timestamp'] = datetime.now().isoformat()
        
        # Store in history
        self._event_history[session_id].append(event_data)
        if len(self._event_history[session_id]) > self._max_history_size:
            self._event_history[session_id].pop(0)
        
        # Broadcast to subscribers
        if session_id in self._subscribers:
            dead_queues = []
            event_str = f"data: {json.dumps(event_data)}\n\n"
            
            for queue in self._subscribers[session_id]:
                try:
                    # Non-blocking put with timeout
                    await asyncio.wait_for(
                        queue.put(event_str),
                        timeout=1.0
                    )
                except (asyncio.TimeoutError, asyncio.QueueFull):
                    dead_queues.append(queue)
            
            # Clean up dead queues
            for queue in dead_queues:
                await self.remove_subscriber(session_id, queue)
    
    def get_stats(self) -> dict:
        """Get broadcaster statistics"""
        return {
            "totalSessions": len(self._subscribers),
            "totalSubscribers": sum(len(queues) for queues in self._subscribers.values()),
            "sessionStats": {
                session_id: {
                    "subscribers": len(queues),
                    "historySize": len(self._event_history.get(session_id, []))
                }
                for session_id, queues in self._subscribers.items()
            }
        }

# Global broadcaster instance
sse_broadcaster = EnhancedSSEBroadcaster()

async def agent_network_event_stream(session_id: str):
    """SSE stream generator for agent network events"""
    queue = await sse_broadcaster.add_subscriber(session_id)
    
    try:
        while True:
            event = await queue.get()
            yield event
    except asyncio.CancelledError:
        pass
    finally:
        await sse_broadcaster.remove_subscriber(session_id, queue)
```

### 1.2 Fix Agent Network SSE Endpoint
```python
# app/server.py - UPDATE EXISTING ENDPOINT

@app.get("/agent_network_sse/{session_id}")
async def agent_network_sse(session_id: str) -> StreamingResponse:
    """Fixed SSE endpoint that properly streams agent events"""
    
    async def event_generator():
        """Generate SSE events for the session"""
        queue = await sse_broadcaster.add_subscriber(session_id)
        
        try:
            # Send initial connection event
            yield f"data: {json.dumps({'type': 'connection', 'status': 'connected'})}\n\n"
            
            while True:
                try:
                    # Wait for events with timeout to send heartbeat
                    event = await asyncio.wait_for(queue.get(), timeout=30)
                    yield event
                except asyncio.TimeoutError:
                    # Send heartbeat to keep connection alive
                    yield f"data: {json.dumps({'type': 'heartbeat', 'timestamp': datetime.now().isoformat()})}\n\n"
                    
        except asyncio.CancelledError:
            pass
        finally:
            await sse_broadcaster.remove_subscriber(session_id, queue)
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Disable nginx buffering
        }
    )
```

---

## 🔌 PHASE 2: Agent Callback Integration (Priority: HIGH)

### 2.1 Connect Callbacks to SSE
```python
# app/enhanced_callbacks.py - UPDATE EXISTING

from app.utils.sse_broadcaster import sse_broadcaster
import asyncio

def before_agent_callback(callback_context: CallbackContext) -> None:
    """Enhanced callback that broadcasts to SSE"""
    try:
        ctx = callback_context._invocation_context
        session = ctx.session
        agent = ctx.agent
        
        if not session or not agent:
            return
        
        # Prepare event data (using camelCase for frontend)
        event = {
            "type": "agent_start",
            "data": {
                "agentId": f"agent_{agent.name}_{datetime.now().timestamp()}",
                "agentName": agent.name,
                "agentType": agent.__class__.__name__,
                "action": "Starting",
                "status": "active",
                "timestamp": datetime.now().isoformat(),
                "sessionId": session.id if hasattr(session, 'id') else None
            }
        }
        
        # Broadcast using asyncio
        if hasattr(session, 'id'):
            asyncio.create_task(
                sse_broadcaster.broadcast_event(session.id, event)
            )
        
        # Track in network state
        agent_network_tracking_callback(callback_context)
        
    except Exception as e:
        logger.error(f"Error in before_agent_callback: {e}", exc_info=True)

def after_agent_callback(callback_context: CallbackContext) -> None:
    """Enhanced after callback with results broadcasting"""
    try:
        ctx = callback_context._invocation_context
        session = ctx.session
        agent = ctx.agent
        
        if not session or not agent:
            return
        
        # Get execution time if available
        execution_time = None
        if hasattr(callback_context, 'start_time'):
            execution_time = (datetime.now() - callback_context.start_time).total_seconds()
        
        # Prepare completion event
        event = {
            "type": "agent_complete",
            "data": {
                "agentName": agent.name,
                "status": "complete",
                "executionTime": execution_time,
                "timestamp": datetime.now().isoformat(),
                "sessionId": session.id if hasattr(session, 'id') else None,
                "hasOutput": bool(callback_context.response) if hasattr(callback_context, 'response') else False
            }
        }
        
        # Broadcast completion
        if hasattr(session, 'id'):
            asyncio.create_task(
                sse_broadcaster.broadcast_event(session.id, event)
            )
        
    except Exception as e:
        logger.error(f"Error in after_agent_callback: {e}", exc_info=True)

def composite_after_agent_callback_with_research_sources(
    callback_context: CallbackContext,
) -> None:
    """Existing callback - add SSE broadcasting"""
    # Your existing logic...
    collect_research_sources_callback(callback_context)
    
    # ADD: Broadcast research sources
    try:
        session = callback_context._invocation_context.session
        if session and hasattr(session, 'id'):
            sources = callback_context.state.get("sources", {})
            if sources:
                event = {
                    "type": "research_sources",
                    "data": {
                        "sources": list(sources.values()),
                        "timestamp": datetime.now().isoformat()
                    }
                }
                asyncio.create_task(
                    sse_broadcaster.broadcast_event(session.id, event)
                )
    except Exception as e:
        logger.error(f"Error broadcasting sources: {e}")
```

### 2.2 Add Progress Tracking
```python
# app/utils/agent_progress.py - CREATE NEW

from typing import Dict, Optional
from datetime import datetime
import asyncio

class AgentProgressTracker:
    """Track and broadcast agent progress updates"""
    
    def __init__(self, session_id: str, agent_name: str):
        self.session_id = session_id
        self.agent_name = agent_name
        self.start_time = datetime.now()
        self.steps_completed = 0
        self.total_steps = 0
        
    async def update_progress(self, 
                              current_step: int, 
                              total_steps: int, 
                              message: str = None):
        """Send progress update via SSE"""
        self.steps_completed = current_step
        self.total_steps = total_steps
        
        progress_percent = (current_step / total_steps * 100) if total_steps > 0 else 0
        
        event = {
            "type": "agent_progress",
            "data": {
                "agentName": self.agent_name,
                "progress": round(progress_percent, 1),
                "currentStep": current_step,
                "totalSteps": total_steps,
                "message": message,
                "elapsedTime": (datetime.now() - self.start_time).total_seconds(),
                "timestamp": datetime.now().isoformat()
            }
        }
        
        await sse_broadcaster.broadcast_event(self.session_id, event)
```

---

## 🔄 PHASE 3: Response Format Standardization (Priority: HIGH)

### 3.1 Response Transformer Middleware
```python
# app/middleware/response_transformer.py - CREATE NEW

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
import json
from typing import Dict, Any, List, Union

def snake_to_camel(snake_str: str) -> str:
    """Convert snake_case to camelCase"""
    if '_' not in snake_str:
        return snake_str
    components = snake_str.split('_')
    return components[0] + ''.join(x.capitalize() for x in components[1:])

def transform_keys(obj: Any) -> Any:
    """Recursively transform dictionary keys from snake_case to camelCase"""
    if isinstance(obj, dict):
        return {
            snake_to_camel(key): transform_keys(value)
            for key, value in obj.items()
        }
    elif isinstance(obj, list):
        return [transform_keys(item) for item in obj]
    else:
        return obj

class ResponseTransformerMiddleware(BaseHTTPMiddleware):
    """Middleware to transform response keys to camelCase"""
    
    async def dispatch(self, request: Request, call_next):
        # Skip transformation for specific endpoints
        skip_paths = ['/openapi.json', '/docs', '/redoc']
        if any(request.url.path.startswith(path) for path in skip_paths):
            return await call_next(request)
        
        response = await call_next(request)
        
        # Only transform JSON responses
        if response.headers.get('content-type', '').startswith('application/json'):
            # Read response body
            body = b""
            async for chunk in response.body_iterator:
                body += chunk
            
            try:
                # Transform the response
                data = json.loads(body)
                transformed = transform_keys(data)
                
                # Create new response with transformed data
                return Response(
                    content=json.dumps(transformed),
                    status_code=response.status_code,
                    headers=dict(response.headers),
                    media_type="application/json"
                )
            except json.JSONDecodeError:
                # If not valid JSON, return original
                return Response(
                    content=body,
                    status_code=response.status_code,
                    headers=dict(response.headers)
                )
        
        return response
```

### 3.2 Update Server Configuration
```python
# app/server.py - ADD AFTER APP CREATION

from app.middleware.response_transformer import ResponseTransformerMiddleware
from fastapi.middleware.cors import CORSMiddleware

# Add CORS middleware for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",  # Vite dev server
        "http://localhost:3000",  # Alternative dev port
        "http://localhost:8000",  # Backend URL
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

# Add response transformer middleware
app.add_middleware(ResponseTransformerMiddleware)

# Fix session endpoint responses
@app.post("/apps/{app_name}/users/{user_id}/sessions")
async def create_session_override(app_name: str, user_id: str):
    """Override to ensure camelCase response"""
    # Call original ADK endpoint
    session = await create_session_original(app_name, user_id)
    
    # Ensure camelCase format
    return {
        "sessionId": session.get("session_id", session.get("sessionId")),
        "userId": user_id,
        "appName": app_name,
        "createdAt": datetime.now().isoformat(),
        "lastActivity": datetime.now().isoformat(),
        "status": "active"
    }
```

---

## 🧹 PHASE 4: Session Management & Cleanup (Priority: MEDIUM)

### 4.1 Enhanced Session Manager
```python
# app/utils/session_cleanup.py - CREATE NEW

import asyncio
from datetime import datetime, timedelta
from typing import Dict, Set
import logging

logger = logging.getLogger(__name__)

class SessionCleanupManager:
    """Manage session lifecycle and cleanup"""
    
    def __init__(self):
        self.active_sessions: Dict[str, datetime] = {}
        self.session_timeout = timedelta(hours=2)
        self.cleanup_interval = timedelta(minutes=15)
        self._cleanup_task: Optional[asyncio.Task] = None
        
    async def start(self):
        """Start the cleanup background task"""
        if not self._cleanup_task or self._cleanup_task.done():
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())
            logger.info("Session cleanup manager started")
    
    async def stop(self):
        """Stop the cleanup task"""
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
            logger.info("Session cleanup manager stopped")
    
    async def _cleanup_loop(self):
        """Background task for periodic cleanup"""
        while True:
            try:
                await asyncio.sleep(self.cleanup_interval.total_seconds())
                await self.cleanup_expired_sessions()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in cleanup loop: {e}")
    
    async def cleanup_expired_sessions(self):
        """Clean up sessions that have expired"""
        now = datetime.now()
        expired = []
        
        for session_id, last_activity in self.active_sessions.items():
            if (now - last_activity) > self.session_timeout:
                expired.append(session_id)
        
        for session_id in expired:
            await self.cleanup_session(session_id)
            logger.info(f"Cleaned up expired session: {session_id}")
    
    async def cleanup_session(self, session_id: str):
        """Clean up a specific session"""
        # Remove from tracking
        self.active_sessions.pop(session_id, None)
        
        # Clear SSE subscribers
        await sse_broadcaster.remove_all_subscribers(session_id)
        
        # Clear session data from memory
        # Add any additional cleanup here
        
        logger.info(f"Session {session_id} cleaned up")
    
    def touch_session(self, session_id: str):
        """Update session last activity"""
        self.active_sessions[session_id] = datetime.now()

# Global instance
session_cleanup = SessionCleanupManager()

# Add to server startup/shutdown
@app.on_event("startup")
async def startup_event():
    await session_cleanup.start()

@app.on_event("shutdown")
async def shutdown_event():
    await session_cleanup.stop()
```

---

## 🛠️ PHASE 5: Development Support (Priority: LOW)

### 5.1 Debug Endpoints
```python
# app/routes/debug.py - CREATE NEW

from fastapi import APIRouter, HTTPException
from app.utils.sse_broadcaster import sse_broadcaster
from app.utils.session_cleanup import session_cleanup
import os

debug_router = APIRouter(prefix="/api/debug", tags=["debug"])

@debug_router.get("/health")
async def comprehensive_health():
    """Comprehensive health check"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "environment": os.getenv("ENVIRONMENT", "development"),
        "adkStatus": "active",
        "sseStats": sse_broadcaster.get_stats(),
        "activeSessions": len(session_cleanup.active_sessions),
        "pythonVersion": sys.version,
    }

@debug_router.get("/sse/test/{session_id}")
async def test_sse_broadcast(session_id: str):
    """Test SSE broadcasting for a session"""
    test_event = {
        "type": "test",
        "data": {
            "message": "Test broadcast",
            "timestamp": datetime.now().isoformat()
        }
    }
    
    await sse_broadcaster.broadcast_event(session_id, test_event)
    return {"status": "broadcast sent", "sessionId": session_id}

@debug_router.post("/session/{session_id}/cleanup")
async def force_cleanup_session(session_id: str):
    """Force cleanup a session (dev only)"""
    if os.getenv("ENVIRONMENT") == "production":
        raise HTTPException(status_code=403, detail="Not available in production")
    
    await session_cleanup.cleanup_session(session_id)
    return {"status": "cleaned", "sessionId": session_id}

# Add to main app
app.include_router(debug_router)
```

---

## 📅 Implementation Timeline

### Week 1: Critical Fixes
- **Day 1-2:** SSE Broadcasting implementation
- **Day 3-4:** Agent callback integration
- **Day 5:** Testing and validation

### Week 2: Standardization
- **Day 1-2:** Response transformer middleware
- **Day 3-4:** Session management
- **Day 5:** Integration testing

### Week 3: Polish & Deploy
- **Day 1-2:** Development support endpoints
- **Day 3-4:** Performance optimization
- **Day 5:** Production deployment

---

## 🧪 Testing Strategy

### Unit Tests
```python
# tests/test_sse_broadcaster.py
import pytest
import asyncio
from app.utils.sse_broadcaster import EnhancedSSEBroadcaster

@pytest.mark.asyncio
async def test_broadcast_to_session():
    broadcaster = EnhancedSSEBroadcaster()
    
    # Add subscriber
    queue = await broadcaster.add_subscriber("test-session")
    
    # Broadcast event
    await broadcaster.broadcast_event("test-session", {"type": "test"})
    
    # Verify received
    event = await asyncio.wait_for(queue.get(), timeout=1)
    assert "test" in event

@pytest.mark.asyncio
async def test_camelcase_transformation():
    from app.middleware.response_transformer import transform_keys
    
    input_data = {"user_id": "123", "session_id": "456"}
    output = transform_keys(input_data)
    
    assert output == {"userId": "123", "sessionId": "456"}
```

### Integration Tests
```bash
# Test SSE streaming
curl -N http://localhost:8000/agent_network_sse/test-session

# Test response format
curl http://localhost:8000/apps/app/users/test/sessions \
  -X POST \
  -H "Content-Type: application/json" | jq .
```

---

## 🚀 Deployment Strategy

### Environment Variables
```bash
# .env.development
ENVIRONMENT=development
ENABLE_DEBUG_ENDPOINTS=true
SSE_HEARTBEAT_INTERVAL=30
SESSION_TIMEOUT_HOURS=2
CORS_ORIGINS=http://localhost:5173,http://localhost:3000

# .env.production
ENVIRONMENT=production
ENABLE_DEBUG_ENDPOINTS=false
SSE_HEARTBEAT_INTERVAL=60
SESSION_TIMEOUT_HOURS=24
CORS_ORIGINS=https://vana.yourdomain.com
```

### Docker Updates
```dockerfile
# Dockerfile - Add health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:8000/health || exit 1
```

### Rollback Plan
1. **Feature flags** for gradual rollout
2. **Database backups** before deployment
3. **Blue-green deployment** for zero downtime
4. **Monitoring alerts** for error rates

---

## ✅ Success Criteria

### Performance Metrics
- ✅ SSE event latency < 100ms
- ✅ Zero dropped events during normal operation
- ✅ Memory usage stable over 24 hours
- ✅ API response time < 200ms

### Functional Requirements
- ✅ All agent events broadcast to correct sessions
- ✅ 100% of API responses in camelCase format
- ✅ Expired sessions cleaned within 15 minutes
- ✅ Development endpoints functional

### Quality Metrics
- ✅ 90% test coverage for new code
- ✅ Zero critical security vulnerabilities
- ✅ Complete API documentation
- ✅ Error rate < 0.1%

---

## 📝 Migration Checklist

- [ ] Backup current deployment
- [ ] Update environment variables
- [ ] Deploy Phase 1 (SSE fixes)
- [ ] Validate SSE broadcasting
- [ ] Deploy Phase 2 (Callbacks)
- [ ] Test agent event flow
- [ ] Deploy Phase 3 (Response format)
- [ ] Validate frontend compatibility
- [ ] Deploy Phase 4 (Session management)
- [ ] Monitor memory usage
- [ ] Deploy Phase 5 (Dev support)
- [ ] Complete integration testing
- [ ] Update documentation
- [ ] Train team on new features

---

## 🔍 Monitoring & Alerts

### Key Metrics to Monitor
```python
# app/utils/metrics.py
from prometheus_client import Counter, Histogram, Gauge

# SSE metrics
sse_events_sent = Counter('sse_events_sent_total', 'Total SSE events sent')
sse_subscribers = Gauge('sse_subscribers_active', 'Active SSE subscribers')
sse_broadcast_duration = Histogram('sse_broadcast_duration_seconds', 'SSE broadcast duration')

# Session metrics
active_sessions = Gauge('sessions_active', 'Active sessions')
session_cleanup_total = Counter('session_cleanup_total', 'Total sessions cleaned')

# Agent metrics
agent_executions = Counter('agent_executions_total', 'Total agent executions', ['agent_name'])
agent_duration = Histogram('agent_duration_seconds', 'Agent execution duration', ['agent_name'])
```

---

This plan provides a complete, actionable roadmap for updating the backend to support the new frontend architecture while maintaining system stability and ADK compliance.