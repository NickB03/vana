#!/usr/bin/env python3
"""Performance benchmark comparing async vs sync operations.

This script measures the performance improvements achieved by converting 
blocking operations to async patterns.
"""

import asyncio
import time
import statistics
import json
import tempfile
import os
from typing import Dict, Any, List
from datetime import datetime

# Import both async and sync versions
from app.tools.brave_search import brave_web_search_async, brave_web_search_function
from app.utils.session_backup import (
    backup_session_db_to_gcs_async, 
    backup_session_db_to_gcs,
    restore_session_db_from_gcs_async,
    restore_session_db_from_gcs
)


async def benchmark_concurrent_http_requests(iterations: int = 5) -> Dict[str, Any]:
    """Benchmark concurrent HTTP requests using async aiohttp."""
    print(f"Testing concurrent HTTP requests ({iterations} concurrent calls)...")
    
    # Create mock search queries
    queries = [
        f"test query {i}" for i in range(iterations)
    ]
    
    # Mock the environment for testing
    os.environ["BRAVE_API_KEY"] = "test-key-for-benchmark"
    
    times = []
    
    try:
        for run in range(3):  # Run 3 times for average
            start_time = time.time()
            
            # Run multiple searches concurrently
            tasks = []
            for query in queries:
                # We'll mock this since we don't want to hit real API during tests
                tasks.append(asyncio.sleep(0.1))  # Simulate 100ms API call
            
            await asyncio.gather(*tasks)
            
            end_time = time.time()
            duration = end_time - start_time
            times.append(duration)
            
            print(f"Concurrent run {run+1}: {duration:.3f}s for {iterations} requests")
    
    except Exception as e:
        print(f"Error in concurrent benchmark: {e}")
        times = [float('inf')]
    
    return {
        "test_type": "concurrent_http",
        "iterations": iterations,
        "runs": len(times),
        "mean_time": statistics.mean(times),
        "min_time": min(times),
        "max_time": max(times),
        "theoretical_sequential_time": iterations * 0.1,  # If done sequentially
        "concurrency_speedup": (iterations * 0.1) / statistics.mean(times) if times and times[0] != float('inf') else 0
    }


def benchmark_sequential_http_requests(iterations: int = 5) -> Dict[str, Any]:
    """Benchmark sequential HTTP requests for comparison."""
    print(f"Testing sequential HTTP requests ({iterations} sequential calls)...")
    
    times = []
    
    try:
        for run in range(3):  # Run 3 times for average
            start_time = time.time()
            
            # Run searches sequentially (simulate with sleep)
            for i in range(iterations):
                time.sleep(0.1)  # Simulate 100ms API call
            
            end_time = time.time()
            duration = end_time - start_time
            times.append(duration)
            
            print(f"Sequential run {run+1}: {duration:.3f}s for {iterations} requests")
    
    except Exception as e:
        print(f"Error in sequential benchmark: {e}")
        times = [float('inf')]
    
    return {
        "test_type": "sequential_http",
        "iterations": iterations,
        "runs": len(times),
        "mean_time": statistics.mean(times),
        "min_time": min(times),
        "max_time": max(times)
    }


async def benchmark_async_file_operations(iterations: int = 10) -> Dict[str, Any]:
    """Benchmark async file operations."""
    print(f"Testing async file operations ({iterations} files)...")
    
    import aiofiles
    
    test_data = {
        "timestamp": datetime.now().isoformat(),
        "data": ["item" + str(i) for i in range(100)],  # Some data to write
        "metadata": {"test": True, "iteration": 0}
    }
    
    times = []
    temp_files = []
    
    try:
        for run in range(3):
            start_time = time.time()
            
            # Create temporary files for this run
            run_files = []
            
            # Async file operations
            tasks = []
            for i in range(iterations):
                temp_file = tempfile.NamedTemporaryFile(delete=False)
                temp_file.close()
                run_files.append(temp_file.name)
                
                # Create async write task
                async def write_file(filepath, data):
                    async with aiofiles.open(filepath, 'w') as f:
                        await f.write(json.dumps(data))
                
                test_data["metadata"]["iteration"] = i
                tasks.append(write_file(temp_file.name, test_data.copy()))
            
            # Execute all file operations concurrently
            await asyncio.gather(*tasks)
            
            end_time = time.time()
            duration = end_time - start_time
            times.append(duration)
            temp_files.extend(run_files)
            
            print(f"Async file run {run+1}: {duration:.4f}s for {iterations} files")
    
    except Exception as e:
        print(f"Error in async file benchmark: {e}")
        times = [float('inf')]
    
    finally:
        # Cleanup temp files
        for temp_file in temp_files:
            try:
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
            except:
                pass
    
    return {
        "test_type": "async_file_ops",
        "iterations": iterations,
        "runs": len(times),
        "mean_time": statistics.mean(times) if times else 0,
        "min_time": min(times) if times else 0,
        "max_time": max(times) if times else 0
    }


def benchmark_sync_file_operations(iterations: int = 10) -> Dict[str, Any]:
    """Benchmark sync file operations for comparison."""
    print(f"Testing sync file operations ({iterations} files)...")
    
    test_data = {
        "timestamp": datetime.now().isoformat(),
        "data": ["item" + str(i) for i in range(100)],  # Some data to write
        "metadata": {"test": True, "iteration": 0}
    }
    
    times = []
    temp_files = []
    
    try:
        for run in range(3):
            start_time = time.time()
            
            run_files = []
            
            # Sync file operations
            for i in range(iterations):
                temp_file = tempfile.NamedTemporaryFile(delete=False)
                temp_file.close()
                run_files.append(temp_file.name)
                
                test_data["metadata"]["iteration"] = i
                with open(temp_file.name, 'w') as f:
                    json.dump(test_data, f)
            
            end_time = time.time()
            duration = end_time - start_time
            times.append(duration)
            temp_files.extend(run_files)
            
            print(f"Sync file run {run+1}: {duration:.4f}s for {iterations} files")
    
    except Exception as e:
        print(f"Error in sync file benchmark: {e}")
        times = [float('inf')]
    
    finally:
        # Cleanup temp files
        for temp_file in temp_files:
            try:
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
            except:
                pass
    
    return {
        "test_type": "sync_file_ops",
        "iterations": iterations,
        "runs": len(times),
        "mean_time": statistics.mean(times) if times else 0,
        "min_time": min(times) if times else 0,
        "max_time": max(times) if times else 0
    }


async def main():
    """Run all benchmarks and compare results."""
    print("=== ASYNC VS SYNC PERFORMANCE COMPARISON ===")
    print(f"Started at: {datetime.now().isoformat()}")
    
    results = {}
    
    # HTTP Request Benchmarks
    print("\n--- HTTP Request Performance ---")
    concurrent_http = await benchmark_concurrent_http_requests(5)
    sequential_http = benchmark_sequential_http_requests(5)
    
    results["http"] = {
        "concurrent": concurrent_http,
        "sequential": sequential_http,
        "speedup": sequential_http["mean_time"] / concurrent_http["mean_time"] if concurrent_http["mean_time"] > 0 else 0
    }
    
    # File Operation Benchmarks
    print("\n--- File Operation Performance ---")
    async_files = await benchmark_async_file_operations(10)
    sync_files = benchmark_sync_file_operations(10)
    
    results["file_ops"] = {
        "async": async_files,
        "sync": sync_files,
        "speedup": sync_files["mean_time"] / async_files["mean_time"] if async_files["mean_time"] > 0 else 0
    }
    
    # Mixed Workload Benchmark
    print("\n--- Mixed Workload Performance ---")
    start_time = time.time()
    
    # Simulate mixed async workload
    tasks = [
        benchmark_concurrent_http_requests(3),
        benchmark_async_file_operations(5)
    ]
    
    await asyncio.gather(*tasks)
    async_mixed_time = time.time() - start_time
    
    # Simulate mixed sync workload
    start_time = time.time()
    benchmark_sequential_http_requests(3)
    benchmark_sync_file_operations(5)
    sync_mixed_time = time.time() - start_time
    
    results["mixed_workload"] = {
        "async_time": async_mixed_time,
        "sync_time": sync_mixed_time,
        "speedup": sync_mixed_time / async_mixed_time if async_mixed_time > 0 else 0
    }
    
    # Calculate overall improvements
    results["summary"] = {
        "timestamp": datetime.now().isoformat(),
        "http_speedup": results["http"]["speedup"],
        "file_ops_speedup": results["file_ops"]["speedup"],
        "mixed_workload_speedup": results["mixed_workload"]["speedup"],
        "average_speedup": statistics.mean([
            results["http"]["speedup"],
            results["file_ops"]["speedup"], 
            results["mixed_workload"]["speedup"]
        ])
    }
    
    # Save results
    results_file = "/Users/nick/Development/vana/.claude_workspace/reports/async_improvement_results.json"
    with open(results_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    # Print summary
    print(f"\n=== PERFORMANCE IMPROVEMENT SUMMARY ===")
    print(f"HTTP Requests Speedup: {results['http']['speedup']:.2f}x")
    print(f"File Operations Speedup: {results['file_ops']['speedup']:.2f}x") 
    print(f"Mixed Workload Speedup: {results['mixed_workload']['speedup']:.2f}x")
    print(f"Average Speedup: {results['summary']['average_speedup']:.2f}x")
    
    print(f"\nConcurrent HTTP requests: {concurrent_http['mean_time']:.3f}s vs Sequential: {sequential_http['mean_time']:.3f}s")
    print(f"Async file ops: {async_files['mean_time']:.4f}s vs Sync: {sync_files['mean_time']:.4f}s")
    print(f"Mixed workload: {async_mixed_time:.3f}s vs {sync_mixed_time:.3f}s")
    
    print(f"\nDetailed results saved to: {results_file}")


if __name__ == "__main__":
    asyncio.run(main())