#!/usr/bin/env python3
"""Performance benchmark for async conversion testing.

This script measures the performance impact of converting blocking operations to async.
Run this before and after async conversions to measure improvements.
"""

import asyncio
import time
import statistics
from typing import List, Dict, Any
import httpx
import json
from datetime import datetime


async def benchmark_http_performance(iterations: int = 10) -> Dict[str, Any]:
    """Benchmark HTTP performance using async httpx."""
    print(f"Running HTTP benchmark with {iterations} iterations...")
    
    # Test URLs (using httpbin for testing)
    test_urls = [
        "https://httpbin.org/delay/1",  # 1 second delay
        "https://httpbin.org/json",     # JSON response
        "https://httpbin.org/get",      # GET request
    ]
    
    times = []
    
    async with httpx.AsyncClient(timeout=30.0) as client:
        for i in range(iterations):
            start_time = time.time()
            
            # Simulate multiple concurrent requests (like brave search)
            tasks = []
            for url in test_urls:
                tasks.append(client.get(url))
            
            try:
                responses = await asyncio.gather(*tasks)
                success = all(r.status_code == 200 for r in responses)
            except Exception as e:
                print(f"Error in iteration {i}: {e}")
                success = False
            
            end_time = time.time()
            duration = end_time - start_time
            times.append(duration)
            
            if success:
                print(f"Iteration {i+1}: {duration:.3f}s ✓")
            else:
                print(f"Iteration {i+1}: {duration:.3f}s ✗")
    
    return {
        "mean_time": statistics.mean(times),
        "median_time": statistics.median(times),
        "min_time": min(times),
        "max_time": max(times),
        "std_dev": statistics.stdev(times) if len(times) > 1 else 0,
        "total_requests": len(test_urls) * iterations,
        "iterations": iterations
    }


async def benchmark_file_operations(iterations: int = 10) -> Dict[str, Any]:
    """Benchmark file I/O operations (simulated for session backup)."""
    print(f"Running file I/O benchmark with {iterations} iterations...")
    
    test_data = {
        "timestamp": datetime.now().isoformat(),
        "session_data": {"test": "data", "numbers": list(range(1000))},
        "metadata": {"version": "1.0", "type": "benchmark"}
    }
    
    times = []
    
    for i in range(iterations):
        start_time = time.time()
        
        # Simulate file operations
        try:
            # Write test data
            filename = f"/tmp/benchmark_test_{i}.json"
            with open(filename, 'w') as f:
                json.dump(test_data, f)
            
            # Read test data back
            with open(filename, 'r') as f:
                loaded_data = json.load(f)
            
            # Clean up
            import os
            os.remove(filename)
            
            success = loaded_data == test_data
        except Exception as e:
            print(f"Error in file operation {i}: {e}")
            success = False
        
        end_time = time.time()
        duration = end_time - start_time
        times.append(duration)
        
        if success:
            print(f"File operation {i+1}: {duration:.4f}s ✓")
        else:
            print(f"File operation {i+1}: {duration:.4f}s ✗")
    
    return {
        "mean_time": statistics.mean(times),
        "median_time": statistics.median(times),
        "min_time": min(times),
        "max_time": max(times),
        "std_dev": statistics.stdev(times) if len(times) > 1 else 0,
        "iterations": iterations
    }


async def main():
    """Run all benchmarks and save results."""
    print("=== ASYNC PERFORMANCE BENCHMARK ===")
    print(f"Started at: {datetime.now().isoformat()}")
    
    # Run HTTP benchmark
    print("\n--- HTTP Performance ---")
    http_results = await benchmark_http_performance(5)
    
    # Run file I/O benchmark  
    print("\n--- File I/O Performance ---")
    file_results = await benchmark_file_operations(10)
    
    # Compile results
    results = {
        "timestamp": datetime.now().isoformat(),
        "http_performance": http_results,
        "file_io_performance": file_results,
        "summary": {
            "http_mean_time": http_results["mean_time"],
            "file_mean_time": file_results["mean_time"],
            "total_benchmark_time": time.time()
        }
    }
    
    # Save results
    results_file = "/Users/nick/Development/vana/.claude_workspace/reports/async_benchmark_baseline.json"
    with open(results_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n=== BENCHMARK RESULTS ===")
    print(f"HTTP Operations:")
    print(f"  Mean time: {http_results['mean_time']:.3f}s")
    print(f"  Median time: {http_results['median_time']:.3f}s")
    print(f"  Min/Max: {http_results['min_time']:.3f}s / {http_results['max_time']:.3f}s")
    
    print(f"\nFile Operations:")
    print(f"  Mean time: {file_results['mean_time']:.4f}s")
    print(f"  Median time: {file_results['median_time']:.4f}s")
    print(f"  Min/Max: {file_results['min_time']:.4f}s / {file_results['max_time']:.4f}s")
    
    print(f"\nResults saved to: {results_file}")


if __name__ == "__main__":
    asyncio.run(main())