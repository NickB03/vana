#!/usr/bin/env python3
"""Simple test to validate memory leak fixes."""

import asyncio
import time
import gc
import psutil
import os
from app.utils.sse_broadcaster_fixed import EnhancedSSEBroadcaster, BroadcasterConfig

async def test_memory_leak_fixes():
    """Test that memory fixes work correctly."""
    print("🔧 Testing Memory Leak Fixes")
    print("=" * 50)
    
    # Get initial memory
    process = psutil.Process(os.getpid())
    initial_memory = process.memory_info().rss / (1024 * 1024)
    print(f"Initial memory: {initial_memory:.2f} MB")
    
    # Create broadcaster with aggressive cleanup for testing
    config = BroadcasterConfig(
        max_queue_size=50,
        max_history_per_session=100,
        event_ttl=2.0,  # 2 seconds
        session_ttl=10.0,  # 10 seconds
        cleanup_interval=1.0,  # 1 second
        enable_metrics=True
    )
    
    broadcaster = EnhancedSSEBroadcaster(config)
    
    try:
        print("\n📊 Test 1: Bounded History")
        print("-" * 30)
        
        session_id = "test_session"
        
        # Add many events (should be bounded)
        for i in range(200):  # More than max_history_per_session
            await broadcaster.broadcast_event(session_id, {
                "type": "test_event",
                "data": {"event_id": i}
            })
        
        history = broadcaster.get_event_history(session_id)
        print(f"Events generated: 200")
        print(f"History size: {len(history)} (should be ≤ {config.max_history_per_session})")
        assert len(history) <= config.max_history_per_session, f"History not bounded: {len(history)}"
        
        print("\n⏰ Test 2: TTL Expiration")
        print("-" * 30)
        
        # Generate events
        for i in range(10):
            await broadcaster.broadcast_event(session_id, {
                "type": "ttl_test",
                "data": {"event_id": i}
            })
        
        print(f"Events before TTL: {len(broadcaster.get_event_history(session_id))}")
        
        # Wait for TTL expiration
        print("Waiting for TTL expiration (3 seconds)...")
        await asyncio.sleep(3.0)
        
        # Force cleanup
        await broadcaster._perform_cleanup()
        
        history_after = broadcaster.get_event_history(session_id)
        print(f"Events after TTL cleanup: {len(history_after)}")
        assert len(history_after) == 0, f"Events not expired: {len(history_after)}"
        
        print("\n🔌 Test 3: Queue Management")
        print("-" * 30)
        
        # Add subscriber
        queue = await broadcaster.add_subscriber(session_id)
        
        # Fill queue beyond capacity (should handle gracefully)
        success_count = 0
        for i in range(config.max_queue_size + 10):
            success = await queue.put(f"item_{i}", timeout=0.1)
            if success:
                success_count += 1
        
        print(f"Items accepted: {success_count}/{config.max_queue_size + 10}")
        assert success_count <= config.max_queue_size, f"Queue not bounded: {success_count}"
        
        # Clean up
        await broadcaster.remove_subscriber(session_id, queue)
        
        print("\n📈 Test 4: Memory Usage Under Load")
        print("-" * 30)
        
        # Create multiple sessions with activity
        sessions = []
        queues = []
        
        for i in range(10):
            sid = f"load_session_{i}"
            sessions.append(sid)
            q = await broadcaster.add_subscriber(sid)
            queues.append((sid, q))
        
        # Generate load
        for session_id in sessions:
            for j in range(50):
                await broadcaster.broadcast_event(session_id, {
                    "type": "load_test",
                    "data": {"session": session_id, "event": j, "payload": "x" * 100}
                })
        
        current_memory = process.memory_info().rss / (1024 * 1024)
        print(f"Memory under load: {current_memory:.2f} MB")
        
        # Get stats
        stats = broadcaster.get_stats()
        print(f"Active sessions: {stats['totalSessions']}")
        print(f"Total subscribers: {stats['totalSubscribers']}")
        print(f"Total events: {stats['totalEvents']}")
        
        # Clean up subscribers
        for session_id, queue in queues:
            await broadcaster.remove_subscriber(session_id, queue)
        
        # Wait for cleanup cycles
        await asyncio.sleep(3.0)
        
        # Force multiple cleanups
        for _ in range(3):
            await broadcaster._perform_cleanup()
            await asyncio.sleep(0.1)
        
        # Check final memory
        final_memory = process.memory_info().rss / (1024 * 1024)
        memory_increase = final_memory - initial_memory
        
        print(f"\n📊 Memory Summary:")
        print(f"Initial:  {initial_memory:.2f} MB")
        print(f"Peak:     {current_memory:.2f} MB")
        print(f"Final:    {final_memory:.2f} MB")
        print(f"Increase: {memory_increase:.2f} MB")
        
        # Final stats
        final_stats = broadcaster.get_stats()
        print(f"\n📈 Final Stats:")
        print(f"Sessions: {final_stats['totalSessions']}")
        print(f"Subscribers: {final_stats['totalSubscribers']}")
        print(f"Events: {final_stats['totalEvents']}")
        print(f"Cleanup count: {final_stats['metrics']['cleanup_count']}")
        print(f"Events cleaned: {final_stats['metrics']['expired_events_cleaned']}")
        print(f"Queues cleaned: {final_stats['metrics']['dead_queues_cleaned']}")
        
        # Memory increase should be reasonable (less than 20MB for this test)
        max_acceptable_increase = 20.0
        if memory_increase < max_acceptable_increase:
            print(f"✅ Memory leak prevention: PASSED ({memory_increase:.2f}MB < {max_acceptable_increase}MB)")
        else:
            print(f"❌ Memory leak prevention: FAILED ({memory_increase:.2f}MB ≥ {max_acceptable_increase}MB)")
            return False
            
    finally:
        await broadcaster.shutdown()
    
    print("\n🎉 All Memory Leak Tests Passed!")
    return True

if __name__ == "__main__":
    success = asyncio.run(test_memory_leak_fixes())
    if not success:
        exit(1)