#!/usr/bin/env python3
"""Simple test for memory fixes without psutil warnings."""

import asyncio
from app.utils.sse_broadcaster_fixed import EnhancedSSEBroadcaster, BroadcasterConfig

async def test_bounded_history():
    """Test that event history is properly bounded."""
    print("🔧 Testing Bounded History")
    
    config = BroadcasterConfig(
        max_history_per_session=50,
        event_ttl=None,  # Disable TTL for this test
        cleanup_interval=999999,  # Disable background cleanup
        enable_metrics=False  # Disable memory monitoring to avoid psutil
    )
    
    broadcaster = EnhancedSSEBroadcaster(config)
    
    try:
        session_id = "test_session"
        
        # Add 100 events (more than max_history_per_session)
        for i in range(100):
            await broadcaster.broadcast_event(session_id, {
                "type": "test_event",
                "data": {"event_id": i}
            })
        
        history = broadcaster.get_event_history(session_id)
        print(f"✅ Generated 100 events, history size: {len(history)} (max: {config.max_history_per_session})")
        
        assert len(history) <= config.max_history_per_session, f"History not bounded: {len(history)}"
        
        # Check that we have the most recent events
        event_ids = [event.data.get("event_id") for event in history]
        assert max(event_ids) == 99, "Most recent event not in history"
        assert min(event_ids) >= 50, "Old events not properly removed"
        
        print("✅ Bounded history test passed!")
        return True
        
    finally:
        await broadcaster.shutdown()

async def test_ttl_expiration():
    """Test TTL-based event expiration."""
    print("🔧 Testing TTL Expiration")
    
    config = BroadcasterConfig(
        max_history_per_session=100,
        event_ttl=0.5,  # 0.5 second TTL
        cleanup_interval=999999,  # Manual cleanup only
        enable_metrics=False
    )
    
    broadcaster = EnhancedSSEBroadcaster(config)
    
    try:
        session_id = "test_session"
        
        # Add events
        for i in range(10):
            await broadcaster.broadcast_event(session_id, {
                "type": "ttl_test",
                "data": {"event_id": i}
            })
        
        initial_count = len(broadcaster.get_event_history(session_id))
        print(f"✅ Generated {initial_count} events")
        
        # Wait for TTL expiration
        await asyncio.sleep(0.6)
        
        # Manual cleanup
        await broadcaster._perform_cleanup()
        
        final_count = len(broadcaster.get_event_history(session_id))
        print(f"✅ After TTL cleanup: {final_count} events remaining")
        
        assert final_count == 0, f"Events not properly expired: {final_count}"
        
        print("✅ TTL expiration test passed!")
        return True
        
    finally:
        await broadcaster.shutdown()

async def test_queue_bounds():
    """Test queue size limits."""
    print("🔧 Testing Queue Bounds")
    
    config = BroadcasterConfig(
        max_queue_size=25,
        enable_metrics=False
    )
    
    broadcaster = EnhancedSSEBroadcaster(config)
    
    try:
        session_id = "test_session"
        queue = await broadcaster.add_subscriber(session_id)
        
        # Try to fill queue beyond capacity
        success_count = 0
        for i in range(50):  # Try more than max_queue_size
            success = await queue.put(f"item_{i}", timeout=0.01)
            if success:
                success_count += 1
        
        print(f"✅ Items accepted: {success_count}/{50} (max: {config.max_queue_size})")
        
        assert success_count <= config.max_queue_size, f"Queue not bounded: {success_count}"
        
        await broadcaster.remove_subscriber(session_id, queue)
        
        print("✅ Queue bounds test passed!")
        return True
        
    finally:
        await broadcaster.shutdown()

async def main():
    """Run all memory tests."""
    print("🚀 Running Memory Leak Fix Tests")
    print("=" * 50)
    
    tests = [
        test_bounded_history,
        test_ttl_expiration, 
        test_queue_bounds
    ]
    
    passed = 0
    for test in tests:
        try:
            if await test():
                passed += 1
                print()
        except Exception as e:
            print(f"❌ Test failed: {e}")
            import traceback
            traceback.print_exc()
            print()
    
    print("=" * 50)
    print(f"🎉 Tests passed: {passed}/{len(tests)}")
    
    if passed == len(tests):
        print("✅ All memory leak fixes working correctly!")
        return True
    else:
        print("❌ Some tests failed")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    if not success:
        exit(1)