#!/usr/bin/env python3
"""
Production Smoke Test - Real System Validation
==============================================

This script validates that all fixes are REAL production improvements, not test manipulations.
It performs actual system validation against running services.

Usage:
    python production_smoke_test.py
"""

import asyncio
import time
import psutil
import os
import sys
import json
import requests
import subprocess
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
import concurrent.futures
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent.parent))


@dataclass
class TestResult:
    """Test result data structure."""
    test_name: str
    passed: bool
    duration: float
    details: Dict[str, Any]
    error_message: Optional[str] = None


@dataclass
class SystemMetrics:
    """System resource metrics."""
    memory_mb: float
    cpu_percent: float
    open_files: int
    connections: int
    timestamp: float


class ProductionValidator:
    """Validates production fixes with real system tests."""
    
    def __init__(self):
        self.results: List[TestResult] = []
        self.backend_url = "http://localhost:8000"
        self.frontend_url = "http://localhost:5173"
        self.process_pids: Dict[str, int] = {}
        
    def log(self, message: str):
        """Log with timestamp."""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
        
    def get_system_metrics(self) -> SystemMetrics:
        """Get current system metrics."""
        process = psutil.Process()
        return SystemMetrics(
            memory_mb=process.memory_info().rss / (1024 * 1024),
            cpu_percent=process.cpu_percent(),
            open_files=len(process.open_files()),
            connections=len(process.connections()),
            timestamp=time.time()
        )
    
    async def start_backend_server(self) -> bool:
        """Start the backend server and verify it's running."""
        self.log("Starting backend server...")
        
        try:
            # Kill any existing process on port 8000
            try:
                subprocess.run(["pkill", "-f", "make dev-backend"], check=False)
                time.sleep(2)
            except:
                pass
            
            # Start backend
            process = subprocess.Popen(
                ["make", "dev-backend"],
                cwd=Path(__file__).parent.parent.parent,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                preexec_fn=os.setsid
            )
            
            self.process_pids["backend"] = process.pid
            
            # Wait for server to start (max 30 seconds)
            for attempt in range(30):
                try:
                    response = requests.get(f"{self.backend_url}/health", timeout=5)
                    if response.status_code == 200:
                        self.log("✅ Backend server started successfully")
                        return True
                except:
                    pass
                await asyncio.sleep(1)
            
            self.log("❌ Backend server failed to start")
            return False
            
        except Exception as e:
            self.log(f"❌ Error starting backend: {e}")
            return False
    
    async def test_memory_leak_fixes(self) -> TestResult:
        """Test SSE broadcaster memory leak fixes under real load."""
        start_time = time.time()
        self.log("🧪 Testing memory leak fixes...")
        
        try:
            initial_metrics = self.get_system_metrics()
            
            # Create multiple SSE connections and generate events
            async def create_sse_load():
                sessions = []
                for i in range(20):  # 20 concurrent sessions
                    session_id = f"test_session_{i}"
                    
                    # Start SSE connection
                    try:
                        response = requests.get(
                            f"{self.backend_url}/sse/agent-network/{session_id}",
                            stream=True,
                            timeout=30
                        )
                        
                        if response.status_code == 200:
                            sessions.append((session_id, response))
                            
                            # Generate events for this session
                            for j in range(50):
                                requests.post(
                                    f"{self.backend_url}/api/broadcast-test",
                                    json={
                                        "session_id": session_id,
                                        "event_type": "memory_test",
                                        "data": {"payload": "x" * 1000}  # 1KB payload
                                    },
                                    timeout=5
                                )
                                
                                if j % 10 == 0:
                                    await asyncio.sleep(0.1)
                                    
                    except Exception as e:
                        self.log(f"Session {session_id} error: {e}")
                        continue
                
                # Let it run for a few seconds
                await asyncio.sleep(5)
                
                # Close connections
                for session_id, response in sessions:
                    try:
                        response.close()
                    except:
                        pass
                
                return len(sessions)
            
            # Run the load test
            active_sessions = await create_sse_load()
            
            # Wait for cleanup
            await asyncio.sleep(2)
            
            # Check final metrics
            final_metrics = self.get_system_metrics()
            
            # Memory should not have grown excessively (allow 100MB growth)
            memory_growth = final_metrics.memory_mb - initial_metrics.memory_mb
            
            success = memory_growth < 100  # Less than 100MB growth
            
            return TestResult(
                test_name="memory_leak_fixes",
                passed=success,
                duration=time.time() - start_time,
                details={
                    "initial_memory_mb": initial_metrics.memory_mb,
                    "final_memory_mb": final_metrics.memory_mb,
                    "memory_growth_mb": memory_growth,
                    "active_sessions": active_sessions,
                    "success_threshold_mb": 100
                },
                error_message=None if success else f"Memory grew by {memory_growth:.1f}MB (threshold: 100MB)"
            )
            
        except Exception as e:
            return TestResult(
                test_name="memory_leak_fixes",
                passed=False,
                duration=time.time() - start_time,
                details={},
                error_message=str(e)
            )
    
    async def test_authentication_security(self) -> TestResult:
        """Test real authentication security implementation."""
        start_time = time.time()
        self.log("🔐 Testing authentication security...")
        
        try:
            tests = []
            
            # Test 1: Password requirements
            weak_passwords = ["123", "password", "abc123", "PASSWORD", "Pass123"]
            
            for weak_pass in weak_passwords:
                response = requests.post(
                    f"{self.backend_url}/auth/register",
                    json={
                        "email": f"test_{weak_pass}@example.com",
                        "username": f"test_{weak_pass}",
                        "password": weak_pass,
                        "first_name": "Test",
                        "last_name": "User"
                    },
                    timeout=10
                )
                
                # Should reject weak passwords
                if response.status_code != 400:
                    tests.append(("weak_password_rejection", False, f"Accepted weak password: {weak_pass}"))
                else:
                    tests.append(("weak_password_rejection", True, f"Correctly rejected: {weak_pass}"))
            
            # Test 2: Create a valid user and test authentication
            valid_user = {
                "email": "test_auth_user@example.com",
                "username": "test_auth_user",
                "password": "ValidPass123!",
                "first_name": "Test",
                "last_name": "User"
            }
            
            # Register user
            register_response = requests.post(
                f"{self.backend_url}/auth/register",
                json=valid_user,
                timeout=10
            )
            
            if register_response.status_code == 201:
                tests.append(("valid_user_creation", True, "User created successfully"))
                
                # Test login
                login_response = requests.post(
                    f"{self.backend_url}/auth/login",
                    json={
                        "username": valid_user["username"],
                        "password": valid_user["password"]
                    },
                    timeout=10
                )
                
                if login_response.status_code == 200:
                    token_data = login_response.json()
                    access_token = token_data.get("access_token")
                    
                    if access_token:
                        tests.append(("login_success", True, "Login successful"))
                        
                        # Test protected endpoint
                        protected_response = requests.get(
                            f"{self.backend_url}/auth/me",
                            headers={"Authorization": f"Bearer {access_token}"},
                            timeout=10
                        )
                        
                        if protected_response.status_code == 200:
                            tests.append(("protected_endpoint", True, "Protected endpoint accessible"))
                        else:
                            tests.append(("protected_endpoint", False, f"Protected endpoint failed: {protected_response.status_code}"))
                    else:
                        tests.append(("token_generation", False, "No access token returned"))
                else:
                    tests.append(("login_success", False, f"Login failed: {login_response.status_code}"))
            else:
                tests.append(("valid_user_creation", False, f"User creation failed: {register_response.status_code}"))
            
            # Test 3: Test unauthorized access
            unauth_response = requests.get(f"{self.backend_url}/auth/me", timeout=10)
            if unauth_response.status_code == 401:
                tests.append(("unauthorized_protection", True, "Unauthorized access properly blocked"))
            else:
                tests.append(("unauthorized_protection", False, f"Unauthorized access allowed: {unauth_response.status_code}"))
            
            # Evaluate results
            passed_tests = sum(1 for _, passed, _ in tests if passed)
            total_tests = len(tests)
            
            success = passed_tests == total_tests
            
            return TestResult(
                test_name="authentication_security",
                passed=success,
                duration=time.time() - start_time,
                details={
                    "total_tests": total_tests,
                    "passed_tests": passed_tests,
                    "test_results": tests
                },
                error_message=None if success else f"Failed {total_tests - passed_tests}/{total_tests} tests"
            )
            
        except Exception as e:
            return TestResult(
                test_name="authentication_security",
                passed=False,
                duration=time.time() - start_time,
                details={},
                error_message=str(e)
            )
    
    async def test_async_performance(self) -> TestResult:
        """Test real async performance improvements."""
        start_time = time.time()
        self.log("⚡ Testing async performance improvements...")
        
        try:
            # Test 1: Concurrent requests to async endpoints
            concurrent_requests = 50
            
            async def make_request(session_id: int):
                try:
                    # Simulate search request (should be async now)
                    response = requests.post(
                        f"{self.backend_url}/api/search-test",
                        json={
                            "query": f"test query {session_id}",
                            "session_id": str(session_id)
                        },
                        timeout=30
                    )
                    return response.status_code == 200, time.time()
                except Exception as e:
                    return False, time.time()
            
            # Measure concurrent performance
            test_start = time.time()
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=concurrent_requests) as executor:
                futures = [executor.submit(lambda i=i: asyncio.run(make_request(i))) 
                          for i in range(concurrent_requests)]
                results = [future.result() for future in concurrent.futures.as_completed(futures)]
            
            total_time = time.time() - test_start
            successful_requests = sum(1 for success, _ in results if success)
            
            # Performance should be reasonable for concurrent requests
            # If truly async, should complete much faster than sequential
            expected_max_time = 10  # 10 seconds for 50 requests should be plenty
            performance_good = total_time < expected_max_time
            
            return TestResult(
                test_name="async_performance",
                passed=performance_good and successful_requests >= concurrent_requests * 0.8,  # 80% success rate
                duration=time.time() - start_time,
                details={
                    "concurrent_requests": concurrent_requests,
                    "successful_requests": successful_requests,
                    "total_time_seconds": total_time,
                    "expected_max_time": expected_max_time,
                    "performance_good": performance_good,
                    "average_time_per_request": total_time / concurrent_requests
                },
                error_message=None if (performance_good and successful_requests >= concurrent_requests * 0.8) 
                              else f"Performance issues: {total_time:.2f}s for {concurrent_requests} requests"
            )
            
        except Exception as e:
            return TestResult(
                test_name="async_performance", 
                passed=False,
                duration=time.time() - start_time,
                details={},
                error_message=str(e)
            )
    
    async def test_real_database_operations(self) -> TestResult:
        """Test that database operations are real, not mocked."""
        start_time = time.time()
        self.log("💾 Testing real database operations...")
        
        try:
            # Test database persistence across requests
            test_data = {
                "test_key": f"test_value_{int(time.time())}",
                "timestamp": datetime.now().isoformat()
            }
            
            # Store data
            store_response = requests.post(
                f"{self.backend_url}/api/test-db-store",
                json=test_data,
                timeout=10
            )
            
            if store_response.status_code != 200:
                return TestResult(
                    test_name="database_operations",
                    passed=False,
                    duration=time.time() - start_time,
                    details={},
                    error_message=f"Failed to store data: {store_response.status_code}"
                )
            
            stored_id = store_response.json().get("id")
            
            # Wait a moment
            await asyncio.sleep(1)
            
            # Retrieve data
            retrieve_response = requests.get(
                f"{self.backend_url}/api/test-db-retrieve/{stored_id}",
                timeout=10
            )
            
            if retrieve_response.status_code == 200:
                retrieved_data = retrieve_response.json()
                data_matches = retrieved_data.get("test_key") == test_data["test_key"]
                
                return TestResult(
                    test_name="database_operations",
                    passed=data_matches,
                    duration=time.time() - start_time,
                    details={
                        "stored_data": test_data,
                        "retrieved_data": retrieved_data,
                        "data_matches": data_matches,
                        "stored_id": stored_id
                    },
                    error_message=None if data_matches else "Retrieved data doesn't match stored data"
                )
            else:
                return TestResult(
                    test_name="database_operations",
                    passed=False,
                    duration=time.time() - start_time,
                    details={},
                    error_message=f"Failed to retrieve data: {retrieve_response.status_code}"
                )
                
        except Exception as e:
            return TestResult(
                test_name="database_operations",
                passed=False,
                duration=time.time() - start_time,
                details={},
                error_message=str(e)
            )
    
    async def analyze_test_suite_authenticity(self) -> TestResult:
        """Analyze if tests are testing real functionality or just passing artificially."""
        start_time = time.time()
        self.log("🔍 Analyzing test suite authenticity...")
        
        try:
            # Check for common test manipulation patterns
            test_issues = []
            
            # Look for mocking in production code
            mock_patterns = [
                ("mock", 0),
                ("fake", 0), 
                ("stub", 0),
                ("test-specific", 0)
            ]
            
            # Scan production code for suspicious patterns
            project_root = Path(__file__).parent.parent.parent
            
            for file_path in project_root.rglob("*.py"):
                if "test" in str(file_path) or "__pycache__" in str(file_path):
                    continue
                    
                try:
                    content = file_path.read_text()
                    for pattern, count in mock_patterns:
                        if pattern.lower() in content.lower():
                            mock_patterns[mock_patterns.index((pattern, count))] = (pattern, count + 1)
                except:
                    continue
            
            # Flag files with suspicious patterns
            for pattern, count in mock_patterns:
                if count > 0:
                    test_issues.append(f"Found {count} instances of '{pattern}' in production code")
            
            # Check if environment variables suggest test mode
            test_env_vars = ["TEST", "MOCK", "FAKE", "STUB"]
            active_test_vars = [var for var in test_env_vars if os.getenv(var)]
            
            if active_test_vars:
                test_issues.append(f"Test environment variables active: {active_test_vars}")
            
            authenticity_score = max(0, 100 - len(test_issues) * 20)
            
            return TestResult(
                test_name="test_suite_authenticity",
                passed=authenticity_score >= 80,
                duration=time.time() - start_time,
                details={
                    "mock_patterns": dict(mock_patterns),
                    "test_issues": test_issues,
                    "authenticity_score": authenticity_score,
                    "active_test_vars": active_test_vars
                },
                error_message=None if authenticity_score >= 80 else f"Low authenticity score: {authenticity_score}%"
            )
            
        except Exception as e:
            return TestResult(
                test_name="test_suite_authenticity",
                passed=False,
                duration=time.time() - start_time,
                details={},
                error_message=str(e)
            )
    
    async def run_all_tests(self) -> Dict[str, Any]:
        """Run all production validation tests."""
        self.log("🚀 Starting Production Validation Suite")
        self.log("=" * 50)
        
        # Start backend server
        if not await self.start_backend_server():
            return {
                "success": False,
                "error": "Failed to start backend server",
                "results": []
            }
        
        try:
            # Run all tests
            tests = [
                self.analyze_test_suite_authenticity(),
                self.test_memory_leak_fixes(),
                self.test_authentication_security(),
                self.test_async_performance(),
                self.test_real_database_operations()
            ]
            
            self.results = await asyncio.gather(*tests, return_exceptions=True)
            
            # Process any exceptions
            for i, result in enumerate(self.results):
                if isinstance(result, Exception):
                    self.results[i] = TestResult(
                        test_name=f"test_{i}",
                        passed=False,
                        duration=0,
                        details={},
                        error_message=str(result)
                    )
            
            # Calculate overall results
            passed_tests = sum(1 for r in self.results if r.passed)
            total_tests = len(self.results)
            success_rate = (passed_tests / total_tests) * 100 if total_tests > 0 else 0
            
            # Generate report
            report = {
                "success": success_rate >= 80,  # 80% pass rate required
                "timestamp": datetime.now().isoformat(),
                "summary": {
                    "total_tests": total_tests,
                    "passed_tests": passed_tests,
                    "failed_tests": total_tests - passed_tests,
                    "success_rate": success_rate
                },
                "test_results": [asdict(r) for r in self.results]
            }
            
            return report
            
        finally:
            # Cleanup
            await self.cleanup()
    
    async def cleanup(self):
        """Clean up test resources."""
        self.log("🧹 Cleaning up test environment...")
        
        # Kill backend process
        if "backend" in self.process_pids:
            try:
                os.killpg(os.getpgid(self.process_pids["backend"]), 9)
            except:
                pass
        
        # Additional cleanup
        try:
            subprocess.run(["pkill", "-f", "make dev-backend"], check=False)
        except:
            pass


async def main():
    """Main entry point."""
    validator = ProductionValidator()
    
    try:
        results = await validator.run_all_tests()
        
        # Save results
        results_file = Path(__file__).parent / f"production_validation_{int(time.time())}.json"
        results_file.write_text(json.dumps(results, indent=2))
        
        # Print summary
        print("\n" + "=" * 60)
        print("📊 PRODUCTION VALIDATION RESULTS")
        print("=" * 60)
        
        if results["success"]:
            print("✅ OVERALL RESULT: PASSED")
        else:
            print("❌ OVERALL RESULT: FAILED")
        
        summary = results["summary"]
        print(f"📈 Success Rate: {summary['success_rate']:.1f}%")
        print(f"✅ Passed: {summary['passed_tests']}/{summary['total_tests']}")
        print(f"❌ Failed: {summary['failed_tests']}/{summary['total_tests']}")
        
        print(f"\n📁 Full results saved to: {results_file}")
        
        # Exit with appropriate code
        sys.exit(0 if results["success"] else 1)
        
    except Exception as e:
        print(f"❌ Critical error during validation: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())