# Subagent Coordination Plan: API & UI Teams

## Executive Summary

This document defines clear boundaries and coordination strategies for API and UI subagents to work in parallel without code conflicts while migrating the custom frontend to integrate with ADK's SSE backend.

## Important Discovery

**The ADK frontend already uses SSE, not WebSocket!** The custom frontend imported socket.io but isn't actually using it. This simplifies our migration significantly.

## Team Boundaries

### API Subagent (Backend Team)

**Owns These Directories:**
```
/app/
├── services/
│   ├── sse_adapter.py          # NEW: SSE event adapter
│   ├── session_manager.py      # NEW: Session state management
│   ├── event_transformer.py    # NEW: Event transformation logic
│   └── sse_error_handler.py    # NEW: Error handling service
├── routes/
│   └── sse_routes.py          # NEW: Additional SSE endpoints
├── utils/
│   └── typing.py              # MODIFY: Add SSE types
├── config.py                  # MODIFY: Add SSE configuration
└── server.py                  # MODIFY: Integrate SSE services
```

**Responsibilities:**
- Transform ADK agent events to frontend format
- Manage session state and persistence
- Handle error recovery and resilience
- Provide health check endpoints
- Configure CORS and middleware

**DO NOT TOUCH:**
- Any files in `/frontend/` directory
- Visual components or styling
- Client-side JavaScript/TypeScript

### UI Subagent (Frontend Team)

**Owns These Directories:**
```
/frontend/src/
├── services/
│   ├── sseClient.ts           # NEW: SSE client wrapper
│   └── websocket.ts           # DELETE: Remove unused file
├── hooks/
│   ├── useSSE.ts             # NEW: SSE connection hook
│   ├── useMessages.ts        # NEW: Message state hook
│   └── useWebSocket.ts       # DELETE: Remove unused hook
├── utils/
│   └── sseParser.ts          # NEW: Extract SSE parsing logic
├── components/
│   ├── ConnectionStatus.tsx   # NEW: Connection indicator
│   └── ErrorBoundary.tsx     # MODIFY: Add SSE error handling
└── App.tsx                   # MODIFY: Refactor to use hooks
```

**Responsibilities:**
- Create clean SSE client abstraction
- Refactor App.tsx to use new hooks
- Add connection status indicators
- Ensure zero visual changes
- Maintain all animations and styling

**DO NOT TOUCH:**
- Any files in `/app/` directory
- Backend API endpoints
- Server configuration

## Coordination Strategy

### 1. Git Branch Strategy
```bash
main
├── feature/sse-migration          # Parent branch
│   ├── api/sse-backend           # API subagent branch
│   └── ui/sse-frontend           # UI subagent branch
```

### 2. Daily Sync Points
- **Morning Standup**: Share progress and blockers
- **Afternoon Check-in**: Test integration points
- **EOD Merge**: Merge to parent branch if stable

### 3. Integration Points

#### Shared Contract Definition
Create a shared types file that both teams reference but neither modifies:
```typescript
// docs/sse-contract.ts (READ-ONLY for both teams)
interface SSEEvent {
  type: 'thinking_update' | 'message_update' | 'error'
  data: ThinkingUpdate | MessageUpdate | ErrorData
  timestamp: number
}

interface ThinkingUpdate {
  stepId: string
  agent: string
  action: string
  status: 'pending' | 'active' | 'complete'
  duration?: string
}
```

### 4. Testing Coordination

#### Independent Testing
- **API Team**: Test with curl/Postman
- **UI Team**: Test with mock SSE server

#### Integration Testing
```bash
# API team provides test server
cd /app && make dev-backend

# UI team tests against real backend
cd /frontend && npm run dev
```

### 5. Communication Protocols

#### Slack Channels
- `#sse-migration-general` - General discussion
- `#sse-api-team` - API subagent internal
- `#sse-ui-team` - UI subagent internal
- `#sse-integration` - Integration issues

#### Documentation
- API team documents in `/docs/api/`
- UI team documents in `/docs/ui/`
- Shared docs in `/docs/shared/`

## Conflict Prevention Rules

### 1. File Locking
- Use `.gitignore` patterns to prevent accidental cross-team edits
- Add pre-commit hooks to check file ownership

### 2. Import Rules
- Frontend CANNOT import from `/app/`
- Backend CANNOT import from `/frontend/`
- Shared types in `/docs/` are READ-ONLY

### 3. Testing Isolation
- API tests in `/app/tests/`
- UI tests in `/frontend/tests/`
- Integration tests in `/tests/integration/`

## Implementation Phases

### Phase 1: Parallel Development (Days 1-3)
- Both teams work independently
- No integration required
- Focus on core functionality

### Phase 2: Integration Testing (Days 4-5)
- Connect frontend to backend
- Fix integration issues
- Performance testing

### Phase 3: Migration (Days 6-7)
- Feature flag rollout
- Monitor metrics
- Full deployment

## Success Metrics

### API Team
- [ ] All ADK events properly transformed
- [ ] Session persistence working
- [ ] < 50ms event processing time
- [ ] 99.9% uptime

### UI Team
- [ ] Zero visual changes
- [ ] All animations preserved
- [ ] Connection status visible
- [ ] Graceful error handling

### Joint Success
- [ ] End-to-end message flow working
- [ ] No console errors
- [ ] Performance metrics maintained
- [ ] User experience unchanged

## Emergency Procedures

### Rollback Plan
1. Feature flag to disable SSE
2. Revert to previous WebSocket mock
3. Hotfix branch if needed

### Escalation Path
1. Team lead consultation
2. Architecture review
3. Emergency standup

## Conclusion

This coordination plan ensures both subagents can work efficiently in parallel while maintaining clear boundaries. The key is respecting file ownership, maintaining the shared contract, and coordinating only at defined integration points.