# API Subagent SSE Implementation Plan

## Overview
This document outlines the backend integration plan for migrating from WebSocket to Server-Sent Events (SSE) in the Vana project. The plan focuses on creating an SSE adapter service that bridges the existing ADK SSE endpoints with the custom frontend's WebSocket-based architecture.

## Current State Analysis

### Existing ADK SSE Infrastructure
- **Endpoint**: `/api/run_sse` (already implemented in ADK's FastAPI)
- **Response Type**: `StreamingResponse` with `text/event-stream` media type
- **Event Format**: JSON-serialized ADK events with SSE formatting (`data: {event}\n\n`)
- **Streaming Mode**: Controlled via `RunConfig(streaming_mode=StreamingMode.SSE)`

### Current Frontend WebSocket Implementation
- **Protocol**: Socket.IO WebSocket
- **Events**: Custom event types (thinking steps, state updates, completion)
- **State Management**: Real-time bidirectional updates
- **Connection Management**: Auto-reconnection, heartbeat

## Implementation Components

### 1. SSE Adapter Service (`app/services/sse_adapter.py`)

**Purpose**: Transform ADK events to match frontend expectations

**Key Features**:
- Event type mapping (ADK events → Frontend events)
- State synchronization
- Error handling and recovery
- Event buffering and batching

**Implementation Details**:
```python
from typing import AsyncGenerator, Dict, Any, Optional
from google.adk.events.event import Event
from fastapi.responses import StreamingResponse
import json
import asyncio
from datetime import datetime

class SSEAdapter:
    """Adapts ADK events to frontend-compatible SSE format"""
    
    def __init__(self):
        self.event_mappings = {
            "agent_message": "thinking_step",
            "tool_call": "tool_execution",
            "final_response": "completion",
            # Add more mappings
        }
        self.active_sessions: Dict[str, SessionState] = {}
    
    async def transform_event_stream(
        self,
        adk_events: AsyncGenerator[Event, None],
        session_id: str,
        user_id: str
    ) -> AsyncGenerator[str, None]:
        """Transform ADK event stream to frontend-compatible SSE events"""
        # Implementation details in section below
```

### 2. Session Management Service (`app/services/session_manager.py`)

**Purpose**: Manage session state between SSE connections

**Key Features**:
- Session lifecycle management
- State persistence across reconnections
- Event replay for missed events
- Cleanup of stale sessions

**Implementation Details**:
```python
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import asyncio
from dataclasses import dataclass, field

@dataclass
class SessionState:
    session_id: str
    user_id: str
    created_at: datetime
    last_activity: datetime
    event_buffer: List[Dict[str, Any]] = field(default_factory=list)
    connection_count: int = 0
    is_active: bool = True
    
class SessionManager:
    """Manages SSE session state and lifecycle"""
    
    def __init__(self, ttl_minutes: int = 30):
        self.sessions: Dict[str, SessionState] = {}
        self.ttl = timedelta(minutes=ttl_minutes)
        self._cleanup_task = None
```

### 3. Event Transformation Logic (`app/services/event_transformer.py`)

**Purpose**: Convert between ADK and frontend event formats

**Key Features**:
- Type-safe event transformation
- Custom event enrichment
- Thinking step generation
- Progress tracking

**Implementation Details**:
```python
from typing import Dict, Any, Optional, List
from google.adk.events.event import Event
from pydantic import BaseModel
import re

class FrontendEvent(BaseModel):
    """Frontend-compatible event structure"""
    type: str
    data: Dict[str, Any]
    timestamp: str
    sequence: int
    agent_name: Optional[str] = None
    
class EventTransformer:
    """Transforms ADK events to frontend format"""
    
    def transform_adk_event(self, event: Event, context: Dict[str, Any]) -> List[FrontendEvent]:
        """Transform single ADK event to one or more frontend events"""
        # Implementation details below
```

### 4. Enhanced API Endpoints (`app/routes/sse_routes.py`)

**Purpose**: Additional SSE endpoints for enhanced functionality

**Key Features**:
- Session initialization endpoint
- Event replay endpoint
- Connection health check
- Graceful shutdown handling

**Implementation Details**:
```python
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from typing import Optional
import asyncio

router = APIRouter(prefix="/api/sse", tags=["sse"])

@router.post("/session/init")
async def initialize_session(request: SessionInitRequest) -> SessionInitResponse:
    """Initialize SSE session with proper state"""
    # Implementation below

@router.get("/events/{session_id}")
async def stream_events(
    session_id: str,
    last_event_id: Optional[str] = None,
    user_id: Optional[str] = None
) -> StreamingResponse:
    """Stream events with replay capability"""
    # Implementation below
```

### 5. Error Handling and Recovery (`app/services/sse_error_handler.py`)

**Purpose**: Robust error handling for SSE connections

**Key Features**:
- Automatic retry with exponential backoff
- Error event generation
- Connection state recovery
- Graceful degradation

**Implementation Details**:
```python
from typing import Optional, Callable, Any
import asyncio
from enum import Enum
import logging

class ErrorType(Enum):
    CONNECTION_LOST = "connection_lost"
    INVALID_SESSION = "invalid_session"
    RATE_LIMIT = "rate_limit"
    SERVER_ERROR = "server_error"
    
class SSEErrorHandler:
    """Handles errors in SSE connections gracefully"""
    
    async def handle_error(
        self,
        error: Exception,
        session_id: str,
        retry_count: int = 0
    ) -> Dict[str, Any]:
        """Handle errors and determine recovery strategy"""
        # Implementation below
```

## Integration Points

### 1. Modify Existing Server (`app/server.py`)
**Changes Required**:
- Import and initialize SSE services
- Add SSE-specific middleware
- Configure CORS for SSE endpoints
- Add graceful shutdown handlers

```python
# Add to app/server.py
from app.services.sse_adapter import SSEAdapter
from app.services.session_manager import SessionManager
from app.routes import sse_routes

# Initialize services
sse_adapter = SSEAdapter()
session_manager = SessionManager()

# Add routes
app.include_router(sse_routes.router)

# Add shutdown handler
@app.on_event("shutdown")
async def shutdown_event():
    await session_manager.cleanup_all_sessions()
```

### 2. Extend Type Definitions (`app/utils/typing.py`)
**New Types Required**:
```python
from typing import Literal, Optional, List
from pydantic import BaseModel, Field
from datetime import datetime

class SSEEventType(str, Enum):
    THINKING_STEP = "thinking_step"
    TOOL_EXECUTION = "tool_execution"
    STATE_UPDATE = "state_update"
    COMPLETION = "completion"
    ERROR = "error"
    HEARTBEAT = "heartbeat"

class SessionInitRequest(BaseModel):
    user_id: str
    session_id: Optional[str] = None
    previous_session_id: Optional[str] = None
    client_capabilities: Dict[str, Any] = Field(default_factory=dict)

class SessionInitResponse(BaseModel):
    session_id: str
    user_id: str
    replay_available: bool
    server_time: datetime
    capabilities: Dict[str, Any]
```

### 3. Configuration Updates (`app/config.py`)
**New Configuration Options**:
```python
from pydantic import BaseSettings

class SSEConfig(BaseSettings):
    # SSE specific settings
    sse_heartbeat_interval: int = 30  # seconds
    sse_event_buffer_size: int = 1000
    sse_session_ttl_minutes: int = 30
    sse_max_reconnect_attempts: int = 5
    sse_reconnect_delay_ms: int = 1000
    
    # Feature flags
    enable_event_replay: bool = True
    enable_event_compression: bool = False
    enable_detailed_logging: bool = False
    
    class Config:
        env_prefix = "VANA_SSE_"
```

## Implementation Boundaries

### API Subagent Responsibilities
1. **Backend Services**: All files in `app/services/` directory
2. **API Routes**: New routes in `app/routes/sse_routes.py`
3. **Type Definitions**: Extensions to `app/utils/typing.py`
4. **Configuration**: SSE-specific config in `app/config.py`
5. **Server Integration**: Minimal changes to `app/server.py`

### NOT in API Subagent Scope
1. **Frontend Components**: No changes to any files in `frontend/` directory
2. **UI State Management**: No modifications to React components
3. **WebSocket Removal**: Frontend team handles Socket.IO removal
4. **Visual Design**: No CSS or UI styling changes
5. **Client-Side SSE**: Frontend team implements EventSource client

## Testing Strategy

### Unit Tests (`tests/unit/test_sse_adapter.py`)
```python
import pytest
from app.services.sse_adapter import SSEAdapter
from app.services.event_transformer import EventTransformer

@pytest.mark.asyncio
async def test_event_transformation():
    """Test ADK event to frontend event transformation"""
    # Test implementation

@pytest.mark.asyncio 
async def test_session_management():
    """Test session lifecycle management"""
    # Test implementation
```

### Integration Tests (`tests/integration/test_sse_endpoints.py`)
```python
import pytest
from fastapi.testclient import TestClient
import asyncio

@pytest.mark.asyncio
async def test_sse_streaming():
    """Test end-to-end SSE streaming"""
    # Test implementation

@pytest.mark.asyncio
async def test_error_recovery():
    """Test SSE error handling and recovery"""
    # Test implementation
```

## Deployment Considerations

### Performance Optimization
1. **Event Buffering**: Implement smart buffering to reduce network overhead
2. **Compression**: Optional gzip compression for large events
3. **Connection Pooling**: Efficient management of concurrent SSE connections
4. **Resource Limits**: Configure max connections per user/session

### Monitoring and Observability
1. **Metrics**: Track SSE connection count, duration, error rates
2. **Logging**: Structured logging for debugging
3. **Tracing**: OpenTelemetry integration for distributed tracing
4. **Health Checks**: SSE-specific health endpoints

### Security
1. **Authentication**: Validate user tokens for SSE connections
2. **Rate Limiting**: Prevent abuse of SSE endpoints
3. **CORS**: Proper CORS configuration for SSE
4. **Input Validation**: Sanitize all event data

## Migration Path

### Phase 1: Parallel Implementation (Week 1-2)
1. Implement SSE adapter service
2. Add session management
3. Create event transformation logic
4. Add new SSE endpoints
5. Deploy alongside existing WebSocket

### Phase 2: Testing and Validation (Week 2-3)
1. Unit test all components
2. Integration testing with ADK
3. Load testing for performance
4. Error scenario testing

### Phase 3: Gradual Rollout (Week 3-4)
1. Feature flag for SSE mode
2. A/B testing with small user group
3. Monitor performance metrics
4. Gather user feedback

### Phase 4: Full Migration (Week 4-5)
1. Enable SSE for all users
2. Deprecate WebSocket endpoints
3. Remove WebSocket code (frontend team)
4. Documentation updates

## Success Criteria

1. **Functional Requirements**
   - All WebSocket events properly mapped to SSE
   - Session state maintained across reconnections
   - Error recovery without data loss
   - Performance equal or better than WebSocket

2. **Non-Functional Requirements**
   - < 100ms event transformation latency
   - Support 1000+ concurrent connections
   - 99.9% uptime for SSE service
   - Graceful degradation on errors

3. **Developer Experience**
   - Clear API documentation
   - Comprehensive logging
   - Easy debugging tools
   - Minimal configuration

## Risks and Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Browser SSE limitations | High | Implement fallback polling mechanism |
| Memory leaks from long connections | Medium | Automatic session cleanup, connection limits |
| Event ordering issues | Medium | Sequence numbers, event replay |
| Performance degradation | High | Load testing, horizontal scaling |
| Frontend integration delays | Medium | Clear API contracts, mock services |

## Dependencies

1. **ADK Framework**: Version compatibility with SSE support
2. **FastAPI**: SSE streaming capabilities
3. **Frontend Team**: Coordinated timeline for client changes
4. **Infrastructure**: Load balancer SSE configuration
5. **Monitoring**: Observability tools for SSE metrics

## Conclusion

This implementation plan provides a comprehensive approach to migrating from WebSocket to SSE while maintaining all existing functionality. The modular design allows for independent development and testing of components, with clear boundaries between API and UI work. The phased migration approach minimizes risk and allows for validation at each step.