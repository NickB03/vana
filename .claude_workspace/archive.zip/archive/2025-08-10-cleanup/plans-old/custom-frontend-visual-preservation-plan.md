# Custom Frontend Visual Preservation & Communication Optimization Plan

## Executive Summary

This plan outlines how to maintain the exact visual design and user experience of the custom Vana frontend while migrating from WebSocket to Server-Sent Events (SSE) for optimal integration with the ADK backend.

## Visual Design Analysis

### Core Design Elements to Preserve

#### 1. Color Scheme & Branding
- **Background**: Dark theme with `#1a1a1a` base
- **VANA Gradient**: Blue (#7c9fff) → Purple (#b794f6) → Red (#fc8181) → Orange (#f6ad55)
- **Animated gradients**: Shifting backgrounds and pulsing effects
- **Glassmorphism**: Semi-transparent panels with backdrop blur

#### 2. Key Visual Components

**Landing Page**
- Gradient text title "Hi, I'm Vana"
- Framer Motion animations with staggered delays
- Suggested prompts with hover effects
- AIInput component with tools integration

**Thinking Panel**
- Collapsible side panel with glassmorphism
- Real-time status indicators (active/completed counts)
- Brain icon with gradient pulse animation
- Smooth spring animations for expand/collapse

**Chat Interface**
- System welcome message styling
- Message bubbles with user/assistant differentiation
- AIConversation component for message threading
- Loading states with animated indicators

#### 3. Animation Patterns
```css
/* Preserve these exact animations */
- gradient-shift: 3s ease infinite
- gradient-pulse: 2s ease-in-out infinite
- border-spin: 3s linear infinite
- Framer Motion spring animations (damping: 20)
```

## Communication Layer Migration

### Current State: WebSocket (socket.io)
```typescript
// Current implementation
const wsService = new WebSocketService()
wsService.on('thinking_update', handleThinkingUpdate)
wsService.on('message_update', handleMessageUpdate)
```

### Target State: SSE (EventSource)
```typescript
// New implementation preserving the same interface
const sseService = new SSEService()
sseService.on('thinking_update', handleThinkingUpdate)
sseService.on('message_update', handleMessageUpdate)
```

## Implementation Strategy

### Phase 1: Create SSE Adapter (2 days)

Create a drop-in replacement for WebSocket that maintains the exact same API:

```typescript
// services/sse-adapter.ts
export class SSEService {
  private eventSource: EventSource | null = null
  private listeners: Map<string, Set<Function>> = new Map()
  private sessionId: string | null = null
  
  async connect(url?: string) {
    // First create ADK session
    const session = await this.createSession()
    this.sessionId = session.id
    
    // Connect to SSE endpoint
    this.eventSource = new EventSource(`/api/run_sse?session=${this.sessionId}`)
    this.setupEventHandlers()
  }
  
  // Maintain exact same event interface
  on(event: string, callback: Function) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set())
    }
    this.listeners.get(event)!.add(callback)
  }
  
  sendMessage(message: string) {
    // Convert to ADK format and send via POST
    this.sendToADK(message)
  }
}
```

### Phase 2: Event Transformation Layer (1 day)

Map ADK agent events to existing thinking step format:

```typescript
// utils/event-transformer.ts
export function transformADKEvent(adkEvent: ADKEvent): ThinkingUpdate {
  return {
    stepId: generateStepId(),
    agent: getAgentDisplayName(adkEvent.author),
    action: getActionDescription(adkEvent),
    status: mapEventStatus(adkEvent),
    duration: adkEvent.duration
  }
}

// Agent name mappings for visual consistency
const AGENT_VISUALS = {
  'plan_generator': {
    display: 'Orchestrator',
    action: 'Planning research strategy',
    icon: 'Brain'
  },
  'section_researcher': {
    display: 'Research Specialist',
    action: 'Performing multi-domain research',
    icon: 'Search'
  },
  'enhanced_search_executor': {
    display: 'Research Specialist',
    action: 'Aggregating results',
    icon: 'Database'
  }
}
```

### Phase 3: Component Integration (1 day)

Update only the service layer, keeping all visual components intact:

```typescript
// hooks/useWebSocket.ts - No changes needed!
// Just swap the import
import { sseService as wsService } from '../services/sse-adapter'

// All components remain exactly the same
// ChatInterface.tsx - No changes
// ThinkingPanel.tsx - No changes
// LandingPage.tsx - No changes
```

## Visual Component Preservation

### Components That Stay Exactly the Same
1. **LandingPage.tsx** - All animations and styling preserved
2. **ThinkingPanel.tsx** - Glassmorphism and animations intact
3. **ChatInterface.tsx** - Message rendering unchanged
4. **AIInput.tsx** - Tool integration maintained
5. **All UI components** - No visual changes

### CSS/Styling Preservation
- **index.css** - Keep all custom properties and animations
- **Tailwind config** - No changes needed
- **Framer Motion** - All animations preserved

## SSE Optimization for Best Results

### 1. Connection Management
```typescript
class SSEService {
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectDelay = 1000
  
  private setupReconnection() {
    this.eventSource!.onerror = () => {
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        setTimeout(() => this.reconnect(), 
          this.reconnectDelay * Math.pow(2, this.reconnectAttempts))
        this.reconnectAttempts++
      }
    }
  }
}
```

### 2. Event Buffering & Batching
```typescript
class EventBuffer {
  private buffer: ThinkingUpdate[] = []
  private flushInterval = 100 // ms
  
  add(event: ThinkingUpdate) {
    this.buffer.push(event)
    this.scheduleFlush()
  }
  
  private flush() {
    if (this.buffer.length > 0) {
      this.emit('batch', this.buffer)
      this.buffer = []
    }
  }
}
```

### 3. Performance Optimizations
- Stream parsing with incremental JSON parsing
- Event deduplication for redundant updates
- Automatic compression negotiation
- Connection pooling for multiple agents

## Testing & Validation

### Visual Regression Testing
1. Screenshot comparison before/after migration
2. Animation timing validation
3. Color and gradient consistency checks
4. Responsive design verification

### Functional Testing
1. WebSocket → SSE event mapping
2. Real-time update latency
3. Error handling and reconnection
4. Message ordering and delivery

## Migration Timeline

| Phase | Duration | Tasks |
|-------|----------|-------|
| Day 1-2 | 2 days | SSE Adapter implementation |
| Day 3 | 1 day | Event transformation layer |
| Day 4 | 1 day | Component integration |
| Day 5 | 1 day | Testing & optimization |

## Risk Mitigation

1. **Feature Flag Implementation**
   ```typescript
   const useWebSocketService = () => {
     return process.env.VITE_USE_SSE === 'true' 
       ? sseService 
       : originalWebSocketService
   }
   ```

2. **Gradual Rollout**
   - Test with subset of users
   - Monitor performance metrics
   - Quick rollback capability

3. **Fallback Mechanism**
   - Detect SSE support
   - Fallback to polling if needed
   - Maintain WebSocket as backup

## Success Criteria

✅ **Visual Preservation**
- [ ] All animations run at same speed
- [ ] Colors and gradients identical
- [ ] Layout and spacing unchanged
- [ ] Interaction feedback preserved

✅ **Performance Metrics**
- [ ] Message latency < 100ms
- [ ] Thinking updates real-time
- [ ] Smooth animations (60fps)
- [ ] Reliable reconnection

✅ **User Experience**
- [ ] No visual differences noticed
- [ ] Same interaction patterns
- [ ] Improved reliability
- [ ] Better error handling

## Conclusion

By implementing an SSE adapter that maintains the exact same API as the current WebSocket service, we can migrate to SSE without changing a single line of visual component code. This approach ensures 100% visual preservation while gaining the benefits of SSE for ADK integration.