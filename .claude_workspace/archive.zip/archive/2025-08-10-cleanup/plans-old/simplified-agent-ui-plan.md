# Simplified Multi-Agent UI Plan for Claude Code

## Overview
Transform the current multi-agent display from showing individual agent activities to a single, consolidated progress view with phase-based tracking.

## Design Principles
1. **One Progress Box**: Single consolidated view instead of multiple agent boxes
2. **Phase-Based Progress**: Clear phases (Planning → Research → Synthesis)
3. **Smart Summarization**: Show what's happening, not implementation details
4. **Visual Progress**: Progress bar or spinner with current phase
5. **Expandable Details**: Option to see detailed agent activity if needed

## Implementation Plan

### Phase 1: Create Consolidated Progress Component

```typescript
interface ResearchPhase {
  phase: 'planning' | 'researching' | 'evaluating' | 'composing'
  status: 'pending' | 'active' | 'complete'
  summary: string
  progress?: number // 0-100
  subTasks?: string[] // Current activities
}
```

### Phase 2: Agent Activity Mapping

Map agent names to user-friendly phases:
- `interactive_planner_agent` → "Creating research plan"
- `plan_generator` → "Designing research strategy"
- `section_planner` → "Structuring report outline"
- `section_researcher` → "Gathering information"
- `research_evaluator` → "Ensuring quality"
- `enhanced_search_executor` → "Deep diving into sources"
- `report_composer_with_citations` → "Writing final report"

### Phase 3: Simplified Event Processing

Instead of creating a step for each agent event:
1. Track current phase based on active agent
2. Update phase progress based on agent completion
3. Show single progress indicator with phase name
4. Optionally show sub-activities as bullet points

### Phase 4: New UI Components

#### A. SimplifiedThinkingPanel
```typescript
// Single box showing:
// - Current Phase (with icon)
// - Progress bar or circular progress
// - Brief description of what's happening
// - Estimated time remaining (optional)
// - Expand button for details
```

#### B. PhaseProgress
```typescript
// Visual timeline showing:
// Planning ✓ → Research (in progress) → Quality Check → Final Report
```

### Phase 5: Smart Summarization Logic

Create summaries based on agent groups:
- **Planning Agents**: "Analyzing your request and creating a research plan"
- **Research Agents**: "Searching and analyzing relevant information"
- **Evaluation Agents**: "Ensuring comprehensive coverage"
- **Composition Agents**: "Creating your final report"

## Implementation Steps

1. **Create new components**:
   - `SimplifiedThinkingPanel.tsx`
   - `PhaseProgress.tsx`
   - `ResearchProgress.tsx`

2. **Update SSE client**:
   - Add phase tracking logic
   - Implement activity summarization
   - Reduce event granularity

3. **Modify ChatInterface**:
   - Use SimplifiedThinkingPanel instead of ThinkingPanel
   - Add toggle for detailed/simplified view

4. **Add configuration**:
   - Allow users to switch between detailed and simplified views
   - Remember user preference

## Example UI Flow

1. **User asks question**
   ```
   [Planning Phase] 🧠
   Creating a research plan for your question...
   ━━━━━░░░░░░░░░░ 30%
   ```

2. **Research begins**
   ```
   [Research Phase] 🔍
   Gathering information from multiple sources...
   ━━━━━━━━━░░░░░░ 65%
   • Analyzing 12 sources
   • Extracting key insights
   ```

3. **Final composition**
   ```
   [Writing Phase] ✍️
   Composing your comprehensive report...
   ━━━━━━━━━━━━━━━ 95%
   ```

## Benefits
- **Cleaner UI**: Less visual clutter
- **Better UX**: Users understand what's happening without technical details
- **Scalable**: Works regardless of number of agents
- **Flexible**: Can still access detailed view if needed

## Migration Strategy
1. Build new components alongside existing ones
2. Add feature flag to toggle between views
3. Test with various research queries
4. Gradually make simplified view the default
5. Keep detailed view as "developer mode"