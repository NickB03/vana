# OpenRouter Integration Implementation Plan for Vana

## Executive Summary

This plan outlines a safe, gradual approach to integrating OpenRouter APIs into the Vana project through LiteLLM, while maintaining full backward compatibility with the existing Gemini-based research agent system. The integration follows ADK patterns and enables model flexibility without disrupting current functionality.

## Goals & Constraints

### Primary Goals
1. **Zero Disruption**: Ensure existing Gemini-based agents continue working without modification
2. **Gradual Migration**: Allow testing OpenRouter models alongside Gemini models
3. **Model Flexibility**: Support both Gemini and OpenRouter models simultaneously
4. **Configuration-Based**: Use environment variables and config files for model selection
5. **Production Safety**: Separate dev/prod configurations with safe defaults

### Constraints
- Must maintain ADK agent architecture patterns
- Cannot modify existing agent logic initially
- Must preserve all current functionality
- Environment-specific configurations required
- Rollback must be instant and safe

## Architecture Overview

### Current State
```
Vana Application
├── ResearchConfiguration (config.py)
│   ├── critic_model: "gemini-2.5-pro"
│   └── worker_model: "gemini-2.5-flash"
├── LlmAgent instances (agent.py)
│   └── Uses direct Gemini model strings
└── Google AI/Vertex AI Backend
    └── GOOGLE_GENAI_USE_VERTEXAI flag
```

### Target State
```
Vana Application
├── Enhanced ResearchConfiguration
│   ├── Model selection logic
│   ├── Provider configuration
│   └── Fallback mechanisms
├── LiteLLM Integration Layer
│   ├── Provider routing
│   ├── API key management
│   └── Error handling
└── Multiple Backends
    ├── Google AI/Vertex AI (existing)
    └── OpenRouter via LiteLLM (new)
```

## Implementation Phases

### Phase 1: Foundation Setup (No Breaking Changes)

#### 1.1 Install LiteLLM Dependency
```toml
# pyproject.toml addition
dependencies = [
    # ... existing dependencies ...
    "litellm>=1.57.0",  # Latest stable version with OpenRouter support
]
```

#### 1.2 Create Model Provider Module
Create `/app/utils/model_provider.py`:
```python
"""Model provider configuration and routing for ADK agents."""

import os
import logging
from typing import Optional, Dict, Any
from enum import Enum

logger = logging.getLogger(__name__)


class ModelProvider(Enum):
    """Supported model providers."""
    GEMINI = "gemini"
    OPENROUTER = "openrouter"
    LITELLM = "litellm"  # For custom LiteLLM configurations


class ModelConfig:
    """Configuration for model providers and routing."""
    
    def __init__(self):
        self.provider = self._detect_provider()
        self.litellm_config = self._load_litellm_config()
        
    def _detect_provider(self) -> ModelProvider:
        """Detect which model provider to use based on environment."""
        provider = os.environ.get("VANA_MODEL_PROVIDER", "gemini").lower()
        
        if provider == "openrouter":
            if not os.environ.get("OPENROUTER_API_KEY"):
                logger.warning("OPENROUTER_API_KEY not set, falling back to Gemini")
                return ModelProvider.GEMINI
            return ModelProvider.OPENROUTER
        elif provider == "litellm":
            return ModelProvider.LITELLM
        else:
            return ModelProvider.GEMINI
    
    def _load_litellm_config(self) -> Optional[Dict[str, Any]]:
        """Load LiteLLM configuration if needed."""
        if self.provider in [ModelProvider.OPENROUTER, ModelProvider.LITELLM]:
            # Set LiteLLM environment variables
            if self.provider == ModelProvider.OPENROUTER:
                # OpenRouter requires specific base URL
                os.environ["OPENROUTER_API_BASE"] = "https://openrouter.ai/api/v1"
            
            return {
                "success_callback": ["langfuse"] if os.environ.get("LANGFUSE_PUBLIC_KEY") else None,
                "failure_callback": None,
                "cache": False,  # ADK handles its own caching
                "retry_strategy": {
                    "initial_retry_delay": 1,
                    "max_retry_delay": 60,
                    "retry_multiplier": 2,
                    "max_retries": 3
                }
            }
        return None
    
    def format_model_name(self, model: str) -> str:
        """Format model name for the configured provider."""
        if self.provider == ModelProvider.GEMINI:
            # Return as-is for Gemini models
            return model
        elif self.provider == ModelProvider.OPENROUTER:
            # OpenRouter uses different model naming
            if model == "gemini-2.5-pro":
                # Map to equivalent OpenRouter model
                return "openrouter/anthropic/claude-3.5-sonnet"
            elif model == "gemini-2.5-flash":
                # Map to a fast OpenRouter model
                return "openrouter/anthropic/claude-3-haiku"
            else:
                # Pass through with openrouter prefix
                return f"openrouter/{model}"
        elif self.provider == ModelProvider.LITELLM:
            # Allow custom LiteLLM model strings
            return model
        else:
            return model
    
    def get_model_kwargs(self) -> Dict[str, Any]:
        """Get additional kwargs for model initialization."""
        kwargs = {}
        
        if self.provider == ModelProvider.OPENROUTER:
            # OpenRouter specific parameters
            kwargs["api_key"] = os.environ.get("OPENROUTER_API_KEY")
            kwargs["api_base"] = "https://openrouter.ai/api/v1"
            
            # Optional OpenRouter headers
            if app_name := os.environ.get("OPENROUTER_APP_NAME"):
                kwargs["headers"] = {
                    "HTTP-Referer": os.environ.get("OPENROUTER_REFERRER", "https://vana.ai"),
                    "X-Title": app_name
                }
        
        return kwargs


# Global instance
model_config = ModelConfig()
```

#### 1.3 Create Environment-Aware Configuration
Update `/app/config.py`:
```python
import os
from dataclasses import dataclass, field
from typing import Optional, Dict, Any

import google.auth

# Import our new model provider utility
from .utils.model_provider import model_config, ModelProvider

# Existing Google Cloud setup
_, project_id = google.auth.default()
os.environ.setdefault("GOOGLE_CLOUD_PROJECT", project_id)
os.environ.setdefault("GOOGLE_CLOUD_LOCATION", "global")
os.environ.setdefault("GOOGLE_GENAI_USE_VERTEXAI", "True")


@dataclass
class ResearchConfiguration:
    """Configuration for research-related models and parameters.
    
    Now supports multiple model providers through environment configuration.
    """
    
    # Core configuration
    max_search_iterations: int = 5
    
    # Model configuration with provider awareness
    _critic_model_base: str = field(default="gemini-2.5-pro", init=False)
    _worker_model_base: str = field(default="gemini-2.5-flash", init=False)
    
    # Provider-specific model name cache
    _model_cache: Dict[str, str] = field(default_factory=dict, init=False)
    
    def __post_init__(self):
        """Initialize with environment-specific overrides."""
        # Allow environment override of base models
        self._critic_model_base = os.environ.get(
            "VANA_CRITIC_MODEL", self._critic_model_base
        )
        self._worker_model_base = os.environ.get(
            "VANA_WORKER_MODEL", self._worker_model_base
        )
        
        # Override search iterations if specified
        if max_iter := os.environ.get("VANA_MAX_SEARCH_ITERATIONS"):
            self.max_search_iterations = int(max_iter)
    
    @property
    def critic_model(self) -> str:
        """Get critic model name formatted for current provider."""
        if "critic" not in self._model_cache:
            self._model_cache["critic"] = model_config.format_model_name(
                self._critic_model_base
            )
        return self._model_cache["critic"]
    
    @property
    def worker_model(self) -> str:
        """Get worker model name formatted for current provider."""
        if "worker" not in self._model_cache:
            self._model_cache["worker"] = model_config.format_model_name(
                self._worker_model_base
            )
        return self._model_cache["worker"]
    
    @property
    def model_provider(self) -> str:
        """Get current model provider name."""
        return model_config.provider.value
    
    @property
    def is_using_litellm(self) -> bool:
        """Check if using LiteLLM for model routing."""
        return model_config.provider != ModelProvider.GEMINI
    
    def get_model_kwargs(self) -> Dict[str, Any]:
        """Get provider-specific model kwargs."""
        return model_config.get_model_kwargs()


# Global configuration instance
config = ResearchConfiguration()
```

### Phase 2: Testing Infrastructure

#### 2.1 Create Test Configuration
Create `/app/utils/model_testing.py`:
```python
"""Utilities for testing different model providers."""

import os
import asyncio
import logging
from typing import Dict, List, Optional
from datetime import datetime

from google.adk.agents import LlmAgent
from google.genai import types as genai_types

from ..config import config
from .model_provider import ModelProvider, model_config

logger = logging.getLogger(__name__)


class ModelTester:
    """Test harness for comparing model providers."""
    
    def __init__(self):
        self.results: List[Dict] = []
        
    async def test_basic_generation(
        self, 
        model_name: str, 
        provider: Optional[ModelProvider] = None
    ) -> Dict:
        """Test basic text generation with a model."""
        start_time = datetime.utcnow()
        
        # Temporarily override provider if specified
        original_provider = model_config.provider
        if provider:
            model_config.provider = provider
        
        try:
            # Create test agent
            test_agent = LlmAgent(
                name="test_agent",
                model=model_config.format_model_name(model_name),
                description="Test agent for model validation",
                instruction="You are a helpful assistant. Answer concisely.",
            )
            
            # Test simple generation
            response = await test_agent.generate_content(
                "What is 2 + 2? Answer with just the number."
            )
            
            result = {
                "model": model_name,
                "provider": provider.value if provider else model_config.provider.value,
                "success": True,
                "response": response.text,
                "latency_ms": (datetime.utcnow() - start_time).total_seconds() * 1000,
                "timestamp": start_time.isoformat(),
            }
            
        except Exception as e:
            logger.error(f"Model test failed: {e}")
            result = {
                "model": model_name,
                "provider": provider.value if provider else model_config.provider.value,
                "success": False,
                "error": str(e),
                "latency_ms": (datetime.utcnow() - start_time).total_seconds() * 1000,
                "timestamp": start_time.isoformat(),
            }
        finally:
            # Restore original provider
            model_config.provider = original_provider
            
        self.results.append(result)
        return result
    
    async def compare_providers(
        self, 
        model_mapping: Dict[ModelProvider, str]
    ) -> List[Dict]:
        """Compare the same logical model across providers."""
        comparison_results = []
        
        for provider, model_name in model_mapping.items():
            result = await self.test_basic_generation(model_name, provider)
            comparison_results.append(result)
            
        return comparison_results
    
    def print_summary(self):
        """Print test results summary."""
        print("\n=== Model Testing Summary ===")
        for result in self.results:
            status = "✓" if result["success"] else "✗"
            print(f"{status} {result['provider']}/{result['model']}: "
                  f"{result.get('response', result.get('error', 'Unknown'))[:50]}... "
                  f"({result['latency_ms']:.0f}ms)")


# Convenience function for testing
async def validate_model_setup():
    """Validate current model configuration."""
    tester = ModelTester()
    
    print(f"Current provider: {config.model_provider}")
    print(f"Critic model: {config.critic_model}")
    print(f"Worker model: {config.worker_model}")
    
    # Test current configuration
    await tester.test_basic_generation(config.critic_model)
    await tester.test_basic_generation(config.worker_model)
    
    tester.print_summary()
    return tester.results
```

#### 2.2 Create Integration Tests
Create `/tests/integration/test_model_providers.py`:
```python
"""Integration tests for model provider functionality."""

import os
import pytest
import asyncio
from unittest.mock import patch

from app.utils.model_provider import ModelProvider, model_config
from app.config import ResearchConfiguration
from app.utils.model_testing import ModelTester


class TestModelProviders:
    """Test model provider integration."""
    
    def test_default_provider_is_gemini(self):
        """Test that default provider is Gemini."""
        with patch.dict(os.environ, {}, clear=True):
            config = ResearchConfiguration()
            assert config.model_provider == "gemini"
            assert config.critic_model == "gemini-2.5-pro"
            assert config.worker_model == "gemini-2.5-flash"
    
    def test_openrouter_provider_selection(self):
        """Test OpenRouter provider selection."""
        with patch.dict(os.environ, {
            "VANA_MODEL_PROVIDER": "openrouter",
            "OPENROUTER_API_KEY": "test-key"
        }):
            # Need to reload to pick up env changes
            from app.utils.model_provider import ModelConfig
            test_config = ModelConfig()
            
            assert test_config.provider == ModelProvider.OPENROUTER
            
            # Test model name formatting
            assert test_config.format_model_name("gemini-2.5-pro") == "openrouter/anthropic/claude-3.5-sonnet"
            assert test_config.format_model_name("gemini-2.5-flash") == "openrouter/anthropic/claude-3-haiku"
    
    def test_fallback_without_api_key(self):
        """Test fallback to Gemini without API key."""
        with patch.dict(os.environ, {
            "VANA_MODEL_PROVIDER": "openrouter",
            # No API key provided
        }, clear=True):
            from app.utils.model_provider import ModelConfig
            test_config = ModelConfig()
            
            # Should fall back to Gemini
            assert test_config.provider == ModelProvider.GEMINI
    
    def test_environment_model_override(self):
        """Test environment variable model overrides."""
        with patch.dict(os.environ, {
            "VANA_CRITIC_MODEL": "custom-critic-model",
            "VANA_WORKER_MODEL": "custom-worker-model",
            "VANA_MAX_SEARCH_ITERATIONS": "10"
        }):
            config = ResearchConfiguration()
            
            assert config._critic_model_base == "custom-critic-model"
            assert config._worker_model_base == "custom-worker-model"
            assert config.max_search_iterations == 10
    
    @pytest.mark.asyncio
    async def test_model_comparison(self):
        """Test model comparison across providers (requires API keys)."""
        if not os.environ.get("OPENROUTER_API_KEY"):
            pytest.skip("OPENROUTER_API_KEY not set")
        
        tester = ModelTester()
        
        # Compare equivalent models
        results = await tester.compare_providers({
            ModelProvider.GEMINI: "gemini-2.5-flash",
            ModelProvider.OPENROUTER: "anthropic/claude-3-haiku"
        })
        
        # All should succeed
        assert all(r["success"] for r in results)
        
        # Should have different latencies
        latencies = [r["latency_ms"] for r in results]
        assert len(set(latencies)) > 1  # Not all the same


@pytest.mark.integration
class TestAgentIntegration:
    """Test agent integration with different providers."""
    
    @pytest.mark.asyncio
    async def test_agent_with_gemini(self):
        """Test agent creation with Gemini provider."""
        from app.agent import plan_generator
        
        # Should create successfully
        assert plan_generator.name == "plan_generator"
        assert plan_generator.model == "gemini-2.5-flash"
    
    @pytest.mark.asyncio
    @pytest.mark.skipif(
        not os.environ.get("OPENROUTER_API_KEY"),
        reason="OPENROUTER_API_KEY not set"
    )
    async def test_agent_with_openrouter(self):
        """Test agent creation with OpenRouter provider."""
        with patch.dict(os.environ, {
            "VANA_MODEL_PROVIDER": "openrouter",
            "OPENROUTER_API_KEY": os.environ.get("OPENROUTER_API_KEY")
        }):
            # Reimport to get new configuration
            import importlib
            import app.agent
            importlib.reload(app.agent)
            
            from app.agent import plan_generator
            
            # Should use OpenRouter model names
            assert "openrouter" in plan_generator.model.lower()
```

### Phase 3: Gradual Agent Migration

#### 3.1 Create Provider-Aware Agent Factory
Create `/app/utils/agent_factory.py`:
```python
"""Factory for creating ADK agents with provider awareness."""

import logging
from typing import Optional, Dict, Any, List

from google.adk.agents import LlmAgent
from google.genai import types as genai_types

from ..config import config
from .model_provider import ModelProvider, model_config

logger = logging.getLogger(__name__)


class AgentFactory:
    """Factory for creating agents with appropriate model configuration."""
    
    @staticmethod
    def create_llm_agent(
        name: str,
        model: Optional[str] = None,
        description: str = "",
        instruction: str = "",
        tools: Optional[List] = None,
        **kwargs
    ) -> LlmAgent:
        """Create an LLM agent with provider-aware configuration.
        
        This factory method ensures agents are created with the correct
        model names and configuration for the current provider.
        """
        # Use provided model or default to worker model
        if model is None:
            model = config.worker_model
        else:
            # Format the model name for current provider
            model = model_config.format_model_name(model)
        
        # Get provider-specific kwargs
        provider_kwargs = config.get_model_kwargs()
        
        # Merge with provided kwargs (provided kwargs take precedence)
        all_kwargs = {**provider_kwargs, **kwargs}
        
        # Special handling for LiteLLM providers
        if config.is_using_litellm:
            # LiteLLM uses completion() API internally
            # We might need to wrap certain ADK-specific features
            logger.info(
                f"Creating agent '{name}' with LiteLLM provider: "
                f"{config.model_provider}, model: {model}"
            )
        
        # Create the agent
        agent = LlmAgent(
            name=name,
            model=model,
            description=description,
            instruction=instruction,
            tools=tools or [],
            **all_kwargs
        )
        
        return agent
    
    @staticmethod
    def migrate_existing_agent(
        agent: LlmAgent,
        force_provider: Optional[ModelProvider] = None
    ) -> LlmAgent:
        """Migrate an existing agent to use current provider configuration.
        
        This is useful for gradually migrating agents without changing
        their initialization code.
        """
        # Store original configuration
        original_model = agent.model
        
        # Determine target provider
        target_provider = force_provider or model_config.provider
        
        if target_provider != ModelProvider.GEMINI:
            # Need to recreate agent with new model
            new_model = model_config.format_model_name(original_model)
            
            logger.info(
                f"Migrating agent '{agent.name}' from {original_model} "
                f"to {new_model} ({target_provider.value})"
            )
            
            # Create new agent with same configuration but new model
            migrated_agent = AgentFactory.create_llm_agent(
                name=agent.name,
                model=new_model,
                description=agent.description,
                instruction=agent.instruction,
                tools=agent.tools,
                # Preserve other attributes
                output_schema=getattr(agent, 'output_schema', None),
                output_key=getattr(agent, 'output_key', None),
                disallow_transfer_to_parent=getattr(
                    agent, 'disallow_transfer_to_parent', False
                ),
                disallow_transfer_to_peers=getattr(
                    agent, 'disallow_transfer_to_peers', False
                ),
            )
            
            return migrated_agent
        
        # No migration needed for Gemini
        return agent


# Convenience function for conditional migration
def create_or_migrate_agent(
    existing_agent: Optional[LlmAgent] = None,
    **creation_kwargs
) -> LlmAgent:
    """Create a new agent or migrate existing one based on configuration.
    
    This allows gradual migration by checking environment flags.
    """
    if existing_agent and not config.is_using_litellm:
        # Keep existing agent if not using LiteLLM
        return existing_agent
    elif existing_agent:
        # Migrate existing agent
        return AgentFactory.migrate_existing_agent(existing_agent)
    else:
        # Create new agent
        return AgentFactory.create_llm_agent(**creation_kwargs)
```

#### 3.2 Create Migration Wrapper
Create `/app/agent_migration.py`:
```python
"""Migration module for transitioning agents to OpenRouter."""

import os
import logging
from typing import Dict, Optional

from .agent import (
    plan_generator,
    section_planner,
    section_researcher,
    research_evaluator,
    enhanced_search_executor,
    report_composer,
    interactive_planner_agent,
    root_agent
)
from .utils.agent_factory import AgentFactory
from .utils.model_provider import ModelProvider

logger = logging.getLogger(__name__)


class AgentMigrator:
    """Handles migration of agents to different model providers."""
    
    def __init__(self):
        self.original_agents: Dict = {}
        self.migration_enabled = os.environ.get(
            "VANA_ENABLE_AGENT_MIGRATION", "false"
        ).lower() == "true"
        
    def should_migrate(self, agent_name: str) -> bool:
        """Check if a specific agent should be migrated."""
        if not self.migration_enabled:
            return False
            
        # Check agent-specific migration flags
        agent_flag = f"VANA_MIGRATE_{agent_name.upper()}"
        if os.environ.get(agent_flag):
            return os.environ.get(agent_flag).lower() == "true"
        
        # Check for batch migration mode
        if os.environ.get("VANA_MIGRATE_ALL_AGENTS", "false").lower() == "true":
            return True
            
        # Check for specific agent groups
        if agent_name in ["plan_generator", "section_planner", "section_researcher"]:
            return os.environ.get(
                "VANA_MIGRATE_WORKER_AGENTS", "false"
            ).lower() == "true"
        elif agent_name in ["research_evaluator", "report_composer"]:
            return os.environ.get(
                "VANA_MIGRATE_CRITIC_AGENTS", "false"
            ).lower() == "true"
            
        return False
    
    def migrate_agents(self) -> Dict[str, bool]:
        """Migrate agents based on configuration."""
        migration_results = {}
        
        agents_to_check = {
            "plan_generator": plan_generator,
            "section_planner": section_planner,
            "section_researcher": section_researcher,
            "research_evaluator": research_evaluator,
            "enhanced_search_executor": enhanced_search_executor,
            "report_composer": report_composer,
        }
        
        for agent_name, agent in agents_to_check.items():
            if self.should_migrate(agent_name):
                try:
                    # Store original
                    self.original_agents[agent_name] = agent
                    
                    # Migrate
                    migrated = AgentFactory.migrate_existing_agent(agent)
                    
                    # Update global reference
                    globals()[agent_name] = migrated
                    
                    migration_results[agent_name] = True
                    logger.info(f"Successfully migrated {agent_name}")
                    
                except Exception as e:
                    logger.error(f"Failed to migrate {agent_name}: {e}")
                    migration_results[agent_name] = False
            else:
                migration_results[agent_name] = False
                
        return migration_results
    
    def rollback_migrations(self):
        """Rollback all migrations to original agents."""
        for agent_name, original_agent in self.original_agents.items():
            globals()[agent_name] = original_agent
            logger.info(f"Rolled back {agent_name} to original")
        
        self.original_agents.clear()


# Global migrator instance
agent_migrator = AgentMigrator()

# Perform migrations on module import if enabled
if agent_migrator.migration_enabled:
    migration_results = agent_migrator.migrate_agents()
    logger.info(f"Agent migration results: {migration_results}")
```

### Phase 4: Environment Configuration

#### 4.1 Development Environment Setup
Create `/environments/dev.env`:
```bash
# Development Environment Configuration
# Copy to .env for local development

# Model Provider Configuration
# Options: gemini (default), openrouter, litellm
VANA_MODEL_PROVIDER=gemini

# Model Selection (optional overrides)
# VANA_CRITIC_MODEL=gemini-2.5-pro
# VANA_WORKER_MODEL=gemini-2.5-flash

# OpenRouter Configuration (if using openrouter provider)
# OPENROUTER_API_KEY=your-openrouter-api-key
# OPENROUTER_APP_NAME=vana-dev
# OPENROUTER_REFERRER=https://vana-dev.ai

# Migration Flags (for gradual rollout)
VANA_ENABLE_AGENT_MIGRATION=false
# VANA_MIGRATE_ALL_AGENTS=false
# VANA_MIGRATE_WORKER_AGENTS=false
# VANA_MIGRATE_CRITIC_AGENTS=false
# VANA_MIGRATE_PLAN_GENERATOR=false

# Search Configuration
VANA_MAX_SEARCH_ITERATIONS=5

# Monitoring (optional)
# LANGFUSE_PUBLIC_KEY=your-langfuse-key
# LANGFUSE_SECRET_KEY=your-langfuse-secret
```

#### 4.2 Production Environment Setup
Create `/environments/prod.env`:
```bash
# Production Environment Configuration
# Deploy via Secret Manager

# Model Provider Configuration
VANA_MODEL_PROVIDER=gemini  # Keep Gemini for production initially

# Search Configuration
VANA_MAX_SEARCH_ITERATIONS=5

# Migration Flags - All disabled for production
VANA_ENABLE_AGENT_MIGRATION=false
```

#### 4.3 Testing Environment Setup
Create `/environments/test.env`:
```bash
# Testing Environment Configuration
# For A/B testing different providers

# Model Provider Configuration
VANA_MODEL_PROVIDER=openrouter

# OpenRouter Configuration
OPENROUTER_API_KEY=${SECRET_OPENROUTER_API_KEY}
OPENROUTER_APP_NAME=vana-test
OPENROUTER_REFERRER=https://vana-test.ai

# Enable specific agent migrations for testing
VANA_ENABLE_AGENT_MIGRATION=true
VANA_MIGRATE_WORKER_AGENTS=true
# Keep critic agents on Gemini for comparison
VANA_MIGRATE_CRITIC_AGENTS=false

# Enhanced monitoring for testing
LANGFUSE_PUBLIC_KEY=${SECRET_LANGFUSE_PUBLIC_KEY}
LANGFUSE_SECRET_KEY=${SECRET_LANGFUSE_SECRET_KEY}
```

### Phase 5: Deployment Strategy

#### 5.1 Update Terraform Configuration
Create `/deployment/terraform/modules/openrouter/main.tf`:
```hcl
# OpenRouter integration module

variable "environment" {
  description = "Environment name"
  type        = string
}

variable "enable_openrouter" {
  description = "Enable OpenRouter integration"
  type        = bool
  default     = false
}

variable "openrouter_api_key_secret" {
  description = "Secret Manager secret ID for OpenRouter API key"
  type        = string
  default     = ""
}

# Secret Manager configuration
resource "google_secret_manager_secret" "openrouter_api_key" {
  count     = var.enable_openrouter ? 1 : 0
  secret_id = "vana-${var.environment}-openrouter-api-key"
  
  replication {
    automatic = true
  }
}

# IAM for Cloud Run to access secret
resource "google_secret_manager_secret_iam_member" "openrouter_secret_access" {
  count     = var.enable_openrouter ? 1 : 0
  secret_id = google_secret_manager_secret.openrouter_api_key[0].id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${var.cloud_run_service_account}"
}

# Environment variables for Cloud Run
output "env_vars" {
  value = var.enable_openrouter ? [
    {
      name  = "VANA_MODEL_PROVIDER"
      value = "openrouter"
    },
    {
      name = "OPENROUTER_API_KEY"
      value_source = {
        secret_key_ref = {
          secret  = google_secret_manager_secret.openrouter_api_key[0].secret_id
          version = "latest"
        }
      }
    }
  ] : []
}
```

#### 5.2 Update Cloud Run Deployment
Modify `/deployment/terraform/dev/main.tf`:
```hcl
# Add OpenRouter module
module "openrouter" {
  source = "../modules/openrouter"
  
  environment               = "dev"
  enable_openrouter        = var.enable_openrouter_dev
  cloud_run_service_account = module.cloud_run.service_account
}

# Update Cloud Run configuration
resource "google_cloud_run_service" "vana_app" {
  # ... existing configuration ...
  
  template {
    spec {
      containers {
        # ... existing configuration ...
        
        # Add OpenRouter environment variables
        dynamic "env" {
          for_each = module.openrouter.env_vars
          content {
            name = env.value.name
            
            dynamic "value_from" {
              for_each = env.value.value_source != null ? [1] : []
              content {
                secret_key_ref {
                  name = env.value.value_source.secret_key_ref.secret
                  key  = env.value.value_source.secret_key_ref.version
                }
              }
            }
            
            value = env.value.value_source == null ? env.value.value : null
          }
        }
      }
    }
  }
}
```

### Phase 6: Testing & Validation

#### 6.1 Create Validation Script
Create `/scripts/validate_openrouter_integration.py`:
```python
#!/usr/bin/env python3
"""Validate OpenRouter integration without affecting production."""

import asyncio
import os
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from app.utils.model_testing import ModelTester, validate_model_setup
from app.utils.model_provider import ModelProvider
from app.config import config


async def main():
    """Run validation tests."""
    print("=== OpenRouter Integration Validation ===\n")
    
    # Check current configuration
    print(f"Current provider: {config.model_provider}")
    print(f"LiteLLM enabled: {config.is_using_litellm}")
    print(f"Critic model: {config.critic_model}")
    print(f"Worker model: {config.worker_model}")
    print()
    
    # Test 1: Basic model functionality
    print("Test 1: Basic Model Functionality")
    print("-" * 40)
    await validate_model_setup()
    print()
    
    # Test 2: Provider comparison (if API key available)
    if os.environ.get("OPENROUTER_API_KEY"):
        print("Test 2: Provider Comparison")
        print("-" * 40)
        
        tester = ModelTester()
        results = await tester.compare_providers({
            ModelProvider.GEMINI: "gemini-2.5-flash",
            ModelProvider.OPENROUTER: "anthropic/claude-3-haiku"
        })
        
        tester.print_summary()
        print()
        
        # Test 3: Agent functionality
        print("Test 3: Agent Creation")
        print("-" * 40)
        
        try:
            from app.utils.agent_factory import AgentFactory
            
            test_agent = AgentFactory.create_llm_agent(
                name="validation_agent",
                model="gemini-2.5-flash",  # Will be mapped to OpenRouter equivalent
                description="Test agent for validation",
                instruction="You are a helpful assistant."
            )
            
            print(f"✓ Created agent with model: {test_agent.model}")
            
        except Exception as e:
            print(f"✗ Failed to create agent: {e}")
    else:
        print("Skipping provider comparison tests (OPENROUTER_API_KEY not set)")
    
    print("\n=== Validation Complete ===")


if __name__ == "__main__":
    asyncio.run(main())
```

#### 6.2 Create Performance Comparison Script
Create `/scripts/compare_providers.py`:
```python
#!/usr/bin/env python3
"""Compare performance between Gemini and OpenRouter providers."""

import asyncio
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).parent.parent))

from app.agent import plan_generator
from app.utils.model_provider import ModelProvider, model_config
from app.utils.agent_factory import AgentFactory


async def benchmark_agent(agent_name: str, provider: ModelProvider, test_prompts: List[str]) -> Dict:
    """Benchmark an agent with specific provider."""
    results = {
        "agent": agent_name,
        "provider": provider.value,
        "timestamp": datetime.utcnow().isoformat(),
        "tests": []
    }
    
    # Temporarily switch provider
    original_provider = model_config.provider
    model_config.provider = provider
    
    try:
        # Create agent with provider
        if agent_name == "plan_generator":
            agent = AgentFactory.create_llm_agent(
                name="plan_generator",
                model=config.worker_model,
                description="Generates research plans",
                instruction=plan_generator.instruction,
                tools=plan_generator.tools
            )
        
        # Run test prompts
        for prompt in test_prompts:
            start_time = datetime.utcnow()
            
            try:
                response = await agent.generate_content(prompt)
                latency = (datetime.utcnow() - start_time).total_seconds() * 1000
                
                results["tests"].append({
                    "prompt": prompt[:50] + "...",
                    "success": True,
                    "latency_ms": latency,
                    "response_length": len(response.text)
                })
                
            except Exception as e:
                results["tests"].append({
                    "prompt": prompt[:50] + "...",
                    "success": False,
                    "error": str(e)
                })
    
    finally:
        model_config.provider = original_provider
    
    return results


async def main():
    """Run provider comparison benchmarks."""
    test_prompts = [
        "Create a research plan for understanding quantum computing applications in finance",
        "What are the key environmental impacts of electric vehicles?",
        "Analyze the role of artificial intelligence in modern healthcare"
    ]
    
    providers_to_test = [ModelProvider.GEMINI]
    
    if os.environ.get("OPENROUTER_API_KEY"):
        providers_to_test.append(ModelProvider.OPENROUTER)
    
    all_results = []
    
    for provider in providers_to_test:
        print(f"\nTesting {provider.value} provider...")
        results = await benchmark_agent("plan_generator", provider, test_prompts)
        all_results.append(results)
        
        # Print summary
        successful = sum(1 for t in results["tests"] if t["success"])
        avg_latency = sum(t.get("latency_ms", 0) for t in results["tests"] if t["success"]) / max(successful, 1)
        
        print(f"  Success rate: {successful}/{len(results['tests'])}")
        print(f"  Average latency: {avg_latency:.0f}ms")
    
    # Save detailed results
    output_file = Path("provider_comparison_results.json")
    with output_file.open("w") as f:
        json.dump(all_results, f, indent=2)
    
    print(f"\nDetailed results saved to {output_file}")


if __name__ == "__main__":
    from app.config import config
    asyncio.run(main())
```

### Phase 7: Rollback Strategy

#### 7.1 Create Rollback Script
Create `/scripts/rollback_openrouter.sh`:
```bash
#!/bin/bash
# Rollback OpenRouter integration

set -e

echo "=== OpenRouter Integration Rollback ==="

# Check environment
ENVIRONMENT=${1:-dev}
echo "Rolling back environment: $ENVIRONMENT"

# Rollback environment variables
case $ENVIRONMENT in
  dev)
    gcloud run services update vana-app-dev \
      --update-env-vars="VANA_MODEL_PROVIDER=gemini,VANA_ENABLE_AGENT_MIGRATION=false" \
      --remove-env-vars="OPENROUTER_API_KEY,OPENROUTER_APP_NAME,OPENROUTER_REFERRER" \
      --region=us-central1
    ;;
  prod)
    echo "Production rollback requires approval"
    read -p "Confirm production rollback (yes/no): " confirm
    if [ "$confirm" = "yes" ]; then
      gcloud run services update vana-app-prod \
        --update-env-vars="VANA_MODEL_PROVIDER=gemini" \
        --remove-env-vars="OPENROUTER_API_KEY" \
        --region=us-central1
    fi
    ;;
  *)
    echo "Unknown environment: $ENVIRONMENT"
    exit 1
    ;;
esac

echo "Rollback complete. Service will use Gemini models."
```

#### 7.2 Create Health Check
Create `/app/utils/health_check.py`:
```python
"""Health check utilities for model providers."""

import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional

from ..config import config
from .model_provider import model_config
from .model_testing import ModelTester

logger = logging.getLogger(__name__)


class ProviderHealthCheck:
    """Health check for model providers."""
    
    def __init__(self):
        self.last_check: Optional[datetime] = None
        self.status: Dict[str, bool] = {}
        
    async def check_provider_health(self) -> Dict:
        """Check health of current model provider."""
        start_time = datetime.utcnow()
        
        health_status = {
            "provider": config.model_provider,
            "timestamp": start_time.isoformat(),
            "healthy": False,
            "latency_ms": None,
            "error": None,
            "models": {
                "critic": {"model": config.critic_model, "healthy": False},
                "worker": {"model": config.worker_model, "healthy": False}
            }
        }
        
        try:
            tester = ModelTester()
            
            # Test critic model
            critic_result = await tester.test_basic_generation(config.critic_model)
            health_status["models"]["critic"]["healthy"] = critic_result["success"]
            
            # Test worker model
            worker_result = await tester.test_basic_generation(config.worker_model)
            health_status["models"]["worker"]["healthy"] = worker_result["success"]
            
            # Overall health
            health_status["healthy"] = (
                health_status["models"]["critic"]["healthy"] and
                health_status["models"]["worker"]["healthy"]
            )
            
            health_status["latency_ms"] = (
                datetime.utcnow() - start_time
            ).total_seconds() * 1000
            
        except Exception as e:
            health_status["error"] = str(e)
            logger.error(f"Health check failed: {e}")
        
        self.last_check = datetime.utcnow()
        self.status[config.model_provider] = health_status["healthy"]
        
        return health_status
    
    async def check_all_providers(self) -> List[Dict]:
        """Check health of all configured providers."""
        results = []
        
        # Always check Gemini
        gemini_health = await self.check_provider_health()
        results.append(gemini_health)
        
        # Check OpenRouter if configured
        if model_config.provider != model_config.provider.GEMINI:
            # Already checked above
            pass
        elif os.environ.get("OPENROUTER_API_KEY"):
            # Temporarily switch to OpenRouter
            original = model_config.provider
            try:
                model_config.provider = model_config.provider.OPENROUTER
                openrouter_health = await self.check_provider_health()
                results.append(openrouter_health)
            finally:
                model_config.provider = original
        
        return results


# Global health checker
health_checker = ProviderHealthCheck()
```

### Phase 8: Monitoring & Observability

#### 8.1 Update Server with Health Endpoint
Add to `/app/server.py`:
```python
from fastapi import FastAPI, HTTPException
from .utils.health_check import health_checker

# Add health check endpoint
@app.get("/health/providers")
async def check_provider_health():
    """Check health of configured model providers."""
    try:
        health_status = await health_checker.check_provider_health()
        
        if not health_status["healthy"]:
            raise HTTPException(
                status_code=503,
                detail=f"Provider {health_status['provider']} is unhealthy"
            )
        
        return health_status
    except Exception as e:
        logger.error(f"Health check error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health/providers/all")
async def check_all_providers():
    """Check health of all available providers."""
    try:
        results = await health_checker.check_all_providers()
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "providers": results
        }
    except Exception as e:
        logger.error(f"Health check error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
```

#### 8.2 Create Monitoring Dashboard Config
Create `/monitoring/provider_metrics.yaml`:
```yaml
# Cloud Monitoring dashboard configuration
displayName: "Vana Model Provider Metrics"
mosaicLayout:
  columns: 12
  tiles:
    - width: 6
      height: 4
      widget:
        title: "Model Provider Distribution"
        pieChart:
          dataSets:
            - timeSeriesQuery:
                timeSeriesFilter:
                  filter: |
                    resource.type="cloud_run_revision"
                    metric.type="run.googleapis.com/request_count"
                    metadata.user_labels."model_provider"!=""
                  aggregation:
                    alignmentPeriod: "60s"
                    groupByFields:
                      - "metadata.user_labels.model_provider"
    
    - width: 6
      height: 4
      xPos: 6
      widget:
        title: "Provider Latency Comparison"
        xyChart:
          dataSets:
            - timeSeriesQuery:
                timeSeriesFilter:
                  filter: |
                    resource.type="cloud_run_revision"
                    metric.type="run.googleapis.com/request_latencies"
                  aggregation:
                    alignmentPeriod: "60s"
                    groupByFields:
                      - "metadata.user_labels.model_provider"
                    perSeriesAligner: "ALIGN_PERCENTILE_95"
    
    - width: 12
      height: 4
      yPos: 4
      widget:
        title: "Provider Error Rates"
        xyChart:
          dataSets:
            - timeSeriesQuery:
                timeSeriesFilter:
                  filter: |
                    resource.type="cloud_run_revision"
                    metric.type="logging.googleapis.com/user/provider_errors"
                  aggregation:
                    alignmentPeriod: "300s"
                    groupByFields:
                      - "metadata.user_labels.model_provider"
                    perSeriesAligner: "ALIGN_RATE"
```

## Implementation Timeline

### Week 1: Foundation
- [ ] Add LiteLLM to dependencies
- [ ] Create model provider module
- [ ] Update configuration system
- [ ] Write unit tests

### Week 2: Testing Infrastructure
- [ ] Create model testing utilities
- [ ] Write integration tests
- [ ] Set up test environments
- [ ] Validate with both providers

### Week 3: Agent Migration
- [ ] Implement agent factory
- [ ] Create migration wrapper
- [ ] Test individual agent migrations
- [ ] Validate research pipeline

### Week 4: Deployment & Monitoring
- [ ] Update Terraform modules
- [ ] Deploy to dev environment
- [ ] Set up monitoring
- [ ] Run A/B tests

### Week 5: Production Rollout
- [ ] Deploy to staging
- [ ] Run performance tests
- [ ] Gradual production rollout
- [ ] Monitor and optimize

## Success Criteria

1. **Zero Downtime**: No interruption to existing Gemini functionality
2. **Performance Parity**: OpenRouter latency within 20% of Gemini
3. **Cost Efficiency**: Track and compare costs between providers
4. **Easy Rollback**: Can revert to Gemini within 1 minute
5. **Clear Monitoring**: Dashboard shows provider usage and health

## Risk Mitigation

1. **API Compatibility**: LiteLLM handles provider differences
2. **Rate Limits**: Implement retry logic and backoff
3. **Cost Overruns**: Set up billing alerts and limits
4. **Model Quality**: A/B test results before full migration
5. **Latency Issues**: Regional deployment considerations

## Next Steps

1. Review and approve this plan
2. Set up OpenRouter account and API keys
3. Create feature branch: `feature/openrouter-integration`
4. Begin Phase 1 implementation
5. Schedule weekly progress reviews

This plan ensures a safe, gradual integration of OpenRouter while maintaining the stability of your production Vana system.