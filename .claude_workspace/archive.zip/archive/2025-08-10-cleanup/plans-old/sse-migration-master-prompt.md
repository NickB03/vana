# SSE Migration Master Prompt - Custom Vana UI to ADK Backend

## Project Context

**Vana** is a multi-agent AI system using Google's Agent Development Kit (ADK) for Python. The project currently has:
- **Backend**: ADK-based FastAPI server with SSE endpoint (`/api/run_sse`)
- **Frontend**: Custom Vana React UI with WebSocket implementation (needs migration to SSE)
- **Branch**: Working on `feature/sse-migration` (safe to make changes)

## Current Architecture

### Backend (ADK - Already Has SSE)
- **Endpoint**: `/api/run_sse` (POST)
- **Location**: `/app/server.py` using ADK's `get_fast_api_app()`
- **Event Format**: ADK events with structure:
  ```typescript
  {
    content?: { parts: Array<{text?: string, functionCall?: {...}, functionResponse?: {...}}> },
    author: string,  // Agent name
    actions?: { stateDelta?: { ... } },
    grounding_metadata?: { ... }
  }
  ```

### Frontend (Custom Vana - Currently WebSocket)
- **Main Components**:
  - `/frontend/src/components/ChatInterface.tsx` - Main chat UI
  - `/frontend/src/components/ThinkingPanel.tsx` - Agent activity display
  - `/frontend/src/services/websocket.ts` - WebSocket service
  - `/frontend/src/hooks/useWebSocket.ts` - WebSocket React hook
- **UI Components**: Custom AI components in `/frontend/src/components/ui/`

## Migration Requirements

### Phase 1: Analysis & Planning (Day 1)
1. Analyze how ChatInterface.tsx consumes WebSocket events
2. Document WebSocket event format expectations
3. Map ADK SSE events to Vana UI requirements
4. Design SSE client architecture

### Phase 2: Implementation (Days 2-3)
1. Replace WebSocket service with SSE client
2. Implement event transformation layer
3. Update React hooks for SSE
4. Maintain all UI functionality

### Phase 3: Integration (Day 4)
1. Connect to ADK's `/api/run_sse` endpoint
2. Test real-time agent updates
3. Verify ThinkingPanel displays correctly
4. Ensure zero visual regression

## Three-Agent Team Activation

### 1. ADK Multi-Agent Engineer
**Focus**: Backend integration and event transformation
**Tasks**:
- Analyze ADK's SSE implementation in detail
- Design event transformation service
- Create mapping for agent names to UI display names
- Handle session management with ADK

### 2. Frontend API Specialist  
**Focus**: SSE client implementation and WebSocket replacement
**Tasks**:
- Implement robust SSE client with EventSource API
- Replace WebSocket service while maintaining same interface
- Create TypeScript types for ADK events
- Build reconnection and error handling

### 3. LLM UI Designer
**Focus**: Visual preservation and user experience
**Tasks**:
- Ensure zero visual regression during migration
- Design subtle connection status indicators
- Maintain all animations and interactions
- Create graceful error states

## Critical Success Factors

1. **Preserve Exact UI/UX**: No visual changes to the beautiful Vana interface
2. **Real-time Updates**: Maintain smooth agent activity updates in ThinkingPanel
3. **Type Safety**: Full TypeScript coverage for ADK events
4. **Error Recovery**: Automatic reconnection with exponential backoff
5. **Performance**: Maintain 60fps animations, no UI jank

## Key File Locations

### Backend Files
```
/app/server.py              # ADK SSE endpoint
/app/agent.py               # Agent definitions
/app/config.py              # Configuration
```

### Frontend Files to Modify
```
/frontend/src/services/websocket.ts      # Replace with SSE client
/frontend/src/hooks/useWebSocket.ts      # Update to useSSE
/frontend/src/components/ChatInterface.tsx    # Update event handling
/frontend/src/components/ThinkingPanel.tsx    # Verify agent updates work
```

### New Files to Create
```
/frontend/src/services/sse-client.ts     # New SSE client
/frontend/src/types/adk-events.ts        # ADK event types
/frontend/src/hooks/useSSE.ts            # New SSE hook
```

## Coordination Points

1. **Event Format Agreement**: All teams must agree on the event transformation strategy
2. **Interface Preservation**: Frontend API must maintain same hook interface for minimal component changes
3. **Visual Testing**: UI Designer must verify each integration step
4. **Daily Sync**: Teams coordinate on integration points

## Testing Strategy

1. **Unit Tests**: SSE client, event transformers
2. **Integration Tests**: Full flow from ADK to UI
3. **Visual Regression**: Screenshot comparison
4. **Performance Tests**: 60fps validation
5. **Error Scenarios**: Network failures, reconnection

## IMPORTANT NOTES

- **Git Branch**: All work on `feature/sse-migration` branch
- **No Breaking Changes**: Components using useWebSocket should work with minimal updates
- **ADK Compliance**: Follow ADK patterns and conventions
- **Memory Usage**: Implement proper cleanup to prevent leaks
- **Browser Compatibility**: Handle SSE connection limits

## Launch Command

Execute the following to activate all three agents:

```
Please implement the SSE migration plan for the custom Vana UI to connect to the ADK backend. 

Activate three specialist agents:
1. ADK Multi-Agent Engineer - Lead backend integration and event transformation
2. Frontend API Specialist - Lead SSE client implementation replacing WebSocket
3. LLM UI Designer - Ensure zero visual regression and beautiful UX

Begin with Phase 1 analysis following the comprehensive plan in this document. Each agent should work on their assigned tasks and coordinate at the defined integration points.

Current branch: feature/sse-migration (safe to make all changes)
```

---

This prompt provides the complete context needed for a fresh session after /clear.