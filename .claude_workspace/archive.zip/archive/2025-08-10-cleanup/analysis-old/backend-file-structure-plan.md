# Backend File Structure Plan for SSE Implementation

**Date**: 2025-07-28  
**Phase**: Backend Team - File Structure Planning  
**Status**: Complete  

## Overview

This document outlines the file structure changes needed to implement the ADK SSE transformation service while maintaining ADK compliance and project organization standards.

## Current Project Structure

```
vana/
├── app/
│   ├── __init__.py
│   ├── agent.py              # Core agent definitions
│   ├── config.py             # Configuration dataclass
│   ├── server.py             # FastAPI app with ADK integration
│   └── utils/
│       ├── gcs.py           # Google Cloud Storage utilities
│       ├── tracing.py       # OpenTelemetry tracing
│       └── typing.py        # Type definitions
├── tests/
│   ├── unit/
│   ├── integration/
│   └── load_test/
└── ... (other directories)
```

## Proposed File Structure Changes

### New Service Architecture

```
app/
├── services/                 # 🆕 Service layer for business logic
│   ├── __init__.py
│   ├── sse_transformation.py # Main SSE transformation service
│   ├── adk_integration.py    # ADK integration patterns
│   ├── monitoring.py         # Observability and metrics
│   └── session_manager.py    # Session state management
├── schemas/                  # 🆕 Enhanced type definitions
│   ├── __init__.py
│   ├── sse_events.py        # SSE event type definitions  
│   ├── transformation.py     # Transformation schemas
│   └── monitoring.py        # Metrics and health check schemas
├── middleware/               # 🆕 FastAPI middleware
│   ├── __init__.py
│   ├── error_handling.py    # Global error handling
│   ├── logging.py           # Enhanced logging middleware
│   └── metrics.py           # Request metrics collection
├── utils/
│   ├── __init__.py
│   ├── gcs.py               # ✅ Existing - Google Cloud Storage
│   ├── tracing.py           # ✅ Existing - OpenTelemetry tracing  
│   ├── typing.py            # ✅ Existing - Type definitions
│   ├── health_checks.py     # 🆕 Health check utilities
│   └── json_serialization.py # 🆕 JSON handling utilities
├── agent.py                 # ✅ Existing - Core agent definitions
├── config.py                # 🔄 Enhanced - Add SSE config
├── server.py                # 🔄 Enhanced - Add transformation endpoints
└── __init__.py              # ✅ Existing
```

### Test Structure Enhancement

```
tests/
├── unit/
│   ├── test_dummy.py                    # ✅ Existing
│   ├── services/                        # 🆕 Service tests
│   │   ├── __init__.py
│   │   ├── test_sse_transformation.py   # Transformation service tests
│   │   ├── test_adk_integration.py      # ADK integration tests
│   │   ├── test_monitoring.py           # Monitoring tests
│   │   └── test_session_manager.py      # Session management tests
│   ├── schemas/                         # 🆕 Schema tests
│   │   ├── __init__.py
│   │   └── test_sse_events.py          # Event schema tests
│   └── utils/                           # 🆕 Utility tests
│       ├── __init__.py
│       └── test_health_checks.py       # Health check tests
├── integration/
│   ├── test_agent.py                    # ✅ Existing
│   ├── test_server_e2e.py              # ✅ Existing  
│   ├── test_sse_endpoint.py            # 🆕 SSE endpoint integration tests
│   └── test_transformation_flow.py     # 🆕 Full transformation flow tests
└── load_test/
    ├── README.md                        # ✅ Existing
    ├── load_test.py                     # ✅ Existing
    └── sse_load_test.py                # 🆕 SSE-specific load tests
```

## Detailed File Specifications

### 1. Service Layer Files

#### `app/services/sse_transformation.py`
- **Purpose**: Core SSE event transformation logic
- **Key Classes**: `ADKEventTransformationService`, `ProcessedEvent`, `TransformationMetrics`
- **Dependencies**: `google.adk.events`, `typing`, `dataclasses`
- **Size Estimate**: ~300-400 lines

#### `app/services/adk_integration.py`
- **Purpose**: Integration patterns with ADK FastAPI app
- **Key Functions**: `enhanced_run_sse()`, `get_adk_event_stream()`
- **Dependencies**: `google.adk.cli.fast_api`, `fastapi`
- **Size Estimate**: ~150-200 lines

#### `app/services/monitoring.py`
- **Purpose**: Observability, metrics, and monitoring
- **Key Classes**: `TransformationMonitoring`, `MetricsCollector`
- **Dependencies**: `google.cloud.logging`, `opentelemetry`
- **Size Estimate**: ~200-250 lines

#### `app/services/session_manager.py`
- **Purpose**: Session state management and persistence
- **Key Classes**: `SessionStateManager`, `SessionState`
- **Dependencies**: `typing`, `asyncio`, `time`
- **Size Estimate**: ~150-200 lines

### 2. Schema Files

#### `app/schemas/sse_events.py`
- **Purpose**: Type definitions for SSE events and transformations
- **Key Types**: `ADKEvent`, `ProcessedEvent`, `TransformationMetadata`
- **Dependencies**: `pydantic`, `typing`, `google.adk.events`
- **Size Estimate**: ~100-150 lines

#### `app/schemas/transformation.py`
- **Purpose**: Transformation service configuration and request/response schemas
- **Key Types**: `TransformationConfig`, `TransformationRequest`, `TransformationResponse`
- **Dependencies**: `pydantic`, `typing`
- **Size Estimate**: ~75-100 lines

#### `app/schemas/monitoring.py`
- **Purpose**: Monitoring and health check schemas
- **Key Types**: `HealthCheckResponse`, `MetricsResponse`, `ServiceStatus`
- **Dependencies**: `pydantic`, `enum`
- **Size Estimate**: ~50-75 lines

### 3. Middleware Files

#### `app/middleware/error_handling.py`
- **Purpose**: Global error handling for transformation service
- **Key Classes**: `TransformationErrorHandler`
- **Dependencies**: `fastapi`, `logging`
- **Size Estimate**: ~100-125 lines

#### `app/middleware/logging.py`
- **Purpose**: Enhanced logging middleware for SSE events
- **Key Classes**: `SSELoggingMiddleware`
- **Dependencies**: `fastapi`, `google.cloud.logging`
- **Size Estimate**: ~75-100 lines

#### `app/middleware/metrics.py`
- **Purpose**: Request and response metrics collection
- **Key Classes**: `MetricsMiddleware`
- **Dependencies**: `fastapi`, `time`, `typing`
- **Size Estimate**: ~75-100 lines

### 4. Enhanced Existing Files

#### `app/config.py` (Enhanced)
```python
# Additional configuration for SSE transformation
@dataclass
class ResearchConfiguration:
    # ... existing fields ...
    
    # SSE Transformation Settings
    transformation_enabled: bool = True
    max_events_per_session: int = 1000
    session_state_ttl: int = 3600
    error_threshold: float = 0.1
    monitoring_enabled: bool = True
    metrics_collection_interval: int = 60
```

#### `app/server.py` (Enhanced)
```python
# Additional endpoints for transformation service
@app.get("/health/transformation")
async def transformation_health(): ...

@app.get("/metrics/transformation") 
async def transformation_metrics(): ...

@app.post("/api/run_sse_enhanced")
async def enhanced_run_sse(): ...
```

### 5. Utility Files

#### `app/utils/health_checks.py`
- **Purpose**: Health check utilities for services
- **Key Functions**: `check_transformation_service()`, `check_adk_integration()`
- **Dependencies**: `asyncio`, `typing`
- **Size Estimate**: ~75-100 lines

#### `app/utils/json_serialization.py`
- **Purpose**: JSON serialization utilities for ADK events
- **Key Functions**: `serialize_adk_event()`, `deserialize_event()`
- **Dependencies**: `json`, `typing`, `google.adk.events`
- **Size Estimate**: ~50-75 lines

## Implementation Priority

### Phase 1: Core Service Layer (Week 1)
1. `app/services/sse_transformation.py` - Core transformation logic
2. `app/schemas/sse_events.py` - Event type definitions
3. `tests/unit/services/test_sse_transformation.py` - Unit tests

### Phase 2: Integration Layer (Week 2)  
1. `app/services/adk_integration.py` - ADK integration patterns
2. `app/server.py` (enhanced) - New endpoints
3. `tests/integration/test_sse_endpoint.py` - Integration tests

### Phase 3: Observability Layer (Week 3)
1. `app/services/monitoring.py` - Monitoring and metrics
2. `app/middleware/` - All middleware files
3. `app/utils/health_checks.py` - Health check utilities

### Phase 4: Testing & Documentation (Week 4)
1. Complete test coverage
2. Load testing implementation
3. Documentation updates

## File Creation Commands

For development efficiency, here are the commands to create the directory structure:

```bash
# Create service directories
mkdir -p app/services app/schemas app/middleware
mkdir -p tests/unit/services tests/unit/schemas tests/unit/utils

# Create __init__.py files
touch app/services/__init__.py app/schemas/__init__.py app/middleware/__init__.py
touch tests/unit/services/__init__.py tests/unit/schemas/__init__.py tests/unit/utils/__init__.py

# Create main service files
touch app/services/sse_transformation.py
touch app/services/adk_integration.py  
touch app/services/monitoring.py
touch app/services/session_manager.py

# Create schema files
touch app/schemas/sse_events.py
touch app/schemas/transformation.py
touch app/schemas/monitoring.py

# Create middleware files
touch app/middleware/error_handling.py
touch app/middleware/logging.py
touch app/middleware/metrics.py

# Create utility files
touch app/utils/health_checks.py
touch app/utils/json_serialization.py

# Create test files
touch tests/unit/services/test_sse_transformation.py
touch tests/unit/services/test_adk_integration.py
touch tests/unit/services/test_monitoring.py
touch tests/unit/services/test_session_manager.py
touch tests/unit/schemas/test_sse_events.py
touch tests/unit/utils/test_health_checks.py
touch tests/integration/test_sse_endpoint.py
touch tests/integration/test_transformation_flow.py
touch tests/load_test/sse_load_test.py
```

## Dependency Management

### New Dependencies (add to pyproject.toml)
```toml
[project.dependencies]
# Existing dependencies preserved
# Additional dependencies for SSE transformation:
# (Most dependencies already covered by ADK)
```

### Import Organization Standards
- **Services**: Import from `app.services`
- **Schemas**: Import from `app.schemas`
- **Middleware**: Import from `app.middleware`  
- **Utils**: Import from `app.utils`

Example:
```python
from app.services.sse_transformation import ADKEventTransformationService
from app.schemas.sse_events import ProcessedEvent
from app.utils.health_checks import check_transformation_service
```

## Configuration Management

### Environment Variables
```bash
# New environment variables for SSE transformation
SSE_TRANSFORMATION_ENABLED=true
SSE_MAX_EVENTS_PER_SESSION=1000
SSE_SESSION_TTL=3600
SSE_ERROR_THRESHOLD=0.1
SSE_MONITORING_ENABLED=true
```

### Config File Updates
The `app/config.py` file will be enhanced to include SSE transformation settings while maintaining backward compatibility with existing configuration.

## Conclusion

This file structure plan provides:

✅ **Clear Separation of Concerns**: Services, schemas, middleware, and utilities are properly organized  
✅ **ADK Compliance**: Follows established ADK patterns and doesn't interfere with existing functionality  
✅ **Testability**: Comprehensive test structure with unit, integration, and load tests  
✅ **Maintainability**: Logical organization that scales with future enhancements  
✅ **Backward Compatibility**: Existing files are enhanced, not replaced  

The structure supports incremental implementation, allowing the team to deliver value early while building toward the complete solution.

<function_calls>
<invoke name="TodoWrite">
<parameter name="todos">[{"id": "analyze-adk-sse", "content": "Analyze ADK's existing SSE implementation in get_fast_api_app() and /api/run_sse endpoint", "status": "completed", "priority": "high"}, {"id": "document-event-structure", "content": "Document actual ADK event structure, types, and field meanings", "status": "completed", "priority": "high"}, {"id": "design-transformation-service", "content": "Create event transformation service design for ADK to frontend compatibility", "status": "completed", "priority": "high"}, {"id": "plan-file-structure", "content": "Plan file structure for backend SSE changes and integration", "status": "completed", "priority": "medium"}]