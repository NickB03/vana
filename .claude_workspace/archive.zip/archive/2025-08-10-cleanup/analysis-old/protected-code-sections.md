# Protected Code Sections - DO NOT MODIFY

## Critical Runtime Fixes

### 1. Type Import Syntax
**Files**: All context files (AppContext, AuthContext, SessionContext, SSEContext)
```typescript
// CORRECT - DO NOT CHANGE
import type { AppAction } from '@/types/app';
import type { AuthState } from '@/types/auth';

// WRONG - Would cause runtime errors
import { AppAction } from '@/types/app';
```

### 2. Enum Imports
**Files**: sse-manager.ts, adk-client.ts
```typescript
// CORRECT - Enums must be imported as values
import { ConnectionState } from '../types/adk-service';

// WRONG - Would cause "Can't find variable" error
import type { ConnectionState } from '../types/adk-service';
```

### 3. SSE useEffect Dependencies
**File**: SSEContext.tsx (line 1057)
```typescript
// CORRECT - Prevents infinite loops
}, [user, state.enabled]);

// WRONG - Causes infinite re-renders
}, [user, state.enabled, state.connection.readyState, connect, disconnect]);
```

### 4. Services Initialization
**File**: ServicesContext.tsx (lines 165-172)
```typescript
// CORRECT - Immediate initialization
if (!servicesRef.current && !isInitializedRef.current) {
  servicesRef.current = createServices(configRef.current);
  isInitializedRef.current = true;
}
```

### 5. SimplifiedThinkingPanel Auto-Expansion
**File**: SimplifiedThinkingPanel.tsx (lines 89-98)
```typescript
// CORRECT - Tracks user intent properly
if (hasActiveAgents && !isExpanded && !userManuallyCollapsed) {
  setIsExpanded(true);
}
```

## Safe to Modify

### 1. Type Definitions
- Add missing properties to interfaces
- Fix property name mismatches
- Add optional modifiers where appropriate

### 2. Test Files
- Add jest-dom type imports
- Fix assertion types
- Update mock implementations

### 3. Unused Imports
- Remove with automated tools
- Won't affect runtime behavior

### 4. Example Files
- App.example.tsx can be updated
- Not used in production

### 5. Configuration Files
- vite.config.ts test section
- tsconfig.json type additions

## Why These Are Protected

1. **Type Imports**: The distinction between type and value imports is critical in TypeScript with `verbatimModuleSyntax`. Changing these would reintroduce runtime errors.

2. **SSE Dependencies**: The reduced dependency list prevents React from creating infinite update loops. The removed dependencies were causing the effect to fire continuously.

3. **Services Initialization**: The synchronous initialization ensures services are available before first render, preventing "services not initialized" errors.

4. **Auto-Expansion Logic**: The `userManuallyCollapsed` flag respects user intent while still allowing automatic expansion for new agent activity.

## Validation Checklist

Before making any changes:
- [ ] Does it modify import syntax for types?
- [ ] Does it change useEffect dependencies?
- [ ] Does it alter service initialization timing?
- [ ] Does it affect the auto-expansion logic?

If YES to any - DO NOT MODIFY without careful consideration.