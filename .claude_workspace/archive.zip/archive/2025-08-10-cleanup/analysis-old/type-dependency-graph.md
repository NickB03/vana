# Type Dependency Graph - Vana Frontend

## Core Type Dependencies

```mermaid
graph TD
    %% Core Types
    app[app.ts] --> notification[NotificationItem]
    auth[auth.ts] --> user[User]
    session[session.ts] --> message[AgentMessage]
    sse[sse.ts] --> events[SSEEvent]
    adk-service[adk-service.ts] --> connection[ConnectionState]
    
    %% Component Dependencies
    ChatInterface --> message
    ChatInterface --> thinking[ThinkingStep]
    SimplifiedThinkingPanel --> thinking
    AgentProgress --> agent[AgentMetrics]
    MessageActions --> message
    
    %% Context Dependencies
    AppContext --> app
    AppContext --> notification
    AuthContext --> auth
    AuthContext --> user
    SessionContext --> session
    SessionContext --> message
    SSEContext --> sse
    SSEContext --> adk-events[adk-events.ts]
    ServicesContext --> adk-service
    
    %% Service Dependencies
    adk-client --> adk-service
    sse-manager --> adk-service
    sse-manager --> adk-events
    session-service --> session
    
    %% Test Dependencies
    tests[Test Files] --> jest-dom[@testing-library/jest-dom]
    tests --> all-types[All Type Files]
```

## Type Issue Cascade Analysis

### 1. NotificationItem (HIGH IMPACT)
**Missing**: `dismissible: boolean`
**Affects**: 
- App.example.tsx (8 errors)
- AppContext.test.tsx (1 error)
- integration.test.tsx (1 error)
**Total Impact**: 10 errors

### 2. AgentMetrics (HIGH IMPACT)
**Issues**:
- `is_active` doesn't exist (should be `status`?)
- `average_execution_time` should be `avg_execution_time`
- `tools_used` doesn't exist
**Affects**:
- InspectorPanel.tsx (15 errors)
**Total Impact**: 15 errors

### 3. Jest DOM Types (MEDIUM IMPACT)
**Missing**: Type definitions for assertions
**Affects**:
- All test files (~50 errors)
**Total Impact**: 50 errors

### 4. Message Status Type (MEDIUM IMPACT)
**Issue**: String not assignable to union type
**Affects**:
- ChatInterface.tsx (1 error)
**Fix**: Proper type narrowing or status constants

### 5. ThinkingStep Export (LOW IMPACT)
**Issue**: Not exported from adk-events
**Affects**:
- MultiAgentCanvas/index.tsx (1 error)
**Fix**: Add export or import from correct location

## Fix Order Recommendation

### Phase 1: Core Type Fixes
1. **NotificationItem** - Add `dismissible?: boolean`
2. **AgentMetrics** - Fix property names
3. **Message status** - Add type constants

### Phase 2: Type Exports
1. Export ThinkingStep from appropriate module
2. Fix ApplicationInfo properties
3. Add missing service method types

### Phase 3: Test Infrastructure
1. Install @testing-library/jest-dom types
2. Update tsconfig.json to include types
3. Fix test utility types

### Phase 4: Cleanup
1. Remove unused imports
2. Fix vite.config.ts structure
3. Update example files

## Type Definition Locations

- **Core Types**: `/frontend/src/types/`
- **Component Types**: Colocated with components
- **Test Types**: `/frontend/src/test/utils/`
- **External Types**: `node_modules/@types/`

## Critical Type Relationships

1. **SSE → ADK Events**: SSEContext depends on ADK event types
2. **Session → Messages**: Session management tied to message types
3. **App → Notifications**: Global notification system
4. **Services → All**: Service layer touches all type systems

## Validation Strategy

After each phase:
1. Run `npm run build`
2. Check error count reduction
3. Verify no new errors introduced
4. Test runtime functionality