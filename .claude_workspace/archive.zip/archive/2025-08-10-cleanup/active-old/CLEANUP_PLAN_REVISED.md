# 🧹 Vana Repository Cleanup Plan (Revised)

## Summary
155 total uncommitted changes to review and clean up
**Important**: Frontend directory will be removed but NOT ignored (for rebuild)

---

## 📊 Current State Analysis

### 1. Frontend Deletions (148 files) - **REMOVE FROM GIT**
All `frontend/` directory files marked for deletion to make way for new frontend.
**Action**: Remove these deletions from git tracking
```bash
git rm -r frontend/
```

### 2. Untracked Auxiliary Directories - **DO NOT COMMIT**
```
.claude-flow/      # Claude Flow metrics (local only)
.roo/             # Roo development files (local only)  
.roomodes         # Roo modes config (local only)
memory/           # Local memory storage (not for git)
scripts/          # Contains setup-mcp-servers.sh (keep local)
tests/utils/      # Test utilities (review individually)
```

### 3. Frontend Backup Archive - **REMOVE**
```
frontend-backup-20250727-221746.tar.gz  # Old backup, not needed
```

---

## ✅ What Should STAY (Keep in Git)

### Essential Project Files
- ✅ `README.md` (main project docs)
- ✅ `CLAUDE.md` (already updated & committed)
- ✅ `API.md`, `CONTRIBUTING.md`, `DEPLOYMENT.md` 
- ✅ `GEMINI.md`, `ADK-STARTER-PACK-README.md`
- ✅ `LICENSE`, `Dockerfile`, `.env` files
- ✅ `pyproject.toml` (Python config)
- ✅ `.gitignore` (already updated)
- ✅ `.mcp.json` (MCP configuration)

### Backend Code (Already Committed)
- ✅ All `app/` directory files
- ✅ All `tests/` backend tests
- ✅ `deployment/` documentation

### Claude Workspace Structure
- ✅ `.claude_workspace/active/` (active plans)
- ✅ `.claude_workspace/archive/` (historical docs)
- ✅ `.claude_workspace/reports/` (progress reports)

---

## ❌ What Should GO (Remove/Ignore)

### Frontend Directory (Complete Removal - NOT IGNORED)
```bash
# Remove entire frontend directory from git (but don't add to .gitignore)
git rm -r frontend/
```

### Local Development Files (Add to .gitignore)
```
.claude-flow/
.roo/
.roomodes
memory/
scripts/setup-mcp-servers.sh
*.pid
*.log
frontend-backup-*.tar.gz
```

### Test Utilities (Review Individually)
- Check if `tests/utils/` contains backend test helpers
- If backend-related: keep
- If frontend-related: remove

---

## 🔧 Cleanup Commands

### Step 1: Update .gitignore (WITHOUT frontend/)
```bash
cat >> .gitignore << 'EOF'

# Local development
.claude-flow/
.roo/
.roomodes
memory/
scripts/setup-mcp-servers.sh

# Temp files
*.pid
*.log
frontend-backup-*.tar.gz

# Node modules (for when we rebuild frontend)
node_modules/
dist/
.vite/
EOF
```

### Step 2: Remove old frontend from git
```bash
# Remove frontend directory completely (clean slate for rebuild)
git rm -r frontend/

# Remove backup archive if it exists
git rm frontend-backup-20250727-221746.tar.gz 2>/dev/null || true
```

### Step 3: Clean working directory
```bash
# Remove local temp files
rm -f *.pid *.log
rm -f frontend-backup-*.tar.gz

# Keep the frontend directory path available for new build
# (git rm only removes from tracking, not from filesystem)
```

### Step 4: Commit cleanup
```bash
git add .gitignore
git commit -m "chore: Remove old frontend for rebuild

- Removed old frontend directory from git tracking
- Updated .gitignore for local development files
- Cleaned up temporary files and backups
- Ready for new frontend implementation per rebuild plan"
```

---

## 📝 Final State

After cleanup:
- **Root directory**: Clean, only essential files
- **Backend**: Fully functional and committed
- **Frontend**: Removed from git, ready for fresh rebuild
- **Documentation**: Organized in .claude_workspace
- **Local files**: Properly ignored
- **Frontend path**: Available for new implementation

---

## 🚀 Next Steps

1. Execute cleanup commands above
2. Push cleanup commit
3. Start frontend rebuild from VANA_FRONTEND_REBUILD_PLAN.md
4. New frontend will be created in `frontend/` directory
5. New frontend files will be tracked in git normally

---

## 📦 What the New Frontend Will Include

Per the rebuild plan:
- Clean React + TypeScript setup
- Proper ADK integration layer
- Preserved Kibo UI/shadcn components
- Single source of truth (Zustand store)
- Proper SSE handling for agent events