# 🚀 VANA Frontend Rebuild Implementation Plan

## Executive Summary
Complete frontend rebuild preserving Kibo UI/shadcn design while properly integrating with Google ADK standards.

---

## 📋 PROJECT STRUCTURE

```
vana/
├── frontend-v2/                 # New clean frontend
│   ├── src/
│   │   ├── lib/                # Core utilities
│   │   │   ├── adk/           # ADK integration layer
│   │   │   │   ├── client.ts  # Single ADK client
│   │   │   │   ├── types.ts   # ADK type definitions
│   │   │   │   └── session.ts # Session management
│   │   │   ├── utils.ts       # Utility functions
│   │   │   └── cn.ts          # Class name utilities
│   │   ├── components/
│   │   │   ├── ui/            # shadcn/ui components (preserve existing)
│   │   │   ├── layout/        # Layout components
│   │   │   ├── landing/       # Landing page components
│   │   │   ├── chat/          # Chat interface
│   │   │   └── agents/        # Agent visualization
│   │   ├── hooks/             # Custom React hooks
│   │   ├── stores/            # Zustand stores (single source of truth)
│   │   ├── styles/            # Global styles & themes
│   │   └── types/             # TypeScript definitions
├── frontend/                   # Existing frontend (preserve temporarily)
└── app/                       # Backend (no changes needed)
```

---

## 🎯 PHASE 1: Foundation & Setup (Day 1-2)

### 1.1 Project Initialization
```bash
# Create new frontend directory
mkdir frontend-v2
cd frontend-v2
npm create vite@latest . -- --template react-ts
npm install
```

### 1.2 Install Core Dependencies
```json
{
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "@radix-ui/react-*": "latest",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.1.0",
    "tailwind-merge": "^2.2.0",
    "zustand": "^4.5.0",
    "lucide-react": "latest"
  },
  "devDependencies": {
    "@types/react": "^18.3.3",
    "@types/react-dom": "^18.3.0",
    "typescript": "^5.5.3",
    "vite": "^5.4.1",
    "tailwindcss": "^3.4.0",
    "autoprefixer": "^10.4.19",
    "postcss": "^8.4.38"
  }
}
```

### 1.3 Copy Design Assets
```bash
# Copy existing design elements
cp -r ../frontend/src/components/ui frontend-v2/src/components/
cp ../frontend/src/styles/globals.css frontend-v2/src/styles/
cp ../frontend/tailwind.config.js frontend-v2/
cp ../frontend/src/lib/utils.ts frontend-v2/src/lib/
```

### 1.4 Configure TypeScript for ADK
```typescript
// tsconfig.json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}
```

---

## 🔌 PHASE 2: ADK Integration Layer (Day 3-4)

### 2.1 ADK Types Definition
```typescript
// src/lib/adk/types.ts
export interface ADKSession {
  sessionId: string;
  userId: string;
  appName: string;
  createdAt: string;
  lastActivity: string;
}

export interface ADKMessage {
  role: 'user' | 'assistant' | 'system';
  parts: Array<{
    text?: string;
    functionCall?: {
      name: string;
      args: Record<string, any>;
    };
    functionResponse?: {
      name: string;
      response: any;
    };
  }>;
}

export interface ADKRunRequest {
  app_name: string;
  user_id: string;
  session_id: string;
  new_message: ADKMessage;
  streaming: boolean;
}

export interface ADKEvent {
  candidates?: Array<{
    content: ADKMessage;
    finishReason?: string;
  }>;
  usageMetadata?: {
    promptTokenCount: number;
    candidatesTokenCount: number;
  };
}
```

### 2.2 ADK Client Implementation
```typescript
// src/lib/adk/client.ts
export class ADKClient {
  private baseUrl: string;
  private appName: string;
  private eventSource: EventSource | null = null;

  constructor(baseUrl: string = 'http://localhost:8000', appName: string = 'app') {
    this.baseUrl = baseUrl;
    this.appName = appName;
  }

  async createSession(userId: string): Promise<ADKSession> {
    const response = await fetch(
      `${this.baseUrl}/apps/${this.appName}/users/${userId}/sessions`,
      { method: 'POST' }
    );
    return response.json();
  }

  async getSession(userId: string, sessionId: string): Promise<ADKSession> {
    const response = await fetch(
      `${this.baseUrl}/apps/${this.appName}/users/${userId}/sessions/${sessionId}`
    );
    return response.json();
  }

  streamMessage(
    userId: string,
    sessionId: string,
    message: string,
    onEvent: (event: ADKEvent) => void,
    onError: (error: Error) => void
  ): () => void {
    const request: ADKRunRequest = {
      app_name: this.appName,
      user_id: userId,
      session_id: sessionId,
      new_message: {
        role: 'user',
        parts: [{ text: message }]
      },
      streaming: true
    };

    // Send via fetch with SSE response
    fetch(`${this.baseUrl}/run_sse?alt=sse`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request)
    }).then(response => {
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      
      const readStream = async () => {
        while (reader) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              if (data === '[DONE]') return;
              
              try {
                const event = JSON.parse(data);
                onEvent(event);
              } catch (e) {
                console.error('Parse error:', e);
              }
            }
          }
        }
      };
      
      readStream().catch(onError);
    }).catch(onError);

    // Return cleanup function
    return () => {
      // Cleanup logic
    };
  }
}
```

### 2.3 Session Management
```typescript
// src/lib/adk/session.ts
import { ADKClient } from './client';
import { ADKSession } from './types';

export class SessionManager {
  private client: ADKClient;
  private currentSession: ADKSession | null = null;

  constructor(client: ADKClient) {
    this.client = client;
  }

  async initializeSession(userId: string): Promise<ADKSession> {
    // Try to restore from localStorage
    const stored = localStorage.getItem('adk_session');
    if (stored) {
      const session = JSON.parse(stored) as ADKSession;
      try {
        // Validate session still exists
        const validated = await this.client.getSession(userId, session.sessionId);
        this.currentSession = validated;
        return validated;
      } catch {
        // Session invalid, create new
      }
    }

    // Create new session
    const session = await this.client.createSession(userId);
    this.currentSession = session;
    localStorage.setItem('adk_session', JSON.stringify(session));
    return session;
  }

  getSession(): ADKSession | null {
    return this.currentSession;
  }
}
```

---

## 🎨 PHASE 3: UI Components Migration (Day 5-7)

### 3.1 State Management (Single Source of Truth)
```typescript
// src/stores/app.store.ts
import { create } from 'zustand';
import { ADKClient, SessionManager } from '@/lib/adk';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  status: 'sending' | 'sent' | 'error';
}

interface AgentActivity {
  id: string;
  agent: string;
  action: string;
  status: 'active' | 'complete';
  timestamp: Date;
}

interface AppState {
  // Session
  userId: string;
  sessionId: string | null;
  
  // Messages
  messages: Message[];
  isStreaming: boolean;
  
  // Agent Canvas
  isAgentPanelOpen: boolean;
  agentActivities: AgentActivity[];
  
  // Actions
  initializeSession: (userId: string) => Promise<void>;
  sendMessage: (content: string) => Promise<void>;
  toggleAgentPanel: () => void;
}

const adkClient = new ADKClient();
const sessionManager = new SessionManager(adkClient);

export const useAppStore = create<AppState>((set, get) => ({
  userId: 'default_user',
  sessionId: null,
  messages: [],
  isStreaming: false,
  isAgentPanelOpen: false,
  agentActivities: [],

  initializeSession: async (userId: string) => {
    const session = await sessionManager.initializeSession(userId);
    set({ userId, sessionId: session.sessionId });
  },

  sendMessage: async (content: string) => {
    const { userId, sessionId } = get();
    if (!sessionId) throw new Error('No session');

    const messageId = `msg_${Date.now()}`;
    
    // Add user message
    set(state => ({
      messages: [...state.messages, {
        id: messageId,
        role: 'user',
        content,
        timestamp: new Date(),
        status: 'sent'
      }],
      isStreaming: true
    }));

    // Stream response
    let assistantMessage = '';
    const assistantId = `asst_${Date.now()}`;

    adkClient.streamMessage(
      userId,
      sessionId,
      content,
      (event) => {
        // Handle streaming events
        if (event.candidates?.[0]?.content?.parts) {
          for (const part of event.candidates[0].content.parts) {
            if (part.text) {
              assistantMessage += part.text;
              set(state => ({
                messages: state.messages.map(m =>
                  m.id === assistantId
                    ? { ...m, content: assistantMessage }
                    : m
                )
              }));
            }
            if (part.functionCall) {
              // Update agent activities
              set(state => ({
                isAgentPanelOpen: true,
                agentActivities: [...state.agentActivities, {
                  id: `activity_${Date.now()}`,
                  agent: part.functionCall.name,
                  action: 'Processing',
                  status: 'active',
                  timestamp: new Date()
                }]
              }));
            }
          }
        }
      },
      (error) => {
        console.error('Stream error:', error);
        set({ isStreaming: false });
      }
    );

    // Add assistant message container
    set(state => ({
      messages: [...state.messages, {
        id: assistantId,
        role: 'assistant',
        content: '',
        timestamp: new Date(),
        status: 'sending'
      }]
    }));
  },

  toggleAgentPanel: () => {
    set(state => ({ isAgentPanelOpen: !state.isAgentPanelOpen }));
  }
}));
```

### 3.2 Landing Page (Preserve Design)
```typescript
// src/components/landing/LandingPage.tsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAppStore } from '@/stores/app.store';

export function LandingPage() {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();
  const initializeSession = useAppStore(state => state.initializeSession);

  const handleStart = async () => {
    await initializeSession('default_user');
    navigate('/chat', { state: { initialQuery: query } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white">
      {/* Preserve existing landing page design */}
      <div className="container mx-auto px-4 py-16">
        <h1 className="text-6xl font-bold mb-8">VANA</h1>
        <p className="text-xl mb-12">Multi-Agent AI Research Assistant</p>
        
        <div className="max-w-2xl mx-auto">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="What would you like to research?"
            className="mb-4"
          />
          <Button onClick={handleStart} size="lg" className="w-full">
            Start Research
          </Button>
        </div>
      </div>
    </div>
  );
}
```

### 3.3 Chat Interface with Agent Canvas
```typescript
// src/components/chat/ChatInterface.tsx
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useAppStore } from '@/stores/app.store';
import { MessageList } from './MessageList';
import { MessageInput } from './MessageInput';
import { AgentCanvas } from '@/components/agents/AgentCanvas';
import { cn } from '@/lib/utils';

export function ChatInterface() {
  const location = useLocation();
  const { 
    messages, 
    isStreaming, 
    isAgentPanelOpen,
    sendMessage 
  } = useAppStore();

  useEffect(() => {
    // Send initial query if provided
    const initialQuery = location.state?.initialQuery;
    if (initialQuery) {
      sendMessage(initialQuery);
    }
  }, []);

  return (
    <div className="flex h-screen bg-gray-950">
      {/* Main Chat Area */}
      <div className={cn(
        "flex-1 flex flex-col transition-all duration-300",
        isAgentPanelOpen ? "mr-96" : ""
      )}>
        <MessageList messages={messages} />
        <MessageInput 
          onSend={sendMessage} 
          disabled={isStreaming}
        />
      </div>

      {/* Agent Canvas Panel (Expandable) */}
      <AgentCanvas />
    </div>
  );
}
```

### 3.4 Agent Canvas Component
```typescript
// src/components/agents/AgentCanvas.tsx
import { useAppStore } from '@/stores/app.store';
import { Card } from '@/components/ui/card';
import { X, Maximize2, Minimize2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export function AgentCanvas() {
  const { isAgentPanelOpen, agentActivities, toggleAgentPanel } = useAppStore();
  const [isExpanded, setIsExpanded] = useState(false);

  if (!isAgentPanelOpen) return null;

  return (
    <div className={cn(
      "fixed right-0 top-0 h-full bg-gray-900 border-l border-gray-800 transition-all duration-300",
      isExpanded ? "w-[60%]" : "w-96"
    )}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800">
        <h2 className="text-lg font-semibold text-white">Agent Activity</h2>
        <div className="flex gap-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 hover:bg-gray-800 rounded"
          >
            {isExpanded ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
          </button>
          <button
            onClick={toggleAgentPanel}
            className="p-1 hover:bg-gray-800 rounded"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Activity List */}
      <div className="p-4 space-y-3 overflow-y-auto h-[calc(100%-64px)]">
        {agentActivities.map(activity => (
          <Card key={activity.id} className="p-3 bg-gray-800 border-gray-700">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-medium text-white">{activity.agent}</p>
                <p className="text-sm text-gray-400">{activity.action}</p>
              </div>
              <span className={cn(
                "px-2 py-1 text-xs rounded",
                activity.status === 'active' 
                  ? "bg-blue-500/20 text-blue-400" 
                  : "bg-green-500/20 text-green-400"
              )}>
                {activity.status}
              </span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
```

---

## 🧪 PHASE 4: Testing & Validation (Day 8-9)

### 4.1 ADK Integration Tests
```typescript
// src/lib/adk/__tests__/client.test.ts
import { ADKClient } from '../client';

describe('ADKClient', () => {
  it('creates session with correct endpoint', async () => {
    const client = new ADKClient('http://localhost:8000', 'app');
    const mockFetch = jest.fn().mockResolvedValue({
      json: async () => ({ sessionId: 'test-session', userId: 'user1' })
    });
    global.fetch = mockFetch;

    await client.createSession('user1');
    
    expect(mockFetch).toHaveBeenCalledWith(
      'http://localhost:8000/apps/app/users/user1/sessions',
      { method: 'POST' }
    );
  });

  it('formats message correctly for ADK', () => {
    // Test message formatting matches ADK expectations
  });
});
```

### 4.2 E2E Testing
```typescript
// e2e/adk-flow.spec.ts
import { test, expect } from '@playwright/test';

test('complete ADK flow', async ({ page }) => {
  await page.goto('http://localhost:5173');
  
  // Start from landing
  await page.fill('[placeholder="What would you like to research?"]', 'Test query');
  await page.click('button:has-text("Start Research")');
  
  // Verify navigation to chat
  await expect(page).toHaveURL(/.*\/chat/);
  
  // Verify message sent
  await expect(page.locator('.message-user')).toContainText('Test query');
  
  // Verify agent panel opens
  await expect(page.locator('[data-testid="agent-canvas"]')).toBeVisible();
});
```

---

## 🚀 PHASE 5: Migration & Deployment (Day 10)

### 5.1 Migration Script
```bash
#!/bin/bash
# migrate.sh

echo "Starting Vana Frontend Migration..."

# 1. Build new frontend
cd frontend-v2
npm run build

# 2. Backup existing frontend
cd ..
mv frontend frontend-backup-$(date +%Y%m%d)

# 3. Move new frontend into place
mv frontend-v2 frontend

# 4. Update nginx/proxy configuration
# Update paths to point to new frontend

echo "Migration complete!"
```

### 5.2 Validation Checklist
- [ ] ADK session creation works
- [ ] Messages stream properly via /run_sse
- [ ] Agent activities display in canvas
- [ ] No console errors
- [ ] TypeScript compilation passes
- [ ] All shadcn/ui components render correctly
- [ ] Color scheme matches original
- [ ] Landing page preserves design
- [ ] Chat interface maintains layout
- [ ] Agent panel expands/collapses smoothly

---

## 📊 Success Metrics

1. **Zero Duplicate Code**: Single ADKClient, single store
2. **Type Safety**: 100% TypeScript coverage, no `any` types
3. **ADK Compliance**: All API calls match ADK contract
4. **Performance**: <100ms response time for UI interactions
5. **Bundle Size**: <200KB gzipped
6. **Test Coverage**: >80% for critical paths

---

## 🔧 Implementation Commands

```bash
# Start development
cd frontend-v2
npm run dev

# Run tests
npm run test

# Type check
npm run type-check

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 📝 Notes

- Keep `frontend-backup` directory until new frontend is stable
- Run both frontends side-by-side during transition
- Use feature flags to gradually migrate users
- Monitor error rates during migration
- Keep ADK client minimal - let backend handle complexity

This plan ensures a clean, maintainable frontend that properly integrates with Google ADK while preserving your design vision.