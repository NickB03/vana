# 🧹 Vana Repository Cleanup Plan

## Summary
155 total uncommitted changes to review and clean up

---

## 📊 Current State Analysis

### 1. Frontend Deletions (148 files) - **REMOVE FROM GIT**
All `frontend/` directory files marked for deletion since we're rebuilding from scratch.
**Action**: Remove these deletions from git tracking
```bash
git rm -r frontend/
```

### 2. Untracked Auxiliary Directories - **DO NOT COMMIT**
```
.claude-flow/      # Claude Flow metrics (local only)
.roo/             # Roo development files (local only)  
.roomodes         # Roo modes config (local only)
memory/           # Local memory storage (not for git)
scripts/          # Contains setup-mcp-servers.sh (keep local)
tests/utils/      # Test utilities (review individually)
```

### 3. Frontend Backup Archive - **REMOVE**
```
frontend-backup-20250727-221746.tar.gz  # Old backup, not needed
```

---

## ✅ What Should STAY (Keep in Git)

### Essential Project Files
- ✅ `README.md` (main project docs)
- ✅ `CLAUDE.md` (already updated & committed)
- ✅ `API.md`, `CONTRIBUTING.md`, `DEPLOYMENT.md` 
- ✅ `GEMINI.md`, `ADK-STARTER-PACK-README.md`
- ✅ `LICENSE`, `Dockerfile`, `.env` files
- ✅ `pyproject.toml` (Python config)
- ✅ `.gitignore` (already updated)
- ✅ `.mcp.json` (MCP configuration)

### Backend Code (Already Committed)
- ✅ All `app/` directory files
- ✅ All `tests/` backend tests
- ✅ `deployment/` documentation

### Claude Workspace Structure
- ✅ `.claude_workspace/active/` (active plans)
- ✅ `.claude_workspace/archive/` (historical docs)
- ✅ `.claude_workspace/reports/` (progress reports)

---

## ❌ What Should GO (Remove/Ignore)

### Frontend Directory (Complete Removal)
```bash
# Remove entire frontend directory from git
git rm -r frontend/
```

### Local Development Files (Add to .gitignore)
```
.claude-flow/
.roo/
.roomodes
memory/
scripts/setup-mcp-servers.sh
*.pid
*.log
frontend-backup-*.tar.gz
```

### Test Utilities (Review Individually)
- Check if `tests/utils/` contains backend test helpers
- If backend-related: keep
- If frontend-related: remove

---

## 🔧 Cleanup Commands

### Step 1: Update .gitignore
```bash
cat >> .gitignore << 'EOF'

# Local development
.claude-flow/
.roo/
.roomodes
memory/
scripts/setup-mcp-servers.sh

# Temp files
*.pid
*.log
frontend-backup-*.tar.gz

# Frontend (temporarily while rebuilding)
frontend/
EOF
```

### Step 2: Remove frontend from git
```bash
# Remove frontend directory completely
git rm -r frontend/

# Remove backup archive
git rm frontend-backup-20250727-221746.tar.gz 2>/dev/null || true
```

### Step 3: Clean working directory
```bash
# Remove local temp files
rm -f *.pid *.log
rm -f frontend-backup-*.tar.gz
```

### Step 4: Commit cleanup
```bash
git add .gitignore
git commit -m "chore: Remove old frontend and clean repository

- Removed entire frontend directory for rebuild
- Updated .gitignore for local development files
- Cleaned up temporary files and backups
- Preserved backend and documentation"
```

---

## 📝 Final State

After cleanup:
- **Root directory**: Clean, only essential files
- **Backend**: Fully functional and committed
- **Frontend**: Removed, ready for rebuild
- **Documentation**: Organized in .claude_workspace
- **Local files**: Properly ignored

---

## 🚀 Next Steps

1. Execute cleanup commands above
2. Push cleanup commit
3. Start frontend rebuild from VANA_FRONTEND_REBUILD_PLAN.md