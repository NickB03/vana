#!/bin/bash

# Vana Development Environment Stop Script
# This script cleanly stops all Vana services

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
FRONTEND_DIR="/Users/nick/Development/vana/frontend"
BACKEND_DIR="/Users/nick/Development/vana"
FRONTEND_PORT=5173
BACKEND_PORT=8000

# Function to print colored output
print_status() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')] ✓${NC} $1"
}

print_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')] ✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')] ⚠${NC} $1"
}

# Function to stop a service by port
stop_by_port() {
    local port=$1
    local name=$2
    local pids=$(lsof -t -i:$port 2>/dev/null)
    
    if [ ! -z "$pids" ]; then
        print_status "Stopping $name on port $port (PIDs: $pids)..."
        kill -TERM $pids 2>/dev/null || true
        sleep 2
        
        # Force kill if still running
        if lsof -t -i:$port >/dev/null 2>&1; then
            print_warning "Force killing $name..."
            kill -9 $pids 2>/dev/null || true
        fi
        
        print_success "$name stopped"
    else
        print_status "$name not running on port $port"
    fi
}

# Function to stop a service by PID file
stop_by_pidfile() {
    local pidfile=$1
    local name=$2
    
    if [ -f "$pidfile" ]; then
        local pid=$(cat "$pidfile")
        if kill -0 $pid 2>/dev/null; then
            print_status "Stopping $name (PID: $pid)..."
            kill -TERM $pid 2>/dev/null || true
            sleep 2
            
            # Force kill if still running
            if kill -0 $pid 2>/dev/null; then
                print_warning "Force killing $name..."
                kill -9 $pid 2>/dev/null || true
            fi
            
            print_success "$name stopped"
        fi
        rm -f "$pidfile"
    fi
}

# Main execution
echo
echo "🛑 Stopping Vana Development Environment"
echo "========================================"
echo

# Stop frontend
stop_by_port $FRONTEND_PORT "Frontend"
stop_by_pidfile "$FRONTEND_DIR/frontend.pid" "Frontend (by PID)"

# Stop backend
stop_by_port $BACKEND_PORT "Backend"
stop_by_pidfile "$BACKEND_DIR/backend.pid" "Backend (by PID)"

# Clean up log files if requested
if [ "$1" = "--clean" ]; then
    print_status "Cleaning up log files..."
    rm -f "$BACKEND_DIR/backend.log" "$FRONTEND_DIR/frontend.log"
    print_success "Log files removed"
fi

echo
print_success "All services stopped! 🛑"
echo

if [ "$1" != "--clean" ]; then
    echo "💡 Tip: Use './stop-vana.sh --clean' to also remove log files"
fi