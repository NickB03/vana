#!/bin/bash

echo "=== Claude Code Troubleshooting Script ==="
echo ""

# Check current Node.js version
echo "1. Current Node.js version:"
node --version
echo ""

# Check where Node is installed
echo "2. Node.js location:"
which node
echo ""

# Check all Node installations
echo "3. All Node.js installations:"
which -a node
echo ""

# Check if nvm is installed
echo "4. Checking for nvm:"
if [ -s "$HOME/.nvm/nvm.sh" ]; then
    echo "nvm is installed"
    source "$HOME/.nvm/nvm.sh"
    nvm list
else
    echo "nvm is NOT installed"
fi
echo ""

# Check npm version
echo "5. npm version:"
npm --version
echo ""

# Check if Claude Code is installed globally
echo "6. Checking for Claude Code:"
which claude || echo "Claude Code not found in PATH"
echo ""

# Check npm global packages
echo "7. Global npm packages:"
npm list -g --depth=0 | grep claude || echo "Claude Code not found in global packages"
echo ""

# Provide solutions
echo "=== SOLUTIONS ==="
echo ""
echo "Since you have Node.js 18.17.0, you need to upgrade to 20.5.0 or higher."
echo ""
echo "Option 1 - Install with nvm (recommended):"
echo "  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash"
echo "  source ~/.zshrc"
echo "  nvm install 20"
echo "  nvm use 20"
echo "  npm install -g @anthropic-ai/claude-code"
echo ""
echo "Option 2 - Upgrade with Homebrew:"
echo "  brew update"
echo "  brew upgrade node"
echo "  npm install -g @anthropic-ai/claude-code"
echo ""
echo "After upgrading, close VS Code completely and reopen it."
