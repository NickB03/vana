#!/bin/bash

echo "=== Claude Code / Node.js Recovery Script ==="
echo ""
echo "This will clean up potential issues from the force shutdown during Playwright MCP installation."
echo ""

# Step 1: Check current state
echo "Step 1: Current System State"
echo "----------------------------"
echo "Node version: $(node --version 2>&1 || echo 'Node not found')"
echo "npm version: $(npm --version 2>&1 || echo 'npm not found')"
echo "Claude location: $(which claude 2>&1 || echo 'Claude not found')"
echo ""

# Step 2: Clean npm cache
echo "Step 2: Cleaning npm cache..."
echo "----------------------------"
npm cache clean --force
echo "npm cache cleaned."
echo ""

# Step 3: Remove potentially corrupted global node_modules for claude-code
echo "Step 3: Removing potentially corrupted Claude Code installation..."
echo "----------------------------"
echo "Checking for Claude Code in global packages..."
npm list -g @anthropic-ai/claude-code --depth=0 2>/dev/null
if [ $? -eq 0 ]; then
    echo "Uninstalling Claude Code..."
    npm uninstall -g @anthropic-ai/claude-code
else
    echo "Claude Code not found in global packages."
fi
echo ""

# Step 4: Check for and remove any leftover playwright installations
echo "Step 4: Checking for leftover Playwright installations..."
echo "----------------------------"
# Check global playwright
npm list -g | grep playwright 2>/dev/null
if [ $? -eq 0 ]; then
    echo "Found global Playwright packages. Removing..."
    npm uninstall -g playwright playwright-core @playwright/test 2>/dev/null
else
    echo "No global Playwright packages found."
fi

# Check for playwright in home directory
if [ -d "$HOME/node_modules" ]; then
    echo "Found node_modules in home directory (unusual). Checking for playwright..."
    ls -la $HOME/node_modules | grep playwright || echo "No playwright found in ~/node_modules"
fi
echo ""

# Step 5: Check Node.js version and provide upgrade instructions
echo "Step 5: Node.js Version Check"
echo "----------------------------"
NODE_VERSION=$(node -v 2>/dev/null | cut -d'v' -f2)
if [ -z "$NODE_VERSION" ]; then
    echo "❌ Node.js is not installed or not in PATH"
else
    MAJOR_VERSION=$(echo $NODE_VERSION | cut -d'.' -f1)
    MINOR_VERSION=$(echo $NODE_VERSION | cut -d'.' -f2)
    
    if [ "$MAJOR_VERSION" -lt 20 ] || ([ "$MAJOR_VERSION" -eq 20 ] && [ "$MINOR_VERSION" -lt 5 ]); then
        echo "❌ Current Node.js version ($NODE_VERSION) is too old for Claude Code"
        echo "   Claude Code requires Node.js 20.5.0 or higher"
    else
        echo "✅ Node.js version ($NODE_VERSION) is compatible with Claude Code"
    fi
fi
echo ""

# Step 6: Recovery options
echo "Step 6: Recovery Options"
echo "----------------------------"
echo ""
echo "Option A - Quick Fix with Homebrew (if Node is already installed via Homebrew):"
echo "  brew update"
echo "  brew upgrade node"
echo "  npm install -g @anthropic-ai/claude-code"
echo ""
echo "Option B - Fresh install with nvm (recommended for clean setup):"
echo "  # Install nvm"
echo "  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash"
echo "  source ~/.zshrc"
echo "  "
echo "  # Install Node 20 LTS"
echo "  nvm install 20"
echo "  nvm use 20"
echo "  nvm alias default 20"
echo "  "
echo "  # Install Claude Code"
echo "  npm install -g @anthropic-ai/claude-code"
echo ""
echo "Option C - Complete Node.js reinstall with Homebrew:"
echo "  # Remove existing Node"
echo "  brew uninstall --ignore-dependencies node"
echo "  brew cleanup"
echo "  "
echo "  # Install fresh"
echo "  brew install node"
echo "  npm install -g @anthropic-ai/claude-code"
echo ""
echo "After any of these options, close VS Code completely and restart."
echo ""

# Step 7: Check for running node processes
echo "Step 7: Checking for stuck Node processes..."
echo "----------------------------"
NODE_PROCESSES=$(ps aux | grep -E "node|npm" | grep -v grep | wc -l)
if [ $NODE_PROCESSES -gt 0 ]; then
    echo "⚠️  Found $NODE_PROCESSES Node/npm processes running:"
    ps aux | grep -E "node|npm" | grep -v grep
    echo ""
    echo "If these look stuck from the crash, you can kill them with:"
    echo "  pkill -f node"
    echo "  pkill -f npm"
else
    echo "✅ No stuck Node/npm processes found"
fi
