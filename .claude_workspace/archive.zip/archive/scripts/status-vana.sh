#!/bin/bash

# Vana Development Environment Status Script
# This script checks the health of all Vana services

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
FRONTEND_PORT=5173
BACKEND_PORT=8000

# Function to print colored output
print_status() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')] ✓${NC} $1"
}

print_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')] ✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')] ⚠${NC} $1"
}

# Function to check if a port is in use
is_port_in_use() {
    lsof -i :$1 -t >/dev/null 2>&1
}

# Function to get process info
get_process_info() {
    local port=$1
    local pid=$(lsof -t -i:$port 2>/dev/null | head -1)
    if [ ! -z "$pid" ]; then
        ps -p $pid -o pid,ppid,user,%cpu,%mem,start,command | tail -1
    fi
}

echo
echo "📊 Vana Development Environment Status"
echo "======================================"
echo

# Check Backend
echo "🔧 Backend Service (Port $BACKEND_PORT)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if is_port_in_use $BACKEND_PORT; then
    # Try to get health status
    if health_response=$(curl -s http://localhost:$BACKEND_PORT/health 2>/dev/null); then
        if echo "$health_response" | grep -q "healthy"; then
            print_success "Status: Running and Healthy"
            echo
            echo "Health Response:"
            echo "$health_response" | jq '.' 2>/dev/null || echo "$health_response"
        else
            print_warning "Status: Running but health check failed"
        fi
    else
        print_warning "Status: Running but not responding to health checks"
    fi
    
    echo
    echo "Process Info:"
    get_process_info $BACKEND_PORT
else
    print_error "Status: Not Running"
fi

echo
echo

# Check Frontend
echo "🎨 Frontend Service (Port $FRONTEND_PORT)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if is_port_in_use $FRONTEND_PORT; then
    # Try to access frontend
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:$FRONTEND_PORT | grep -q "200"; then
        print_success "Status: Running and Accessible"
    else
        print_warning "Status: Running but not responding"
    fi
    
    echo
    echo "Process Info:"
    get_process_info $FRONTEND_PORT
else
    print_error "Status: Not Running"
fi

echo
echo

# Check for orphaned processes
echo "🔍 Checking for orphaned processes..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

orphaned=$(ps aux | grep -E "(vite|uvicorn)" | grep -v grep | grep -v "lsof" || true)
if [ ! -z "$orphaned" ]; then
    print_warning "Found potentially orphaned processes:"
    echo "$orphaned"
else
    print_success "No orphaned processes found"
fi

echo
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo

# Summary
if is_port_in_use $BACKEND_PORT && is_port_in_use $FRONTEND_PORT; then
    print_success "All services are running! 🎉"
    echo
    echo "Access your application at: http://localhost:$FRONTEND_PORT"
    echo "API documentation at: http://localhost:$BACKEND_PORT/docs"
else
    print_warning "Some services are not running."
    echo
    echo "💡 Tip: Run './start-vana.sh' to start all services"
fi

echo