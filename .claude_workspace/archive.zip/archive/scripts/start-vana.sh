#!/bin/bash

# Vana Development Environment Startup Script
# This script ensures all services are properly started and healthy

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
FRONTEND_DIR="/Users/nick/Development/vana/frontend"
BACKEND_DIR="/Users/nick/Development/vana"
FRONTEND_PORT=5173
BACKEND_PORT=8000
MAX_RETRIES=30
RETRY_DELAY=2

# Function to print colored output
print_status() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')] ✓${NC} $1"
}

print_error() {
    echo -e "${RED}[$(date '+%H:%M:%S')] ✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[$(date '+%H:%M:%S')] ⚠${NC} $1"
}

# Function to check if a port is in use
is_port_in_use() {
    lsof -i :$1 -t >/dev/null 2>&1
}

# Function to kill process on a port
kill_port() {
    local port=$1
    local pids=$(lsof -t -i:$port 2>/dev/null)
    if [ ! -z "$pids" ]; then
        print_warning "Killing existing process on port $port (PIDs: $pids)"
        kill -9 $pids 2>/dev/null || true
        sleep 1
    fi
}

# Function to wait for a service to be healthy
wait_for_service() {
    local name=$1
    local url=$2
    local retries=0
    
    print_status "Waiting for $name to be ready..."
    
    while [ $retries -lt $MAX_RETRIES ]; do
        if curl -s -f -o /dev/null "$url" 2>/dev/null; then
            print_success "$name is ready!"
            return 0
        fi
        retries=$((retries + 1))
        if [ $((retries % 5)) -eq 0 ]; then
            print_status "Still waiting for $name... ($retries/$MAX_RETRIES)"
        fi
        sleep $RETRY_DELAY
    done
    
    print_error "$name failed to start after $MAX_RETRIES attempts"
    return 1
}

# Function to start the backend
start_backend() {
    print_status "Starting backend server..."
    
    # Check if already running
    if is_port_in_use $BACKEND_PORT; then
        print_warning "Backend already running on port $BACKEND_PORT, checking health..."
        if curl -s -f http://localhost:$BACKEND_PORT/health | grep -q "healthy"; then
            print_success "Backend is healthy, skipping restart"
            return 0
        else
            print_warning "Backend not healthy, restarting..."
            kill_port $BACKEND_PORT
        fi
    fi
    
    # Start backend
    cd "$BACKEND_DIR"
    print_status "Activating virtual environment and starting uvicorn..."
    source .venv/bin/activate 2>/dev/null || {
        print_error "Failed to activate virtual environment"
        print_status "Creating virtual environment..."
        uv venv
        source .venv/bin/activate
    }
    
    # Start uvicorn in background
    nohup uv run uvicorn app.server:app --host 0.0.0.0 --port $BACKEND_PORT --reload > backend.log 2>&1 &
    local backend_pid=$!
    
    # Save PID
    echo $backend_pid > backend.pid
    print_status "Backend started with PID $backend_pid"
    
    # Wait for backend to be healthy
    if wait_for_service "Backend" "http://localhost:$BACKEND_PORT/health"; then
        return 0
    else
        print_error "Backend failed to start properly"
        return 1
    fi
}

# Function to start the frontend
start_frontend() {
    print_status "Starting frontend server..."
    
    # Check if already running
    if is_port_in_use $FRONTEND_PORT; then
        print_warning "Frontend already running on port $FRONTEND_PORT, checking health..."
        if curl -s -f -o /dev/null "http://localhost:$FRONTEND_PORT"; then
            print_success "Frontend is accessible, skipping restart"
            return 0
        else
            print_warning "Frontend not responding, restarting..."
            kill_port $FRONTEND_PORT
        fi
    fi
    
    # Start frontend
    cd "$FRONTEND_DIR"
    print_status "Starting Vite dev server..."
    
    # Check if node_modules exists
    if [ ! -d "node_modules" ]; then
        print_warning "node_modules not found, running npm install..."
        npm install
    fi
    
    # Start vite in background
    nohup npm run dev > frontend.log 2>&1 &
    local frontend_pid=$!
    
    # Save PID
    echo $frontend_pid > frontend.pid
    print_status "Frontend started with PID $frontend_pid"
    
    # Wait for frontend to be ready
    if wait_for_service "Frontend" "http://localhost:$FRONTEND_PORT"; then
        return 0
    else
        print_error "Frontend failed to start properly"
        return 1
    fi
}

# Function to show status
show_status() {
    echo
    print_status "Service Status:"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    # Backend status
    if is_port_in_use $BACKEND_PORT && curl -s -f http://localhost:$BACKEND_PORT/health | grep -q "healthy"; then
        print_success "Backend:  http://localhost:$BACKEND_PORT (healthy)"
    else
        print_error "Backend:  Not running or unhealthy"
    fi
    
    # Frontend status
    if is_port_in_use $FRONTEND_PORT; then
        print_success "Frontend: http://localhost:$FRONTEND_PORT"
    else
        print_error "Frontend: Not running"
    fi
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# Main execution
main() {
    echo
    echo "🚀 Vana Development Environment Startup"
    echo "======================================="
    echo
    
    # Start services
    if start_backend; then
        backend_ok=true
    else
        backend_ok=false
    fi
    
    if start_frontend; then
        frontend_ok=true
    else
        frontend_ok=false
    fi
    
    # Show final status
    show_status
    
    if [ "$backend_ok" = true ] && [ "$frontend_ok" = true ]; then
        echo
        print_success "All services started successfully! 🎉"
        echo
        echo "📝 Logs are available at:"
        echo "   Backend:  $BACKEND_DIR/backend.log"
        echo "   Frontend: $FRONTEND_DIR/frontend.log"
        echo
        echo "💡 Tips:"
        echo "   - Use './stop-vana.sh' to stop all services"
        echo "   - Use './status-vana.sh' to check service status"
        echo "   - Backend API docs: http://localhost:$BACKEND_PORT/docs"
        echo
    else
        echo
        print_error "Some services failed to start. Check the logs for details."
        exit 1
    fi
}

# Run main function
main