# Canvas (Slide-out Workbench) — Implementation Guide

## 1) What “Canvas” is (and isn’t)

Canvas is a **dedicated workspace next to chat** where larger artifacts—documents, code, previews, diagrams—are created and iterated on with the model. OpenAI’s Canvas describes a separate working area that opens when writing/coding gets complex and supports targeted edits and versioning. Gemini’s Canvas markets “prompt → prototype” for things like apps, quizzes, and web pages. Claude’s **Artifacts** show complex outputs in a right-hand pane with versioning and reuse. These three set the expectation we’re mirroring: a **slide-out surface** that the assistant can open automatically, where users can edit, preview, and version artifacts without leaving the conversation. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com), [Gemini](https://gemini.google/overview/canvas/?utm_source=chatgpt.com), [Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))

**Key behaviors to match**

* Opens as a **right-side workspace** when the assistant detects a writing/coding task (or when the user clicks “Open in Canvas”). ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com))
* Supports **direct editing, targeted edits, and version restore** (especially for text/code). ([Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))
* Hosts **interactive artifacts** (markdown, code, sites, SVG/diagrams) and can **render live previews**. ([Gemini](https://gemini.google/overview/canvas/?utm_source=chatgpt.com))

---

## 2) High-level architecture

**Client (Next.js + shadcn/ui)**

* **Canvas Shell (slide-out)**: built with shadcn **Sheet** + **Resizable** + **Tabs**. This is the container the tools mount into. ([Shadcn UI](https://ui.shadcn.com/docs/components/sheet?utm_source=chatgpt.com))
* **Tool Registry**: map tool IDs → lazy React components (Sandbox, Markdown editor, Diff, Formatter…).
* **Engines for previews** (swappable):

  1. **Iframe engine** (default; static HTML/CSS/JS with CSP + sandbox). ([MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe?utm_source=chatgpt.com))
  2. **Sandpack/Kibo Sandbox** (bundled/JSX flows). ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com), [Kibo UI](https://www.kibo-ui.com/components/sandbox?utm_source=chatgpt.com))
  3. **Optional**: StackBlitz **WebContainers** (true Node/SSR demos) or StackBlitz **SDK embed** (prebuilt IDE). ([StackBlitz Docs](https://developer.stackblitz.com/platform/api/webcontainer-api?utm_source=chatgpt.com))
* **Version Store**: keeps artifact versions, diffs, and metadata.

**Server**

* **Route Handlers** for agent streaming and (optional) server bundling (esbuild) to produce a single preview artifact. ([Next.js](https://nextjs.org/docs/app/getting-started/route-handlers-and-middleware?utm_source=chatgpt.com), [esbuild](https://esbuild.github.io/?utm_source=chatgpt.com))

**LLM/Agent**

* Emits **actions** like `open_canvas`, `update_canvas`, `create_version` with payloads (files, content patches, notes). Canvas listens and updates UI.

---

## 3) Components (what each does, why it’s there, how it works)

### 3.1 Canvas Shell (UI container)

* **What:** Right-side slide-over with two panes: **Activity/Assets/Logs** (left) and **Work Area** (right).
* **Why:** Mirrors the UX of ChatGPT/Gemini/Claude so complex work happens “beside” chat, not inside it. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com), [Gemini](https://gemini.google/overview/canvas/?utm_source=chatgpt.com), [Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))
* **How:**

  * `Sheet` (**side="right"**) hosts the shell. ([Shadcn UI](https://ui.shadcn.com/docs/components/sheet?utm_source=chatgpt.com))
  * `ResizablePanelGroup` splits sidebar ↔ work area. ([Shadcn UI](https://ui.shadcn.com/docs/components/resizable?utm_source=chatgpt.com))
  * `Tabs` organize Activity (agent plan/steps), Assets (files/images), Logs. ([Shadcn UI](https://ui.shadcn.com/docs/components/tabs?utm_source=chatgpt.com))
  * Lazy-load tools inside the work area to keep the app shell light. **Next.js dynamic import** with `ssr:false`. ([Next.js](https://nextjs.org/docs/pages/guides/lazy-loading?utm_source=chatgpt.com))

### 3.2 Tool Registry (lazy tools)

* **What:** A mapping `{ toolId → React.lazy component }`.
* **Why:** Lets you plug in new tools (e.g., Diagram/SVG viewer) without touching the shell.
* **How:** Use `next/dynamic` for each tool; mount the active tool based on Canvas state. ([Next.js](https://nextjs.org/docs/app/guides/lazy-loading?utm_source=chatgpt.com))

### 3.3 Sandbox Tool (one-shot web preview)

* **What:** Renders generated sites/apps interactively.
* **Why:** Matches Gemini/Claude use cases where the assistant produces live artifacts (web pages, micro-apps). ([Gemini](https://gemini.google/overview/canvas/?utm_source=chatgpt.com), [Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))
* **How (engine switcher):**

  * **Iframe engine (default)**: injects built HTML with strict **CSP** (`default-src 'none'`) and `iframe[sandbox]`. Fastest for static HTML/CSS/JS. ([MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CSP?utm_source=chatgpt.com))
  * **Sandpack** (or **Kibo Sandbox**, which is Sandpack-powered) when bundling or JSX is needed. Sandpack compiles and runs frameworks in the browser; Kibo’s Sandbox wraps it with UI. ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com), [Kibo UI](https://www.kibo-ui.com/components/sandbox?utm_source=chatgpt.com))
  * **StackBlitz WebContainers** only if you truly need Node/SSR; or **StackBlitz SDK embed** for a full prebuilt IDE+preview you can programmatically control. ([StackBlitz Docs](https://developer.stackblitz.com/platform/api/webcontainer-api?utm_source=chatgpt.com))

### 3.4 Markdown Tool

* **What:** Edit long-form content with **Markdown** (GFM support) and preview.
* **Why:** Chat-adjacent writing/editing is a core Canvas task. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com))
* **How:**

  * Editor: **CodeMirror 6** (browser-friendly, modular). ([CodeMirror](https://codemirror.net/docs/?utm_source=chatgpt.com))
  * Preview: **react-markdown** (+ **remark-gfm** for tables, footnotes). ([remarkjs.github.io](https://remarkjs.github.io/react-markdown/?utm_source=chatgpt.com), [GitHub](https://github.com/remarkjs/remark-gfm?utm_source=chatgpt.com))

### 3.5 Code Tool

* **What:** Edit code with syntax, diagnostics, go-to definition, etc.
* **Why:** For agent-assisted fixes, reviews, and diffs.
* **How:** **Monaco Editor** (VS Code’s editor) for a richer coding experience; it also includes a **DiffEditor** you can reuse in the Diff Tool. ([Microsoft GitHub](https://microsoft.github.io/monaco-editor/docs.html?utm_source=chatgpt.com))

### 3.6 Diff Tool

* **What:** Compare two versions (assistant proposal vs current).
* **How:** Use **Monaco DiffEditor** (ships with Monaco); mount it in the work area. ([Microsoft GitHub](https://microsoft.github.io/monaco-editor/playground.html?utm_source=chatgpt.com))

### 3.7 Formatter Tool

* **What:** On-device code/markdown formatting.
* **How:** **Prettier (standalone)** runs in the browser (no Node). ([prettier.io](https://prettier.io/docs/browser?utm_source=chatgpt.com))

### 3.8 Activity / Assets / Logs (left pane)

* **Activity:** agent plan, steps taken, applied patches.
* **Assets:** generated files, images, downloads/ZIP.
* **Logs:** model/tool logs, bundler output from Sandpack/WebContainers; show with a simple terminal-like view.

---

## 4) Engines for web previews (when to use which)

1. **Iframe engine (default):** static HTML/CSS/JS; supports **import maps** (so the model can add CDN ESM without a bundler). Secure with `iframe[sandbox]` and strict **CSP**. Fastest path for “one-shot” sites. ([MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/script/type/importmap?utm_source=chatgpt.com))
2. **Sandpack / Kibo Sandbox:** when the agent outputs JSX/TSX or needs a bundler in the browser. Sandpack is the open-source toolkit for live code editors; **Kibo’s Sandbox** is a styled wrapper you can add with `npx kibo-ui@latest add sandbox`. ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com), [Kibo UI](https://www.kibo-ui.com/components/sandbox?utm_source=chatgpt.com))
3. **Server bundle (optional):** POST files to a route handler; run **esbuild** to produce JS/CSS and return a single HTML artifact for the iframe. Great for larger graphs; deterministic performance. ([esbuild](https://esbuild.github.io/?utm_source=chatgpt.com), [Next.js](https://nextjs.org/docs/app/api-reference/file-conventions/route?utm_source=chatgpt.com))
4. **WebContainers / StackBlitz SDK:** if you need Node/SSR or a turnkey IDE; embed + programmatically read/write files via VM API. Heavier, but closest to a real dev env. ([StackBlitz Docs](https://developer.stackblitz.com/platform/api/webcontainer-api?utm_source=chatgpt.com))

---

## 5) Data model & contracts (what the LLM sends; what the UI expects)

### 5.1 Core types

```ts
// Artifact types visible in Canvas
type ArtifactType = "markdown" | "site" | "code" | "diagram" | "svg";

type VFile = { path: string; content: string; language?: string };
type VFS = Record<string, VFile>; // "/index.html", "/style.css", ...

type SiteManifest = {
  type: "site";
  entry: string;                 // e.g. "/index.html"
  files: VFS;
  requires?: ("bundler" | "npm" | "node" | "ssr" | "server-bundle")[];
  title?: string;
};

type MarkdownDoc = { type: "markdown"; content: string; title?: string };

type CanvasArtifact =
  | SiteManifest
  | MarkdownDoc
  | { type: "code"; files: VFS; entry?: string; title?: string }
  | { type: "diagram" | "svg"; content: string; title?: string };

type ArtifactVersion = {
  id: string;
  createdAt: number;
  note?: string;                 // "Applied assistant fix for bug X"
  artifact: CanvasArtifact;      // frozen snapshot
};
```

### 5.2 LLM action grammar (agent → UI)

```json
{
  "actions": [
    {
      "type": "open_canvas",
      "tool": "sandbox",
      "title": "One-shot Preview",
      "payload": {
        "type": "site",
        "entry": "/index.html",
        "files": {
          "/index.html": { "path": "/index.html", "content": "<h1>Hello</h1>" },
          "/style.css":  { "path": "/style.css",  "content": "body{font:14px system-ui}" }
        },
        "requires": []
      },
      "agentId": "canvas_orchestrator_agent",
      "autoOpened": true,
      "reason": "Website creation requested"
    },
    {
      "type": "update_canvas",
      "payloadPatch": { "files": { "/index.html": { "content": "<h1>Hello, world</h1>" } } }
    },
    {
      "type": "create_version",
      "note": "First complete draft"
    }
  ]
}
```

### 5.3 Canvas Decision State

```typescript
// Canvas decision metadata passed to frontend
interface CanvasDecision {
  open_canvas: boolean;
  canvas_type: "code" | "markdown" | "site" | "none";
  reason: string;
  canvas_status?: "opened" | "available";
  canvas_ready_type?: string;
}

// Example decision outcomes:
{
  "open_canvas": true,
  "canvas_type": "site", 
  "reason": "Interactive web content requested",
  "canvas_status": "opened"
}

{
  "open_canvas": false,
  "canvas_type": "markdown",
  "reason": "Long report - Canvas available on request",
  "canvas_status": "available",
  "canvas_ready_type": "markdown"
}
```

**Why this shape?**

* Mirrors “open automatically when useful” + “targeted updates” + “versioning” described by vendors. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com), [Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))
* Keeps engines swappable: iframe vs Sandpack vs WebContainers only depend on `requires` and `files`.

---

## 6) User interactions (how it feels)

1. **From chat → Canvas**

   * The assistant proposes: “I can turn this into a website / polish this doc.”
   * UI shows **Open in Canvas**; on click (or automatically by policy) we call `open_canvas`. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com))

2. **Working in Canvas**

   * Left pane: **Activity** (agent steps), **Assets**, **Logs**.
   * Right pane: active tool (**Markdown**, **Sandbox**, **Code**, **Diff**, **Formatter**).
   * Common shortcuts: `Cmd/Ctrl+Enter` to “Apply” (format/build), `Esc` to close, `Cmd/Ctrl+S` to create a **version**.

3. **Targeted edits**

   * User highlights a region (text or code) → floating toolbar (Shorten, Fix bug, Make concise).
   * The selection context is sent to LLM; result returns as `update_canvas` patch. Matches “edit selected region” behaviors. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com))

4. **Preview & Share**

   * Sandbox tool shows live preview; **Export ZIP** (assets), **Open in new tab**.
   * Optional: **Publish** static artifact to storage and return share link (Claude emphasizes sharing and reuse). ([Anthropic Help Center](https://support.anthropic.com/en/articles/9547008-discovering-publishing-customizing-and-sharing-artifacts?utm_source=chatgpt.com))

---

## 6.5) Canvas Orchestrator Agent (Intelligent Decision Layer)

### 6.5.1 Overview

The **Canvas Orchestrator Agent** is an intelligent decision-making layer that determines when and how to open Canvas based on user intent and content analysis. It runs after content generation to evaluate whether Canvas should be automatically opened or made available on demand.

### 6.5.2 Core Decision Tools

```typescript
// Type definitions for Canvas decision system
interface CanvasDecision {
  open_canvas: boolean;
  canvas_type: "code" | "markdown" | "site" | "none";
  reason: string;
  canvas_status?: "opened" | "available";
}

interface CanvasAction {
  type: "open_canvas" | "update_canvas" | "create_version";
  tool?: string;
  title?: string;
  payload?: any;
  agentId?: string;
  autoOpened?: boolean;
  reason?: string;
}
```

**Decision Tool: `should_open_canvas_tool`**

* **What:** Analyzes user request and content to determine Canvas necessity
* **Triggers for auto-opening:**
  * Explicit Canvas requests ("open canvas", "edit in canvas")
  * Website/app creation requests ("create a website", "build an app")
  * Document formatting requests with substantial content (>500 chars)
* **Triggers for availability (not auto-open):**
  * Long reports (>2000 chars) - Canvas available on button click
  * Simple code examples - remain in chat unless creation intent detected

**Generation Tool: `generate_canvas_artifact_tool`**

* **What:** Creates appropriate Canvas artifacts based on content type
* **Site artifacts:** Generates HTML structure with embedded CSS/JS
* **Markdown artifacts:** Prepares content for markdown editor
* **Code artifacts:** Extracts and structures code for editing

### 6.5.3 Agent Pipeline Integration

```python
# Agent placement in pipeline
report_composer_with_citations → canvas_orchestrator_agent → END

# Canvas Orchestrator Agent implementation
canvas_orchestrator = LlmAgent(
    name="canvas_orchestrator_agent",
    model=RESEARCHER_MODEL_NAME,
    system_instruction="""You are the Canvas Orchestrator Agent.
    
    Your role is to:
    1. Evaluate final output from research pipeline
    2. Determine if Canvas should open based on user intent
    3. Prepare appropriate Canvas artifacts when needed
    4. Handle both automatic and user-triggered Canvas requests
    
    Decision Guidelines:
    - "create a website/app" → Open Canvas with site tool
    - "open canvas" or "edit in canvas" → Always open Canvas
    - Document formatting requests → Open markdown editor
    - Simple code requests → Use chat code blocks (no Canvas)
    - Large reports → Make Canvas available but don't auto-open""",
    tools=[should_open_canvas_tool, generate_canvas_artifact_tool]
)
```

### 6.5.4 Frontend Integration

**Canvas Trigger Component:**
```typescript
export function CanvasTrigger({ message, canvasDecision }) {
  const handleOpenCanvas = () => {
    publishAction(userId, {
      type: "open_canvas",
      tool: canvasDecision?.canvas_ready_type || "markdown",
      title: "Manual Canvas",
      payload: { content: message.content }
    });
  };
  
  // Show button if Canvas available but not auto-opened
  if (canvasDecision?.canvas_status === "available") {
    return (
      <Button onClick={handleOpenCanvas}>
        Open in Canvas
      </Button>
    );
  }
  return null;
}
```

**SSE Event Handler:**
```typescript
if (event.agent === "canvas_orchestrator_agent") {
  if (state?.canvas_action) {
    // Auto-open Canvas
    publishAction(userId, { ...state.canvas_action });
    toast({ title: "Canvas Opened", description: state.canvas_decision?.reason });
  } else if (state?.canvas_decision) {
    // Canvas available but not auto-opened
    setCanvasDecision(state.canvas_decision);
  }
}
```

---

## 7) How the LLM interacts (runtime loop)

* **Intelligent trigger policy:** Canvas Orchestrator Agent analyzes user intent and content to determine when Canvas should open automatically vs. when it should be available on demand. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com))
* **Decision-based opening:** Instead of simple keyword matching, uses LLM reasoning to understand context ("create a website" vs "show me code")
* **Streaming updates:** agent streams file/content patches via SSE to the tool; the tool applies them with debouncing (100–300 ms) to avoid thrashing Sandpack. Sandpack re-compiles on `files` change or `updateFile`. ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com))
* **Revisions:** after a meaningful change, agent calls `create_version` so users can **diff** and **restore**. (Claude's multi-version artifact experience.) ([Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))

---

## 8) Library choices (with links)

**UI primitives (shadcn/ui)**

* **Sheet** (right-side slide-over): [https://ui.shadcn.com/docs/components/sheet](https://ui.shadcn.com/docs/components/sheet) ([Shadcn UI](https://ui.shadcn.com/docs/components/sheet?utm_source=chatgpt.com))
* **Resizable** (split panes): [https://ui.shadcn.com/docs/components/resizable](https://ui.shadcn.com/docs/components/resizable) (built on react-resizable-panels) ([Shadcn UI](https://ui.shadcn.com/docs/components/resizable?utm_source=chatgpt.com))
* **Tabs**: [https://ui.shadcn.com/docs/components/tabs](https://ui.shadcn.com/docs/components/tabs) ([Shadcn UI](https://ui.shadcn.com/docs/components/tabs?utm_source=chatgpt.com))

**Preview engines**

* **Sandpack (React)**: [https://sandpack.codesandbox.io/docs](https://sandpack.codesandbox.io/docs) | [https://github.com/codesandbox/sandpack](https://github.com/codesandbox/sandpack) ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com), [GitHub](https://github.com/codesandbox/sandpack?utm_source=chatgpt.com))
* **Kibo Sandbox (Sandpack wrapper)**: [https://www.kibo-ui.com/components/sandbox](https://www.kibo-ui.com/components/sandbox) ([Kibo UI](https://www.kibo-ui.com/components/sandbox?utm_source=chatgpt.com))
* **StackBlitz WebContainers**: [https://developer.stackblitz.com/platform/api/webcontainer-api](https://developer.stackblitz.com/platform/api/webcontainer-api) | [https://webcontainers.io/](https://webcontainers.io/) ([StackBlitz Docs](https://developer.stackblitz.com/platform/api/webcontainer-api?utm_source=chatgpt.com), [webcontainers.io](https://webcontainers.io/?utm_source=chatgpt.com))
* **StackBlitz SDK (embeds + VM)**: [https://developer.stackblitz.com/platform/api/javascript-sdk](https://developer.stackblitz.com/platform/api/javascript-sdk) | Controlling embeds/VM ([StackBlitz Docs](https://developer.stackblitz.com/platform/api/javascript-sdk?utm_source=chatgpt.com))

**Editors & utilities**

* **CodeMirror 6**: [https://codemirror.net/docs/](https://codemirror.net/docs/) ([CodeMirror](https://codemirror.net/docs/?utm_source=chatgpt.com))
* **Monaco Editor** (and Diff Editor): [https://microsoft.github.io/monaco-editor/docs.html](https://microsoft.github.io/monaco-editor/docs.html) | Playground/diff examples ([Microsoft GitHub](https://microsoft.github.io/monaco-editor/docs.html?utm_source=chatgpt.com))
* **react-markdown** + **remark-gfm**: [https://remarkjs.github.io/react-markdown/](https://remarkjs.github.io/react-markdown/) | [https://github.com/remarkjs/remark-gfm](https://github.com/remarkjs/remark-gfm) ([remarkjs.github.io](https://remarkjs.github.io/react-markdown/?utm_source=chatgpt.com), [GitHub](https://github.com/remarkjs/remark-gfm?utm_source=chatgpt.com))
* **Prettier (standalone)**: [https://prettier.io/docs/browser](https://prettier.io/docs/browser) ([prettier.io](https://prettier.io/docs/browser?utm_source=chatgpt.com))
* **esbuild** (server bundling): [https://esbuild.github.io/](https://esbuild.github.io/) | API ([esbuild](https://esbuild.github.io/?utm_source=chatgpt.com))
* **Yjs** (later, for collab): [https://docs.yjs.dev/](https://docs.yjs.dev/) ([docs.yjs.dev](https://docs.yjs.dev/?utm_source=chatgpt.com))

**Security references**

* `iframe[sandbox]`: MDN [https://developer.mozilla.org/.../iframe](https://developer.mozilla.org/.../iframe) | sandbox API | CSP guide/directives. ([MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe?utm_source=chatgpt.com))
* **Import Maps** for CDN ESM: MDN importmap docs. ([MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/script/type/importmap?utm_source=chatgpt.com))

**Next.js integration**

* **Lazy loading / no SSR**: [https://nextjs.org/docs/pages/guides/lazy-loading](https://nextjs.org/docs/pages/guides/lazy-loading) (also app router guide) ([Next.js](https://nextjs.org/docs/pages/guides/lazy-loading?utm_source=chatgpt.com))
* **Route Handlers** (SSE/bundling endpoint): [https://nextjs.org/docs/app/getting-started/route-handlers-and-middleware](https://nextjs.org/docs/app/getting-started/route-handlers-and-middleware) | route file reference. ([Next.js](https://nextjs.org/docs/app/getting-started/route-handlers-and-middleware?utm_source=chatgpt.com))

**Product references (what we mirror)**

* **OpenAI Canvas**: [https://openai.com/index/introducing-canvas/](https://openai.com/index/introducing-canvas/) ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com))
* **Gemini Canvas**: [https://gemini.google/overview/canvas/](https://gemini.google/overview/canvas/) (plus product blog) ([Gemini](https://gemini.google/overview/canvas/?utm_source=chatgpt.com), [blog.google](https://blog.google/products/gemini/gemini-collaboration-features/?utm_source=chatgpt.com))
* **Claude Artifacts**: [https://support.anthropic.com/.../what-are-artifacts-and-how-do-i-use-them](https://support.anthropic.com/.../what-are-artifacts-and-how-do-i-use-them) ([Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))

---

## 9) Security & performance (what to get right)

* **Sandbox all previews:** render artifacts in a same-origin `iframe` with `sandbox="allow-scripts allow-forms allow-pointer-lock allow-downloads"` (tighten as needed). Use a strict **CSP** for the preview document (`default-src 'none'; img-src data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline';`). ([MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe?utm_source=chatgpt.com))
* **Lazy-load heavy engines:** `next/dynamic({ ssr:false })` for Sandpack/Monaco/WebContainers; keep the chat UI instant. ([Next.js](https://nextjs.org/docs/pages/guides/lazy-loading?utm_source=chatgpt.com))
* **Debounce streaming patches:** \~100–300 ms before applying updates to Sandpack to reduce rebuild churn (Sandpack re-compiles as files change). ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com))
* **Optional server bundling:** if artifacts grow, POST files to a route handler, run **esbuild**, return a single artifact for the iframe. ([esbuild](https://esbuild.github.io/?utm_source=chatgpt.com))

---

## 10) Minimal wiring (reference snippets)

### 10.1 Shell mounting & lazy tools (Next.js)

```tsx
// app/layout.tsx
import { CanvasProvider, CanvasPortal } from "@/components/canvas/CanvasProvider";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <CanvasProvider>
          {children}
          <CanvasPortal /> {/* right-side slide-out */}
        </CanvasProvider>
      </body>
    </html>
  );
}
```

```tsx
// components/canvas/CanvasProvider.tsx (sketch)
"use client";
import dynamic from "next/dynamic";
const SandboxTool  = dynamic(() => import("./tools/SandboxTool"), { ssr: false }); // Sandpack/iframe/WebContainers
const MarkdownTool = dynamic(() => import("./tools/MarkdownTool"), { ssr: false });
const DiffTool     = dynamic(() => import("./tools/DiffTool"), { ssr: false });
```

### 10.2 Iframe engine (default one-shot preview)

```tsx
// components/canvas/tools/engines/Iframe.tsx
"use client";
import { useMemo } from "react";
import type { VFS } from "./types";

export function IframeEngine({ files, entry = "/index.html" }:{ files: VFS; entry?: string }) {
  const html = useMemo(() => {
    const index = files[entry]?.content ?? "<h1>Missing index.html</h1>";
    const css   = files["/style.css"]?.content ?? "";
    const js    = files["/script.js"]?.content ?? "";
    return `<!doctype html><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; frame-ancestors 'none'">
<style>${css}</style>${index}<script>${js}<\/script>`;
  }, [files, entry]);

  const src = useMemo(() => URL.createObjectURL(new Blob([html], { type: "text/html" })), [html]);

  return (
    <iframe
      src={src}
      className="h-full w-full bg-white"
      sandbox="allow-scripts allow-forms allow-pointer-lock allow-downloads"
      referrerPolicy="no-referrer"
      onLoad={() => URL.revokeObjectURL(src)}
    />
  );
}
```

(Uses `iframe[sandbox]` + CSP for defense-in-depth.) ([MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe?utm_source=chatgpt.com))

### 10.3 Sandpack engine (when bundling is required)

```tsx
// components/canvas/tools/engines/Sandpack.tsx
"use client";
import {
  SandpackProvider,
  SandpackLayout,
  SandpackCodeEditor,
  SandpackPreview,
} from "@codesandbox/sandpack-react";

export function SandpackEngine({ files, entry = "/index.html" }:{
  files: Record<string, { content: string }>;
  entry?: string;
}) {
  const spFiles = Object.fromEntries(
    Object.entries(files).map(([p, f]) => [p, { code: f.content }])
  );
  return (
    <SandpackProvider template="vanilla" files={spFiles} options={{ activeFile: entry }}>
      <SandpackLayout>
        <SandpackCodeEditor />
        <SandpackPreview />
      </SandpackLayout>
    </SandpackProvider>
  );
}
```

(Sandpack is the official component toolkit for live, in-browser bundling.) ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com))

---

## 11) Acceptance criteria (parity with Canvas/Artifacts)

* **Intelligent auto-open policy:** Canvas Orchestrator Agent makes contextually-aware decisions about when to open Canvas automatically vs. making it available on demand. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com))
* **Smart decision making:** LLM-powered analysis distinguishes between "create a website" (auto-open) vs "show me code" (chat display)
* **Tools available:** Markdown, Code, Diff, Formatter, Sandbox (live site).
* **User control:** Explicit Canvas requests ("open canvas", "edit in canvas") always honored
* **Non-intrusive availability:** Large reports and complex content offer Canvas option via button without auto-opening
* **Hybrid preview engine:** iframe by default; Sandpack when needed; optional WebContainers. ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com), [StackBlitz Docs](https://developer.stackblitz.com/platform/api/webcontainer-api?utm_source=chatgpt.com))
* **Targeted edits & versions:** selection-aware updates + restore older versions. (Artifacts behavior.) ([Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))
* **Decision transparency:** Users understand why Canvas opened or why it's available via reason messages
* **Security:** `iframe[sandbox]` + CSP on all previews. ([MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe?utm_source=chatgpt.com))
* **Performance:** lazy-load heavy bits; no regressions to chat latency. ([Next.js](https://nextjs.org/docs/pages/guides/lazy-loading?utm_source=chatgpt.com))

---

## 12) Implementation Completeness Requirements

### 12.1 Missing Components for Full Implementation

**Canvas UI Components (Critical):**
```typescript
// Required full implementations from this spec:
- components/canvas/CanvasProvider.tsx
- components/canvas/CanvasShell.tsx  
- components/canvas/tools/SandboxTool.tsx
- components/canvas/tools/MarkdownTool.tsx
- components/canvas/tools/CodeTool.tsx
- components/canvas/sse-hub.ts
```

**Type Definitions:**
```typescript
// app/types/canvas.ts - Required
export interface CanvasState {
  isOpen: boolean;
  currentTool: "markdown" | "sandbox" | "code";
  artifacts: Record<string, CanvasArtifact>;
  versions: CanvasVersion[];
  logs: LogEntry[];
}
```

**SSE Hub Implementation:**
```typescript
// app/canvas/sse-hub.ts - Required
const connections = new Map<string, Set<ReadableStreamDefaultController>>();

export function publishAction(userId: string, action: CanvasAction) {
  // Broadcast Canvas actions to connected clients
}
```

**Environment Configuration:**
```bash
# .env.local - Required
CANVAS_ENABLED=true
CANVAS_DEFAULT_TOOL=markdown
CANVAS_MAX_FILE_SIZE=5242880  # 5MB
CANVAS_ALLOWED_EXTENSIONS=.html,.css,.js,.jsx,.md,.json
```

### 12.2 Testing Setup

```python
# tests/integration/test_canvas_orchestrator.py - Required
import pytest
from app.agent import canvas_orchestrator_agent

@pytest.mark.asyncio
async def test_canvas_decision_website():
    state = {
        "user_request": "create a website for my portfolio",
        "final_report_with_citations": "<html>..."
    }
    result = await canvas_orchestrator_agent(state)
    assert result["canvas_decision"]["open_canvas"] == True
    assert result["canvas_decision"]["canvas_type"] == "site"
```

### 12.3 Implementation Checklist

1. [ ] Copy all Canvas UI components from this specification
2. [ ] Implement SSE hub with connection management
3. [ ] Create complete type definitions file
4. [ ] Set up Canvas Provider with state management
5. [ ] Add Canvas API routes for manual triggers
6. [ ] Update SSE broadcaster in Python backend
7. [ ] Configure environment variables
8. [ ] Write comprehensive tests for Canvas Orchestrator Agent
9. [ ] Add error boundaries for Canvas components
10. [ ] Update Makefile with Canvas-specific commands
11. [ ] Integrate Canvas trigger buttons in chat UI
12. [ ] Style Canvas components with Tailwind/shadcn

**Implementation Order:**
1. Backend Canvas Orchestrator Agent (agent logic)
2. Canvas UI components from this specification
3. SSE hub and connection management
4. Canvas trigger integration in chat UI
5. End-to-end testing and refinement

---

## 13) Roadmap (beyond MVP)

* **Server bundling path** with **esbuild** for larger graphs; cache outputs per version. ([esbuild](https://esbuild.github.io/?utm_source=chatgpt.com))
* **Enhanced Canvas Orchestrator:** Machine learning-based intent detection, user preference learning
* **Share & publish:** ZIP download, signed preview URLs, public share pages (Claude's sharing pattern). ([Anthropic Help Center](https://support.anthropic.com/en/articles/9547008-discovering-publishing-customizing-and-sharing-artifacts?utm_source=chatgpt.com))
* **Collaboration:** add **Yjs** for multi-user presence and real-time edits. ([docs.yjs.dev](https://docs.yjs.dev/?utm_source=chatgpt.com))
* **Optional "full IDE":** StackBlitz SDK embed with VM control for advanced users. ([StackBlitz Docs](https://developer.stackblitz.com/platform/api/javascript-sdk?utm_source=chatgpt.com))

---

## 14) Why this approach

* **Intelligent decision making:** Canvas Orchestrator Agent uses LLM reasoning to understand user intent, going beyond simple keyword matching to provide contextually appropriate UI decisions
* **User-centric control:** Respects explicit user requests while making smart defaults, never forcing Canvas when chat is more appropriate
* **Non-intrusive enhancement:** Enhances user experience without being obtrusive - offers Canvas when beneficial, doesn't auto-open for simple queries
* It's **closest in spirit** to OpenAI/Gemini/Claude: a separate, model-invoked workbench for writing/coding, with live previews and versioned artifacts. ([OpenAI](https://openai.com/index/introducing-canvas/?utm_source=chatgpt.com), [Gemini](https://gemini.google/overview/canvas/?utm_source=chatgpt.com), [Anthropic Help Center](https://support.anthropic.com/en/articles/9487310-what-are-artifacts-and-how-do-i-use-them?utm_source=chatgpt.com))
* It stays **shadcn-first** (Sheet/Resizable/Tabs), so it looks native and stays under your control. ([Shadcn UI](https://ui.shadcn.com/docs/components/sheet?utm_source=chatgpt.com))
* The **engine switcher** lets you start lightweight (iframe) and escalate only when needed (Sandpack, server bundling, WebContainers). ([Sandpack](https://sandpack.codesandbox.io/docs?utm_source=chatgpt.com), [esbuild](https://esbuild.github.io/?utm_source=chatgpt.com), [StackBlitz Docs](https://developer.stackblitz.com/platform/api/webcontainer-api?utm_source=chatgpt.com))
* **Flexible presentation layer:** Adapts UI based on content type and user intent, providing the right tool for the right task
