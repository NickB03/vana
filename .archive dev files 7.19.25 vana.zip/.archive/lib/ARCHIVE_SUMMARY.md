# ADK Migration Archive Summary

This archive contains files moved from `/lib` during the ADK migration cleanup.
Archive created: 2025-07-18

## Archival Reason Categories

### 1. Duplicate Google Search Tools
- `_tools/google_search.py` - ADK has native google_search
- `_tools/google_search_v2.py` - ADK has native google_search

### 2. Legacy Version Files (*_v2.py)
- `_tools/content_creation_tools_v2.py`
- `_tools/research_tools_v2.py`
- `_tools/research_tools_adk_v2.py`

### 3. Framework Adapters (Not ADK)
- `_tools/crewai_adapter.py`
- `_tools/langchain_adapter.py`

### 4. MCP Tools (VS Code Dev Tools Only)
- `_tools/mcp_*.py` files
- `_tools/adk_mcp_tools.py`
- `mcp/` entire directory - VS Code development tools only
- `mcp_server/` directory

### 5. Temporarily Disabled
- `sandbox/` directory - Code execution sandbox (per CLAUDE.md)

### 6. OpenRouter Integration (Not Using)
- `model_providers/adk_openrouter_wrapper.py`
- `model_providers/openrouter_provider.py`

### 7. Duplicate/Legacy Coordination Files
- `_tools/task_orchestrator.py`
- `_tools/orchestrated_specialist_tools.py`
- `_tools/workflow_engine.py`
- `_tools/workflow_templates.py`
- `_tools/routing_engine.py`
- `_tools/search_coordinator.py`
- `_tools/message_router.py`
- `_tools/load_balancer.py`
- `_tools/result_aggregator.py`
- `_tools/message_protocol.py`
- `_tools/performance_tracker.py`
- `_tools/capability_matcher.py`
- `_tools/agent_discovery.py`
- `_tools/agent_interface.py`
- `_tools/agent_communication.py`
- `_tools/task_classifier.py`

### 8. Third-Party and Duplicate Tools
- `_tools/third_party_tools.py`
- `_tools/adk_third_party_tools.py`
- `_tools/long_running_tools.py`
- `_tools/adk_long_running_tools.py`
- `_tools/comprehensive_tool_listing.py`
- `_tools/unified_tools.py`
- `_tools/tool_wrappers.py`
- `_tools/web_search_sync.py`

### 9. Legacy Content/Research Tools
- `_tools/content_creation_tools.py`
- `_tools/content_creation_tools_adk.py`
- `_tools/research_tools.py`
- `_tools/research_tools_adk.py`

### 10. JSONRPC Communication (Legacy)
- `_tools/jsonrpc_client.py`
- `_tools/jsonrpc_server.py`

### 11. Other Non-ADK Tools
- `_tools/tool_breadcrumbs.py`
- `_tools/cache.py`
- `_tools/enhanced_reasoning_tools.py`
- `_tools/fixed_specialist_tools.py`
- `_tools/optimized_adk_tools.py`
- `_tools/specialist_tools.py`
- `_tools/database_tools.py`
- `_tools/secure_file_tools.py`
- `_tools/standardized_*.py` files
- `_tools/exceptions.py`
- `_tools/validation.py`

### 12. Shared Libraries (Not in Plan)
- `_shared_libraries/confidence_scorer.py`
- `_shared_libraries/db_connection_pool.py`
- `_shared_libraries/dynamic_agent_factory.py`
- `_shared_libraries/intelligent_cache.py`
- `_shared_libraries/lazy_initialization.py`
- `_shared_libraries/mode_manager.py`
- `_shared_libraries/redis_cache_service.py`
- `_shared_libraries/session_manager.py`
- `_shared_libraries/strategy_orchestrator.py`
- `_shared_libraries/task_router.py`
- `_shared_libraries/tool_optimizer.py`
- `_shared_libraries/tool_standards.py`
- `_shared_libraries/vana_optimizer.py`
- `_shared_libraries/vector_search_service.py`

### 13. Other Directories
- `memory/` - Using adk_memory_service instead
- `performance/` - Legacy optimizations
- `_sub_agents/` - Empty directory
- `tools/` - Empty directory

## Files Kept (Align with ADK Plan)

### _tools/
- `__init__.py`
- `adk_tools.py` - Core ADK tools
- `agent_tools.py` - Agent-specific tools
- `real_coordination_tools.py` - Coordination implementation
- `registry.py` - Tool registry system
- `task_analyzer.py` - Task analysis

### _shared_libraries/
- `__init__.py`
- `adk_memory_service.py` - VANA's memory system
- `coordination_manager.py` - Coordination management
- `orchestrator_metrics.py` - Performance metrics

### Other Kept Directories
- `adk_integration/` - Core ADK integration
- `context/` - Specialist context management
- `logging/` - Logging infrastructure
- `model_strategy/` - Model selection strategy
- `monitoring/` - Production monitoring
- `security/` - Security infrastructure

## Total Files Archived
- Approximately 85 files moved to archive
- Kept only essential ADK-aligned components
- Preserved directory structure in archive for potential recovery