# MCP (Model Context Protocol) Clarification

## Important Distinction

There are **two separate systems** that should not be confused:

### 1. 🛠️ MCP Servers (VS Code Development Tools)

**What they are**:
- Local development tools for VS Code Claude extension
- Help maintain context during development sessions
- Provide semantic search and memory for coding assistance
- Run on developer's machine only

**Location**:
- `lib/mcp/servers/` - MCP server implementations
- `scripts/local_memory_server.py` - Local memory MCP
- Configuration in VS Code's `settings.json`

**Usage**:
- Start manually: `python scripts/local_memory_server.py`
- Configure in VS Code Claude extension
- Used by Claude to remember context between coding sessions

**NOT used for**:
- Production runtime
- VANA's agent memory
- User interactions

### 2. 🚀 VANA's Production Memory System

**What it is**:
- VANA's actual memory service for agent coordination
- Manages agent task history and context
- Enables intelligent routing and specialist activation
- Part of VANA's runtime architecture

**Location**:
- `lib/_shared_libraries/adk_memory_service.py`
- Integrated directly into agent code

**Usage**:
- Automatically initialized when VANA starts
- Manages agent handoffs and context
- Stores conversation history for continuity

**Used for**:
- Production agent coordination
- Task routing decisions
- Context preservation across agent transfers

## Common Confusion Points

### ❌ Incorrect Understanding:
"The Chroma MCP server needs to be updated for production"

### ✅ Correct Understanding:
"The Chroma MCP server is a VS Code tool. VANA's production memory uses the ADK memory service."

### ❌ Incorrect Understanding:
"MCP servers handle VANA's memory in production"

### ✅ Correct Understanding:
"MCP servers are development tools. VANA uses its own memory service in production."

## Architecture Diagram

```
┌─────────────────────────────────────┐
│       Development Environment       │
├─────────────────────────────────────┤
│                                     │
│  VS Code + Claude Extension         │
│           ↓                         │
│    MCP Servers (Local)              │
│    - Memory MCP                     │
│    - Chroma MCP                     │
│    - GitHub MCP                     │
│                                     │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│      VANA Production Runtime       │
├─────────────────────────────────────┤
│                                     │
│  VANA Agents                        │
│       ↓                             │
│  ADK Memory Service                 │
│  (adk_memory_service.py)            │
│       ↓                             │
│  In-Memory or Vector DB             │
│                                     │
└─────────────────────────────────────┘
```

## Summary

- **MCP Servers**: VS Code development tools (not for production)
- **ADK Memory Service**: VANA's production memory system
- **No updates needed**: MCP servers don't affect production deployment
- **Focus on**: ADK event streaming and production configuration

When deploying VANA to production, you can completely ignore MCP servers - they're only for local development with VS Code.