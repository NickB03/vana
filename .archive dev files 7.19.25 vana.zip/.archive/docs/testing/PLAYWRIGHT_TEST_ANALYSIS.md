# Playwright Test Suite Analysis - Quality & Usefulness Assessment

## Executive Summary

After analyzing the Playwright test suite for VANA Phase 1, I've identified several critical issues that would lead to **high false positive rates** and **low practical value**. The tests need significant improvements to be useful for real-world testing.

## Critical Issues

### 1. **Selector Strategy Problems** 🔴

**Current Implementation:**
```typescript
const chatInput = page.locator('[data-testid="chat-input"], textarea, input[type="text"]').first();
const submitButton = page.locator('[data-testid="submit-button"], button[type="submit"], button:has-text("Send")').first();
```

**Problems:**
- Uses `data-testid` attributes that don't exist in the actual UI
- Falls back to generic selectors that could match wrong elements
- The actual UI uses `PromptBox` component, not standard inputs

**Real UI Structure:**
- Chat page uses `<PromptBox>` component from `@/components/ui/chatgpt-prompt-input`
- Messages are rendered in a custom structure, not with `data-testid="message"`
- Submit might be handled within PromptBox, not a separate button

### 2. **Response Detection Issues** 🔴

**Current Implementation:**
```typescript
async function waitForResponse(page: Page, timeout = 20000) {
  const loadingIndicator = page.locator('[data-testid="loading"], .loading, .typing-indicator').first();
  try {
    await loadingIndicator.waitFor({ state: 'hidden', timeout: timeout });
  } catch {
    // Loading indicator might not be present
  }
  await page.waitForTimeout(1000); // Arbitrary wait
}
```

**Problems:**
- Assumes loading indicators that may not exist
- Uses arbitrary 1-second wait (unreliable)
- No verification that response is actually complete
- Could pass even if no response is received

### 3. **Content Validation Too Generic** 🟡

**Current Implementation:**
```typescript
expect(response.toLowerCase()).toContain('executive summary');
expect(response.toLowerCase()).toContain('cloud security');
expect(response).toMatch(/#{1,3}\s+/); // Any markdown header
```

**Problems:**
- Checks are too broad and could match unrelated content
- Doesn't verify the specialist actually responded
- Could pass with error messages containing keywords
- No validation of response quality or structure

### 4. **Missing Specialist Routing Verification** 🔴

The tests don't verify that:
- The correct specialist was engaged
- The orchestrator properly routed the request
- The specialist's specific tools were used
- The response format matches specialist output

### 5. **Error Handling Assumptions** 🟡

**Current Test:**
```typescript
test('should handle errors gracefully', async ({ page }) => {
  const prompt = 'Do the thing with the stuff';
  // ...
  const asksClarification = response.toLowerCase().includes('clarify') ||
                           response.toLowerCase().includes('specific');
  expect(asksClarification).toBeTruthy();
});
```

**Problems:**
- Assumes specific error message format
- Doesn't test actual error scenarios
- Could pass with any response containing "specific"

## Recommendations for High-Quality Tests

### 1. **Fix Selector Strategy**

```typescript
// Better approach - wait for actual UI elements
async function submitPrompt(page: Page, prompt: string) {
  // Wait for the prompt box component
  const promptBox = page.locator('.prompt-box, [class*="prompt"], form').first();
  await promptBox.waitFor({ state: 'visible' });
  
  // Find the actual input within the component
  const input = promptBox.locator('input, textarea').first();
  await input.fill(prompt);
  
  // Submit via Enter key (more reliable than button click)
  await input.press('Enter');
}
```

### 2. **Improve Response Detection**

```typescript
async function waitForResponse(page: Page, timeout = 20000) {
  // Wait for network activity to complete
  await page.waitForLoadState('networkidle', { timeout: 5000 }).catch(() => {});
  
  // Wait for new message to appear
  const messageCountBefore = await page.locator('.message, [class*="message"]').count();
  
  await page.waitForFunction(
    (countBefore) => {
      const messages = document.querySelectorAll('.message, [class*="message"]');
      return messages.length > countBefore;
    },
    messageCountBefore,
    { timeout }
  );
  
  // Wait for streaming to complete (no DOM changes for 500ms)
  await page.waitForFunction(
    () => {
      const lastMessage = Array.from(document.querySelectorAll('.message, [class*="message"]')).pop();
      if (!lastMessage) return false;
      
      const initialContent = lastMessage.textContent;
      return new Promise(resolve => {
        setTimeout(() => {
          resolve(lastMessage.textContent === initialContent);
        }, 500);
      });
    },
    { timeout: 5000 }
  );
}
```

### 3. **Add Specialist-Specific Validation**

```typescript
test('should route to content creation specialist', async ({ page }) => {
  const prompt = 'Write a technical report about cloud security';
  await submitPrompt(page, prompt);
  await waitForResponse(page);
  
  const response = await getLastResponse(page);
  
  // Verify specialist routing
  expect(response).toMatch(/content.*creation|writing.*specialist/i);
  
  // Verify document structure
  const hasProperStructure = 
    response.includes('# ') && // Main title
    response.split('## ').length >= 3 && // Multiple sections
    response.includes('Executive Summary') || response.includes('Introduction');
    
  expect(hasProperStructure).toBeTruthy();
  
  // Verify it's not a generic response
  expect(response).not.toMatch(/I can help|I'll assist|How can I/i);
});
```

### 4. **Test Actual Specialist Features**

```typescript
test('should use research specialist tools', async ({ page }) => {
  const prompt = 'Research quantum computing with credible sources';
  await submitPrompt(page, prompt);
  await waitForResponse(page);
  
  const response = await getLastResponse(page);
  
  // Check for research-specific outputs
  const researchIndicators = [
    response.includes('Source') || response.includes('Reference'),
    response.includes('credibility') || response.includes('reliable'),
    response.includes('findings') || response.includes('research'),
    response.match(/\d{4}/) // Year citations
  ];
  
  const researchCount = researchIndicators.filter(Boolean).length;
  expect(researchCount).toBeGreaterThanOrEqual(2);
});
```

### 5. **Add Debug Helpers**

```typescript
// Add screenshot on failure
test.afterEach(async ({ page }, testInfo) => {
  if (testInfo.status !== 'passed') {
    await page.screenshot({ 
      path: `test-failures/${testInfo.title}-${Date.now()}.png`,
      fullPage: true 
    });
    
    // Log page content for debugging
    const pageContent = await page.content();
    console.log('Page HTML:', pageContent);
  }
});
```

### 6. **Create Page Object Model**

```typescript
class VanaChatPage {
  constructor(private page: Page) {}
  
  async navigate() {
    await this.page.goto('/chat');
    await this.page.waitForLoadState('networkidle');
  }
  
  async sendMessage(message: string) {
    // Implement proper selector strategy
    const input = await this.findChatInput();
    await input.fill(message);
    await input.press('Enter');
  }
  
  async waitForResponse() {
    // Implement robust response detection
  }
  
  async getLastMessage(): Promise<string> {
    // Implement message extraction
  }
  
  private async findChatInput() {
    // Try multiple strategies to find input
    const selectors = [
      'input[placeholder*="message"]',
      'textarea[placeholder*="message"]',
      '.prompt-box input',
      'form input[type="text"]'
    ];
    
    for (const selector of selectors) {
      const element = this.page.locator(selector).first();
      if (await element.isVisible().catch(() => false)) {
        return element;
      }
    }
    
    throw new Error('Could not find chat input');
  }
}
```

## Summary of Required Changes

1. **Replace all generic selectors** with UI-specific selectors based on actual implementation
2. **Implement proper response detection** using DOM monitoring, not arbitrary waits
3. **Add specialist-specific validations** to ensure correct routing and functionality
4. **Remove assumptions** about UI structure and error messages
5. **Add debugging capabilities** for when tests fail
6. **Create reusable page objects** for maintainability

## Expected Impact

**Before Changes:**
- False positive rate: ~70-80%
- Tests pass even when features are broken
- Difficult to debug failures
- Brittle and break with UI changes

**After Changes:**
- False positive rate: <10%
- Tests accurately reflect feature status
- Clear failure messages with screenshots
- Resilient to minor UI changes
- Actually useful for catching regressions

## Next Steps

1. Inspect the actual VANA UI to identify correct selectors
2. Implement the improved helper functions
3. Rewrite tests with specialist-specific validations
4. Add proper error scenarios
5. Create a test data fixture system
6. Set up visual regression testing for UI changes

The current test suite provides a good structure but needs significant improvements to be useful for real-world testing. Focus should be on making tests that actually verify the features work, not just that some response is received.