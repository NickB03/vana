# Memory MCP Integration Guide for VS Code Local Development

**⚠️ CRITICAL: This MCP integration is EXCLUSIVELY for local development using VS Code. It is NOT part of the VANA runtime application and has NO relationship to VANA's memory systems.**

## Important Distinction

- **Memory MCP**: A VS Code development tool for Claude to maintain context during coding sessions
- **VANA Memory Service**: The actual production memory system used by VANA agents (located in `lib/_shared_libraries/adk_memory_service.py`)
- **These are completely separate systems that serve different purposes**

## Overview

The Memory MCP server (`mcp__memory-mcp`) is a **VS Code development tool** that provides knowledge graph capabilities for Claude to maintain context during your local development sessions. This helps Claude remember important information about your project, decisions, and code relationships while you work.

**This tool is NOT used by the VANA application** - VANA has its own memory service for agent coordination.

## Prerequisites

1. **VS Code**: With Claude extension installed
2. **MCP Configuration**: Proper settings in VS Code's Claude configuration
3. **Local Development Environment**: This only works during VS Code sessions

## VS Code Configuration

Configure MCP in VS Code's Claude settings (not in VANA's configuration):

```json
// In VS Code's Claude extension settings
{
  "mcp.servers": {
    "memory-mcp": {
      "command": "python",
      "args": ["-m", "lib.mcp.servers.memory_server"],
      "env": {
        "MEMORY_STORE_PATH": "./.development/claude-memory"
      }
    }
  }
}
```

## Available Functions in VS Code

When working with Claude in VS Code, you have access to these memory functions:

### Entity Management

#### Create Entities
```python
# Store information about project components
mcp__memory-mcp__create_entities(
    entities=[
        {
            "name": "VANA Orchestrator",
            "entityType": "component",
            "observations": [
                "Main task routing agent",
                "Uses Gemini 2.5 Flash model",
                "Has 8 core tools"
            ]
        }
    ]
)
```

#### Create Relations
```python
# Define relationships between entities
mcp__memory-mcp__create_relations(
    relations=[
        {
            "from": "VANA Orchestrator",
            "to": "Master Orchestrator",
            "relationType": "delegates_to"
        }
    ]
)
```

#### Add Observations
```python
# Add new information to existing entities
mcp__memory-mcp__add_observations(
    observations=[
        {
            "entityName": "VANA Orchestrator",
            "contents": ["Now supports streaming responses"]
        }
    ]
)
```

### Query Operations

#### Search Nodes
```python
# Find information in the knowledge graph
results = mcp__memory-mcp__search_nodes(
    query="orchestrator"
)
```

#### Read Full Graph
```python
# Get complete knowledge graph
graph = mcp__memory-mcp__read_graph()
```

#### Open Specific Nodes
```python
# Get detailed information about specific entities
nodes = mcp__memory-mcp__open_nodes(
    names=["VANA Orchestrator", "Master Orchestrator"]
)
```

## VS Code Development Workflow

### 1. Project Understanding
```python
# When starting to work on VANA
mcp__memory-mcp__create_entities(
    entities=[
        {
            "name": "VANA Project",
            "entityType": "project",
            "observations": [
                "Multi-agent AI system",
                "Built on Google ADK",
                "Uses hierarchical orchestration"
            ]
        }
    ]
)
```

### 2. Track Architecture Decisions
```python
# Record important decisions
mcp__memory-mcp__create_entities(
    entities=[
        {
            "name": "Python 3.13 Requirement",
            "entityType": "decision",
            "observations": [
                "Required for Google ADK compatibility",
                "Needed for modern async patterns",
                "Critical for SSL/TLS in production"
            ]
        }
    ]
)
```

### 3. Map Code Relationships
```python
# Track how components interact
mcp__memory-mcp__create_relations(
    relations=[
        {
            "from": "main.py",
            "to": "VANA Chat Agent",
            "relationType": "initializes"
        },
        {
            "from": "VANA Chat Agent",
            "to": "analyze_task_tool",
            "relationType": "uses"
        }
    ]
)
```

### 4. Development Context
```python
# Remember current work context
mcp__memory-mcp__create_entities(
    entities=[
        {
            "name": "Current Task",
            "entityType": "task",
            "observations": [
                "Implementing new development setup",
                "Created Makefile for unified commands",
                "Added Docker support"
            ]
        }
    ]
)
```

## Critical Distinctions from VANA's Memory

### Memory MCP (VS Code Tool)
- **Purpose**: Help Claude maintain context during development
- **Scope**: Local VS Code sessions only
- **Data**: Development notes, code relationships, decisions
- **Persistence**: Local development files
- **Users**: You and Claude during coding

### VANA Memory Service (Production System)
- **Purpose**: Agent coordination and task memory
- **Scope**: Runtime application memory
- **Data**: Agent interactions, task history, execution context
- **Persistence**: In-memory or vector database (production)
- **Users**: VANA agents during execution

## Best Practices

### 1. Clear Entity Types
```python
# Use descriptive types for clarity
entity_types = [
    "component",      # Code components
    "decision",       # Architecture decisions
    "bug",           # Known issues
    "feature",       # Feature implementations
    "dependency",    # External dependencies
    "configuration"  # Config settings
]
```

### 2. Meaningful Relations
```python
# Use clear relationship types
relation_types = [
    "implements",     # Code implementation
    "depends_on",     # Dependencies
    "delegates_to",   # Task delegation
    "configures",     # Configuration
    "resolves",       # Bug fixes
    "extends"         # Feature extensions
]
```

### 3. Session Management
```python
# At start of development session
mcp__memory-mcp__create_entities(
    entities=[{
        "name": f"Dev Session {datetime.now()}",
        "entityType": "session",
        "observations": ["Starting work on X feature"]
    }]
)

# Track progress
mcp__memory-mcp__add_observations(
    observations=[{
        "entityName": f"Dev Session {datetime.now()}",
        "contents": ["Completed Y task", "Found issue with Z"]
    }]
)
```

## Common Use Cases

### 1. Onboarding New Features
```python
# Document new feature implementation
mcp__memory-mcp__create_entities(
    entities=[{
        "name": "Docker Development Setup",
        "entityType": "feature",
        "observations": [
            "Added docker-compose.yml",
            "Created Dockerfile.dev",
            "Supports PostgreSQL database"
        ]
    }]
)
```

### 2. Tracking TODOs
```python
# Remember tasks for later
mcp__memory-mcp__create_entities(
    entities=[{
        "name": "Pending Tasks",
        "entityType": "todo",
        "observations": [
            "Add integration tests for new setup",
            "Update CI/CD pipeline",
            "Document Docker commands"
        ]
    }]
)
```

### 3. Bug Investigation
```python
# Track bug details
mcp__memory-mcp__create_entities(
    entities=[{
        "name": "Port 8081 Conflict",
        "entityType": "bug",
        "observations": [
            "Multiple Python processes on same port",
            "Occurs when not properly shutting down",
            "Fixed by killing processes before starting"
        ]
    }]
)
```

## Important Notes

1. **VS Code Only**: This MCP is only available when using Claude in VS Code
2. **Development Context**: Used for maintaining context during coding sessions
3. **Not Production Data**: Never stores actual VANA application data
4. **Local Storage**: All data is stored locally in your development environment
5. **Session-Based**: Best used for maintaining context within development sessions

## Troubleshooting

### Memory Not Persisting
- Check VS Code MCP configuration
- Verify `MEMORY_STORE_PATH` is writable
- Ensure MCP server is running

### Cannot Find Entities
- Use `search_nodes` with partial matches
- Check entity names for typos
- Use `read_graph` to see all entities

### Performance Issues
- Limit observations per entity
- Use specific queries instead of full graph reads
- Clean up old session data periodically

## DO NOT CONFUSE WITH

- **VANA's ADK Memory Service**: The actual runtime memory system
- **Agent Memory**: Production agent coordination memory
- **Vector Database**: Production semantic search system
- **Task History**: Production task execution history

## Further Resources

- [VS Code Claude Extension](https://marketplace.visualstudio.com/items?itemName=claude.claude-vscode)
- [MCP Protocol Specification](https://github.com/modelcontextprotocol/spec)
- [VANA Memory Service Documentation](../architecture/memory-service.md) (the actual VANA memory, not this MCP)