# CRITICAL: MCP vs VANA Memory Systems

## ⚠️ THESE ARE COMPLETELY DIFFERENT SYSTEMS ⚠️

This document exists to prevent any confusion between VS Code MCP tools and VANA's actual memory systems.

## Quick Reference Table

| Feature | MCP Tools | VANA Memory Service |
|---------|-----------|-------------------|
| **Purpose** | VS Code development aid | Production agent memory |
| **Users** | Claude in VS Code | VANA agents at runtime |
| **Location** | `lib/mcp/servers/` | `lib/_shared_libraries/adk_memory_service.py` |
| **When Active** | Only during VS Code sessions | Always when VANA is running |
| **Data Stored** | Dev notes, context | Agent interactions, task history |
| **Configuration** | VS Code settings.json | .env.local, environment vars |
| **Part of VANA?** | ❌ NO | ✅ YES |

## MCP Tools (VS Code Development Only)

### What They Are
- **Chroma MCP**: VS Code tool for semantic search during development
- **Memory MCP**: VS Code tool for maintaining context between Claude sessions
- Tools that help Claude understand your codebase better during development
- Local development aids that exist only in your VS Code environment

### What They Are NOT
- ❌ NOT part of VANA's runtime
- ❌ NOT used by VANA agents
- ❌ NOT production memory systems
- ❌ NOT deployed with VANA
- ❌ NOT accessible outside VS Code

### Where They Live
```
lib/mcp/servers/
├── chroma_server.py      # VS Code tool only
└── memory_server.py      # VS Code tool only
```

### Configuration
```json
// In VS Code's settings.json (NOT in VANA config)
{
  "mcp.servers": {
    "chroma-vana": { ... },
    "memory-mcp": { ... }
  }
}
```

## VANA's Actual Memory Systems

### What They Are
- **ADK Memory Service**: Production memory for agent coordination
- **In-Memory Storage**: Development/testing memory backend
- **Vector DB Integration**: Production memory storage (when configured)
- Core components of VANA's agent orchestration system

### Where They Live
```
lib/_shared_libraries/
├── adk_memory_service.py    # VANA's actual memory service
└── memory_tools.py          # Memory tools for agents
```

### Configuration
```bash
# In .env.local (VANA's actual configuration)
GOOGLE_API_KEY=...
USE_VERTEX_AI=false
# No MCP configuration here!
```

### Usage by Agents
```python
# How VANA agents use memory (NOT MCP)
from lib._shared_libraries.adk_memory_service import get_memory_service

memory_service = get_memory_service()
# This is VANA's memory, not MCP!
```

## Common Misconceptions to Avoid

### ❌ WRONG: "VANA uses Chroma MCP for memory"
✅ **CORRECT**: VANA has its own memory service. Chroma MCP is a VS Code tool for development.

### ❌ WRONG: "Configure MCP in .env.local"
✅ **CORRECT**: MCP is configured in VS Code settings. VANA's memory is configured in .env.local.

### ❌ WRONG: "Agents can access MCP servers"
✅ **CORRECT**: MCP servers are only accessible to Claude in VS Code. Agents use VANA's memory service.

### ❌ WRONG: "Memory MCP stores VANA's agent data"
✅ **CORRECT**: Memory MCP stores VS Code development context. VANA's memory service stores agent data.

## How to Explain This to Others

When someone asks about MCP:
> "MCP tools (Chroma and Memory) are VS Code extensions that help Claude understand our codebase during development sessions. They are NOT part of VANA itself. VANA has its own memory service for agent coordination."

When someone asks about VANA's memory:
> "VANA uses the ADK Memory Service (in `lib/_shared_libraries/adk_memory_service.py`) for agent memory and coordination. This is completely separate from the VS Code MCP tools."

## Documentation References

### For MCP (VS Code Tools)
- `docs/mcp/CHROMA_MCP_GUIDE.md` - How to use Chroma in VS Code
- `docs/mcp/MEMORY_MCP_GUIDE.md` - How to use Memory MCP in VS Code

### For VANA's Memory
- `lib/_shared_libraries/adk_memory_service.py` - The actual implementation
- `docs/architecture/memory-service.md` - Architecture documentation
- Agent implementations in `agents/*/` - How agents use memory

## Final Reminder

🚨 **MCP = VS Code Development Tool**
🚨 **VANA Memory = Production Agent System**
🚨 **They are NEVER the same thing**

If you're still confused, remember:
- If it starts with `mcp__`, it's a VS Code tool
- If it's in `lib/_shared_libraries/adk_memory_service.py`, it's VANA's memory
- If you're configuring it in VS Code, it's MCP
- If you're configuring it in `.env.local`, it's VANA