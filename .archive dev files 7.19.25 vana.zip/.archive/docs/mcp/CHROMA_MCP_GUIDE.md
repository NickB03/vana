# Chroma MCP Integration Guide for VS Code Local Development

**⚠️ IMPORTANT: This MCP integration is strictly for local development using VS Code. It is NOT part of the VANA runtime application.**

This guide explains how to use the Chroma vector database integration through VS Code's Model Context Protocol (MCP) server during local development sessions with Claude.

## Overview

The Chroma MCP server (`mcp__chroma-vana`) is a **VS Code development tool** that provides vector database capabilities for semantic search, document retrieval, and embedding management during your local development workflow. This helps Claude understand your codebase better and provide more context-aware assistance.

**This is NOT used by the VANA application itself** - it's purely a development aid for working with Claude in VS Code.

## Prerequisites

1. **VS Code**: With Claude extension installed
2. **Chroma Server**: A local Chroma instance for development
3. **MCP Configuration**: Proper settings in VS Code's Claude configuration

## Setup

### Option 1: Docker (Recommended)

```bash
# Start Chroma server
docker run -d -p 8000:8000 chromadb/chroma

# Verify it's running
curl http://localhost:8000/api/v1/version
```

### Option 2: Local Installation

```bash
# Install Chroma
pip install chromadb

# Start server
chroma run --path ./chroma_data --port 8000
```

### VS Code Configuration

Configure MCP in VS Code's Claude settings (not in VANA's `.env.local`):

```json
// In VS Code's Claude extension settings
{
  "mcp.servers": {
    "chroma-vana": {
      "command": "python",
      "args": ["-m", "lib.mcp.servers.chroma_server"],
      "env": {
        "CHROMA_HOST": "localhost",
        "CHROMA_PORT": "8000"
      }
    }
  }
}
```

## Available Functions in VS Code

When working with Claude in VS Code, you have access to these Chroma functions for managing your development knowledge base:

### Collection Management

#### List Collections
```python
# List all collections
result = mcp__chroma-vana__chroma_list_collections(
    limit=10,
    offset=0
)
# Returns: ["collection1", "collection2"] or ["__NO_COLLECTIONS_FOUND__"]
```

#### Create Collection
```python
# Create a new collection
mcp__chroma-vana__chroma_create_collection(
    collection_name="project_docs",
    embedding_function_name="default",  # Options: default, openai, cohere, etc.
    metadata={"description": "Project documentation"}
)
```

#### Get Collection Info
```python
# Get collection details
info = mcp__chroma-vana__chroma_get_collection_info(
    collection_name="project_docs"
)
# Returns: metadata, count, embedding info
```

#### Delete Collection
```python
# Delete a collection
mcp__chroma-vana__chroma_delete_collection(
    collection_name="project_docs"
)
```

### Document Operations

#### Add Documents
```python
# Add documents to collection
mcp__chroma-vana__chroma_add_documents(
    collection_name="project_docs",
    documents=[
        "VANA is a multi-agent AI system",
        "It uses Google ADK for orchestration"
    ],
    ids=["doc1", "doc2"],
    metadatas=[
        {"type": "overview", "section": "intro"},
        {"type": "architecture", "section": "core"}
    ]
)
```

#### Query Documents
```python
# Semantic search
results = mcp__chroma-vana__chroma_query_documents(
    collection_name="project_docs",
    query_texts=["How does VANA work?"],
    n_results=5,
    where={"type": "overview"},  # Optional metadata filter
    include=["documents", "metadatas", "distances"]
)
```

#### Get Documents
```python
# Retrieve specific documents
docs = mcp__chroma-vana__chroma_get_documents(
    collection_name="project_docs",
    ids=["doc1", "doc2"],  # Optional: specific IDs
    where={"section": "intro"},  # Optional: metadata filter
    limit=10,
    offset=0
)
```

#### Update Documents
```python
# Update existing documents
mcp__chroma-vana__chroma_update_documents(
    collection_name="project_docs",
    ids=["doc1"],
    documents=["Updated content for VANA"],
    metadatas=[{"type": "overview", "updated": "2025-07-10"}]
)
```

#### Delete Documents
```python
# Remove documents
mcp__chroma-vana__chroma_delete_documents(
    collection_name="project_docs",
    ids=["doc1", "doc2"]
)
```

## Query Filters

Chroma supports advanced metadata filtering:

```python
# Simple equality
where = {"type": "overview"}

# Comparison operators
where = {"priority": {"$gt": 5}}

# Logical AND
where = {
    "$and": [
        {"type": "documentation"},
        {"priority": {"$gte": 3}}
    ]
}

# Logical OR
where = {
    "$or": [
        {"section": "intro"},
        {"section": "overview"}
    ]
}

# Use in queries
results = mcp__chroma-vana__chroma_query_documents(
    collection_name="project_docs",
    query_texts=["VANA features"],
    where=where,
    n_results=10
)
```

## Best Practices

### 1. Collection Naming
- Use descriptive names: `project_docs`, `user_queries`, `code_snippets`
- Avoid special characters
- Keep names consistent with your domain

### 2. Document IDs
- Use meaningful, unique IDs
- Consider using hashes for consistency
- Format: `{type}_{timestamp}_{hash}`

### 3. Metadata Design
```python
# Good metadata structure
metadata = {
    "type": "documentation",
    "source": "README.md",
    "section": "overview",
    "created_at": "2025-07-10",
    "tags": ["intro", "setup"],
    "version": "1.0"
}
```

### 4. Batch Operations
```python
# Add documents in batches for better performance
documents = []
ids = []
metadatas = []

for i, doc in enumerate(large_document_set):
    documents.append(doc.content)
    ids.append(f"doc_{i}")
    metadatas.append(doc.metadata)
    
    # Batch every 100 documents
    if len(documents) >= 100:
        mcp__chroma-vana__chroma_add_documents(
            collection_name="large_collection",
            documents=documents,
            ids=ids,
            metadatas=metadatas
        )
        documents, ids, metadatas = [], [], []
```

### 5. Embedding Functions
- `default`: General purpose (recommended)
- `openai`: Requires OpenAI API key
- `cohere`: Requires Cohere API key
- Choose based on your use case and available APIs

## Common Use Cases

### 1. Document Q&A System
```python
# Setup
mcp__chroma-vana__chroma_create_collection(
    collection_name="knowledge_base",
    embedding_function_name="default"
)

# Index documents
mcp__chroma-vana__chroma_add_documents(
    collection_name="knowledge_base",
    documents=document_contents,
    ids=document_ids,
    metadatas=document_metadata
)

# Query
results = mcp__chroma-vana__chroma_query_documents(
    collection_name="knowledge_base",
    query_texts=[user_question],
    n_results=3
)
```

### 2. Code Search
```python
# Create code collection
mcp__chroma-vana__chroma_create_collection(
    collection_name="codebase",
    embedding_function_name="default",
    metadata={"project": "vana"}
)

# Index code files
for file_path, content in code_files:
    mcp__chroma-vana__chroma_add_documents(
        collection_name="codebase",
        documents=[content],
        ids=[file_path],
        metadatas=[{
            "language": "python",
            "path": file_path,
            "type": "source_code"
        }]
    )
```

### 3. Conversation Memory
```python
# Store conversation context
mcp__chroma-vana__chroma_add_documents(
    collection_name="conversations",
    documents=[message.content],
    ids=[message.id],
    metadatas=[{
        "user_id": user_id,
        "timestamp": timestamp,
        "session_id": session_id,
        "role": message.role
    }]
)

# Retrieve relevant context
context = mcp__chroma-vana__chroma_query_documents(
    collection_name="conversations",
    query_texts=[current_message],
    where={"session_id": session_id},
    n_results=5
)
```

## Troubleshooting

### Connection Issues
```bash
# Check Chroma is running
curl http://localhost:8000/api/v1/version

# Check MCP server status
grep "MCP_CHROMA" .env.local
```

### Performance Tips
1. Use appropriate `n_results` (default: 5)
2. Index metadata for faster filtering
3. Batch operations when possible
4. Monitor collection sizes

### Common Errors

**"Collection not found"**
- Verify collection exists with `chroma_list_collections()`
- Check spelling and case sensitivity

**"Embedding dimension mismatch"**
- Ensure consistent embedding function across operations
- Recreate collection if changing embedding function

**"Connection refused"**
- Check Chroma server is running
- Verify host/port in `.env.local`

## VS Code Development Workflow

Use Chroma MCP during development to help Claude understand your project better:

### 1. Index Your Codebase
```python
# When starting a development session
mcp__chroma-vana__chroma_create_collection(
    collection_name="vana_codebase",
    embedding_function_name="default"
)

# Index important files
for file_path, content in project_files:
    mcp__chroma-vana__chroma_add_documents(
        collection_name="vana_codebase",
        documents=[content],
        ids=[file_path],
        metadatas=[{"type": "source_code", "path": file_path}]
    )
```

### 2. Store Development Context
```python
# Save important decisions or context
mcp__chroma-vana__chroma_add_documents(
    collection_name="dev_context",
    documents=["We decided to use ADK for agent orchestration because..."],
    ids=["decision_001"],
    metadatas=[{"type": "architecture_decision", "date": "2025-07-10"}]
)
```

### 3. Query During Development
```python
# Help Claude find relevant code
results = mcp__chroma-vana__chroma_query_documents(
    collection_name="vana_codebase",
    query_texts=["How is task routing implemented?"],
    n_results=5
)
```

## Important Notes

1. **Development Only**: This MCP integration is exclusively for VS Code local development
2. **Not Production**: The VANA application uses its own memory and storage systems
3. **VS Code Specific**: Configuration is done through VS Code's Claude extension settings
4. **Local Context**: Helps maintain context across development sessions with Claude

## Further Resources

- [Chroma Documentation](https://docs.trychroma.com/)
- [VS Code Claude Extension](https://marketplace.visualstudio.com/items?itemName=claude.claude-vscode)
- [MCP Protocol Specification](https://github.com/modelcontextprotocol/spec)