"""
VANA Administration Dashboard

A Streamlit-based dashboard for monitoring and managing the VANA multi-agent system.
This provides real-time insights into agent performance, system health, and usage analytics.
"""

import asyncio
import json
import os
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import requests
import streamlit as st
from plotly.subplots import make_subplots

# Add project root to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from lib._shared_libraries.adk_memory_service import get_adk_memory_service
    from lib.monitoring.health_check import get_system_health
    from lib.monitoring.performance_monitor import get_performance_metrics
except ImportError as e:
    st.error(f"Failed to import VANA modules: {e}")
    st.stop()


class VANADashboard:
    """Main dashboard class for VANA administration interface."""
    
    def __init__(self):
        self.setup_page_config()
        self.load_configuration()
        
    def setup_page_config(self):
        """Configure Streamlit page settings."""
        st.set_page_config(
            page_title="VANA Admin Dashboard",
            page_icon="🤖",
            layout="wide",
            initial_sidebar_state="expanded"
        )
        
    def load_configuration(self):
        """Load dashboard configuration."""
        self.environments = {
            "development": os.getenv("VANA_DEV_URL", "http://localhost:8080"),
            "production": os.getenv("VANA_PROD_URL", "https://vana-prod-960076421399.us-central1.run.app")
        }
        
    def render_header(self):
        """Render dashboard header."""
        st.title("🤖 VANA Multi-Agent System Dashboard")
        st.markdown("---")
        
        # Environment selector
        col1, col2, col3 = st.columns([2, 1, 1])
        with col1:
            self.selected_env = st.selectbox(
                "Environment",
                options=list(self.environments.keys()),
                index=0
            )
        
        with col2:
            self.auto_refresh = st.checkbox("Auto Refresh (30s)", value=False)
            
        with col3:
            if st.button("🔄 Refresh Now"):
                st.rerun()
                
    def get_agent_health(self, environment: str) -> Dict:
        """Get health status for all agents."""
        try:
            base_url = self.environments[environment]
            response = requests.get(f"{base_url}/health", timeout=10)
            
            if response.status_code == 200:
                health_data = response.json()
                
                # Get agent list
                agents_response = requests.get(f"{base_url}/list-apps", timeout=10)
                if agents_response.status_code == 200:
                    agents_data = agents_response.json()
                    health_data["agents"] = agents_data.get("agents", [])
                
                return health_data
            else:
                return {"status": "unhealthy", "error": f"HTTP {response.status_code}"}
                
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def render_system_overview(self):
        """Render system overview section."""
        st.header("📊 System Overview")
        
        health_data = self.get_agent_health(self.selected_env)
        
        # Status metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            status = health_data.get("status", "unknown")
            if status == "healthy":
                st.metric("System Status", "🟢 Healthy")
            else:
                st.metric("System Status", "🔴 Unhealthy")
        
        with col2:
            agents = health_data.get("agents", [])
            st.metric("Active Agents", len(agents))
        
        with col3:
            memory_enabled = health_data.get("memory_enabled", False)
            st.metric("Memory Service", "✅ Active" if memory_enabled else "❌ Inactive")
        
        with col4:
            timestamp = health_data.get("timestamp", "Unknown")
            st.metric("Last Updated", timestamp.split("T")[0] if "T" in timestamp else timestamp)
    
    def render_agent_status(self):
        """Render agent status section."""
        st.header("🤖 Agent Status")
        
        health_data = self.get_agent_health(self.selected_env)
        agents = health_data.get("agents", [])
        
        if not agents:
            st.warning("No agent data available")
            return
        
        # Create agent status table
        agent_df = pd.DataFrame(agents)
        
        # Add status indicators
        agent_df["Status"] = "🟢 Active"  # All loaded agents are considered active
        agent_df["Last Seen"] = datetime.now().strftime("%H:%M:%S")
        
        st.dataframe(
            agent_df[["name", "description", "Status", "Last Seen"]],
            use_container_width=True,
            hide_index=True
        )
    
    def render_performance_metrics(self):
        """Render performance metrics section."""
        st.header("📈 Performance Metrics")
        
        # Load performance baselines if available
        try:
            baseline_path = "tests/validation/performance_baselines.json"
            if os.path.exists(baseline_path):
                with open(baseline_path, 'r') as f:
                    baselines = json.load(f)
                
                # Extract metrics for visualization
                metrics_data = []
                for key, baseline in baselines.get("baselines", {}).items():
                    metrics_data.append({
                        "Metric": baseline.get("metric_name", key),
                        "Value": baseline.get("baseline_value", 0),
                        "Unit": baseline.get("unit", ""),
                        "Category": baseline.get("benchmark_name", "unknown")
                    })
                
                if metrics_data:
                    df = pd.DataFrame(metrics_data)
                    
                    # Group by category
                    categories = df["Category"].unique()
                    
                    for category in categories:
                        st.subheader(f"{category.title()} Metrics")
                        category_df = df[df["Category"] == category]
                        
                        # Create metrics display
                        cols = st.columns(min(len(category_df), 4))
                        for idx, (_, row) in enumerate(category_df.iterrows()):
                            with cols[idx % 4]:
                                value = row["Value"]
                                unit = row["Unit"]
                                
                                # Format value based on unit
                                if unit == "seconds":
                                    display_value = f"{value:.3f}s"
                                elif unit == "percentage":
                                    display_value = f"{value:.1f}%"
                                elif unit == "MB":
                                    display_value = f"{value:.1f}MB"
                                else:
                                    display_value = f"{value:.2f}"
                                
                                st.metric(row["Metric"].replace("_", " ").title(), display_value)
                
            else:
                st.info("No performance baseline data available. Run performance tests to generate metrics.")
                
        except Exception as e:
            st.error(f"Failed to load performance metrics: {e}")
    
    def render_memory_analytics(self):
        """Render memory service analytics."""
        st.header("🧠 Memory Analytics")
        
        try:
            # Try to get memory service info
            memory_service = get_adk_memory_service()
            service_info = memory_service.get_service_info()
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Memory Service Status")
                st.json(service_info)
            
            with col2:
                st.subheader("Memory Usage")
                # Placeholder for memory usage visualization
                st.info("Memory usage analytics coming soon")
                
        except Exception as e:
            st.error(f"Failed to load memory analytics: {e}")
    
    def render_logs_section(self):
        """Render logs and debugging section."""
        st.header("📋 System Logs")
        
        # Placeholder for log viewing
        st.info("Log viewing interface coming soon")
        
        # For now, show basic system info
        st.subheader("Environment Information")
        env_info = {
            "Python Version": sys.version.split()[0],
            "Environment": self.selected_env,
            "Base URL": self.environments[self.selected_env],
            "Dashboard Time": datetime.now().isoformat()
        }
        
        st.json(env_info)
    
    def render_sidebar(self):
        """Render sidebar with navigation and controls."""
        with st.sidebar:
            st.title("🔧 Dashboard Controls")
            
            # Quick actions
            st.subheader("Quick Actions")
            
            if st.button("🔄 Restart Services"):
                st.info("Service restart functionality coming soon")
            
            if st.button("🧹 Clear Cache"):
                st.cache_data.clear()
                st.success("Cache cleared!")
            
            if st.button("📊 Export Metrics"):
                st.info("Metrics export functionality coming soon")
            
            # Configuration
            st.subheader("Configuration")
            
            self.debug_mode = st.checkbox("Debug Mode", value=False)
            self.refresh_interval = st.slider("Refresh Interval (seconds)", 10, 300, 30)
            
            # System info
            st.subheader("System Information")
            st.caption(f"Dashboard Version: 1.0.0")
            st.caption(f"Python: {sys.version.split()[0]}")
            st.caption(f"Runtime: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    def run(self):
        """Main dashboard execution method."""
        self.render_header()
        self.render_sidebar()
        
        # Main content tabs
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📊 Overview", 
            "🤖 Agents", 
            "📈 Performance", 
            "🧠 Memory", 
            "📋 Logs"
        ])
        
        with tab1:
            self.render_system_overview()
        
        with tab2:
            self.render_agent_status()
        
        with tab3:
            self.render_performance_metrics()
        
        with tab4:
            self.render_memory_analytics()
        
        with tab5:
            self.render_logs_section()
        
        # Auto-refresh logic
        if self.auto_refresh:
            import time
            time.sleep(self.refresh_interval)
            st.rerun()


def main():
    """Main dashboard entry point."""
    dashboard = VANADashboard()
    dashboard.run()


if __name__ == "__main__":
    main()