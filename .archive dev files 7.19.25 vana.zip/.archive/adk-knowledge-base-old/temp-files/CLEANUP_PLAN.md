# ADK Knowledge Base Cleanup Plan

## Files to KEEP (Essential)
1. `index_manifest.json` - Current index tracking
2. `index_tracker.py` - Index management script
3. `check_adk_index.sh` - Quick status check
4. `COMPLETE_INDEX_REPORT.md` - Final comprehensive report

## Files to ARCHIVE (Temporary/Working files)
1. All intermediate .md files:
   - extraction-plan.md
   - adk-full-extraction-plan.md
   - crawl-summary.md
   - test-crawl-analysis.md
   - load_adk_to_chromadb.md
   - chromadb_index_tracker.md
   - SUMMARY.md
   - IMPLEMENTATION_SUMMARY.md
   - README.md (old version)

2. All temporary Python scripts:
   - load_to_chromadb.py
   - process_and_load_docs.py
   - process_new_docs.py
   - check_index_status.py

3. Temporary data files:
   - new_docs_batch.json
   - index_status_report.txt (old report)

4. Sample directories:
   - docs/ (sample extractions)
   - codelabs/
   - examples/