# ADK Knowledge Base for VANA Development

This directory contains Google ADK (Agent Development Kit) documentation to ground Claude Code in current ADK patterns and best practices.

## Setup Complete ✅

### What's Included

1. **Local Documentation Files**
   - `docs/adk-overview.md` - ADK framework overview
   - `docs/quickstart/quickstart.md` - Complete quickstart guide
   - `docs/development/agents-overview.md` - Agent types and patterns
   - `docs/development/tools-overview.md` - Tool creation and usage

2. **ChromaDB Integration**
   - Collection: `adk_knowledge_base`
   - Documents indexed for semantic search
   - Accessible via ChromaDB MCP in VS Code

## Usage

### Direct File Reading
```bash
# Read specific documentation
cat .development/adk-knowledge-base/docs/quickstart/quickstart.md
```

### ChromaDB Search (in VS Code Claude)
```python
# Search for ADK concepts
mcp__chroma-vana__chroma_query_documents(
    collection_name="adk_knowledge_base",
    query_texts=["How do I create an agent in ADK?"],
    n_results=3
)
```

## Key ADK Patterns for VANA

### 1. Agent Creation
```python
from google.adk.agents import LlmAgent

agent = LlmAgent(
    name="specialist",
    model="gemini-2.0-flash",
    instruction="Clear instructions here",
    tools=[tool1, tool2]
)
```

### 2. Tool Definition
```python
from google.adk.tools import FunctionTool

def my_tool(param: str) -> dict:
    """Clear docstring for LLM understanding."""
    return {"status": "success", "result": "data"}

tool = FunctionTool(func=my_tool)
```

### 3. Multi-Agent Systems
```python
orchestrator = LlmAgent(
    name="orchestrator",
    instruction="Coordinate between specialists",
    sub_agents=[specialist1, specialist2]
)
```

## Updating Documentation

To add more ADK documentation:

1. Extract with Firecrawl:
```python
mcp__firecrawl__firecrawl_scrape(
    url="https://google.github.io/adk-docs/new-page/",
    formats=["markdown"]
)
```

2. Save to appropriate directory
3. Add to ChromaDB collection

## Benefits

- **Grounded Knowledge**: Always reference current ADK patterns
- **Semantic Search**: Find relevant documentation quickly
- **VANA Alignment**: Examples show ADK-compliant implementations
- **Offline Access**: Documentation available without internet

## Next Steps

1. Extract more ADK documentation pages as needed
2. Add ADK sample repository examples
3. Create VANA-specific ADK pattern guide
4. Set up weekly documentation updates