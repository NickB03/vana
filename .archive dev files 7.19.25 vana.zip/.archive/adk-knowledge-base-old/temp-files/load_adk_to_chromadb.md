# Loading ADK Documentation into ChromaDB

## Overview
This document outlines how to load the complete ADK documentation into ChromaDB for semantic search.

## Process

### 1. Documentation Already Crawled
We've successfully crawled 66 pages of ADK documentation using Firecrawl:
- Job ID: 33d3b6d2-440c-462c-812b-0974ef8cd0b2
- Status: Completed
- Pages: 66 core documentation pages

### 2. Key Documentation Categories
- **Getting Started**: Overview, Quickstart, Installation
- **Agents**: LLM Agents, Workflow Agents, Custom Agents, Multi-agent Systems
- **Tools**: Function Tools, Built-in Tools, Third-party Tools, Authentication
- **Sessions**: Session Management, State, Memory
- **Deployment**: Cloud Run, GKE, Agent Engine
- **Advanced**: Callbacks, Runtime, Events, Artifacts
- **Tutorials**: Agent Team tutorial

### 3. Loading Process

#### Step 1: Create New Collection
```python
mcp__chroma-vana__chroma_create_collection(
    collection_name="adk_complete_docs",
    embedding_function_name="default"
)
```

#### Step 2: Process Documentation
For each documentation page:
1. Extract full content using Firecrawl
2. Chunk content (2000 tokens with 200 overlap)
3. Create metadata for each chunk
4. Add to ChromaDB

#### Step 3: Metadata Structure
```python
metadata = {
    "source": "url",
    "title": "page_title",
    "category": "agents|tools|deploy|etc",
    "subcategory": "llm-agents|workflow-agents|etc",
    "type": "adk_documentation",
    "chunk_index": 0,
    "total_chunks": 3,
    "has_code_examples": true,
    "last_updated": "2025-01-19"
}
```

## Usage Examples

### Search for Agent Creation
```python
mcp__chroma-vana__chroma_query_documents(
    collection_name="adk_complete_docs",
    query_texts=["How do I create an LLM agent in ADK?"],
    n_results=5
)
```

### Search for Tool Implementation
```python
mcp__chroma-vana__chroma_query_documents(
    collection_name="adk_complete_docs",
    query_texts=["How to create custom tools for agents?"],
    n_results=5,
    where={"category": "tools"}
)
```

### Search for Deployment Options
```python
mcp__chroma-vana__chroma_query_documents(
    collection_name="adk_complete_docs",
    query_texts=["Deploy ADK agent to production"],
    n_results=5,
    where={"category": "deploy"}
)
```

## Benefits
1. **Instant Access**: No internet required during development
2. **Semantic Search**: Find relevant docs based on meaning
3. **Filtered Search**: Search within specific categories
4. **Version Control**: Track documentation changes
5. **VANA Alignment**: Ensure ADK compliance

## Maintenance
- Weekly crawl for updates
- Diff detection for changes
- Incremental updates to ChromaDB