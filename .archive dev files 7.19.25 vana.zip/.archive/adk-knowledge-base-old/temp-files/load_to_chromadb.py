#!/usr/bin/env python3
"""
Load ADK documentation into ChromaDB for semantic search.
This creates a searchable knowledge base for Claude Code to reference.
"""

import os
import sys
from pathlib import Path
import chromadb
from chromadb.utils import embedding_functions

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent.parent))


def load_adk_to_chromadb():
    """Load ADK documentation into ChromaDB."""
    
    # Initialize ChromaDB client
    print("Initializing ChromaDB...")
    client = chromadb.PersistentClient(path=".chroma_db")
    
    # Create embedding function
    embedding_function = embedding_functions.DefaultEmbeddingFunction()
    
    # Create or get collection
    collection_name = "adk_knowledge_base"
    try:
        collection = client.create_collection(
            name=collection_name,
            embedding_function=embedding_function,
            metadata={"description": "Google ADK documentation for VANA development"}
        )
        print(f"Created new collection: {collection_name}")
    except:
        collection = client.get_collection(
            name=collection_name,
            embedding_function=embedding_function
        )
        print(f"Using existing collection: {collection_name}")
    
    # Load documents
    docs_path = Path(".development/adk-knowledge-base/docs")
    documents = []
    metadatas = []
    ids = []
    
    # Walk through all markdown files
    for md_file in docs_path.rglob("*.md"):
        relative_path = md_file.relative_to(docs_path)
        doc_id = str(relative_path).replace("/", "_").replace(".md", "")
        
        print(f"Loading: {relative_path}")
        
        with open(md_file, 'r') as f:
            content = f.read()
            
        # Extract title from first # header
        title = "Unknown"
        for line in content.split('\n'):
            if line.startswith('# '):
                title = line[2:].strip()
                break
        
        documents.append(content)
        metadatas.append({
            "source": str(relative_path),
            "title": title,
            "type": "adk_documentation"
        })
        ids.append(doc_id)
    
    # Add to ChromaDB
    if documents:
        print(f"\nAdding {len(documents)} documents to ChromaDB...")
        collection.add(
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )
        print("✅ ADK knowledge base loaded successfully!")
        
        # Test query
        print("\nTesting semantic search...")
        results = collection.query(
            query_texts=["How do I create an agent in ADK?"],
            n_results=3
        )
        
        print("\nTop 3 results for 'How do I create an agent in ADK?':")
        for i, (doc_id, metadata) in enumerate(zip(results['ids'][0], results['metadatas'][0])):
            print(f"{i+1}. {metadata['title']} ({metadata['source']})")
    else:
        print("No documents found to load.")


if __name__ == "__main__":
    load_adk_to_chromadb()