#!/usr/bin/env python3
"""
Check the status of the ADK knowledge base index in ChromaDB.
This script queries ChromaDB to show what documents are indexed.
"""

import json
from datetime import datetime
from typing import Dict, List, Set

def check_index_status():
    """Check what's currently indexed in ChromaDB."""
    
    print("ADK Knowledge Base Index Status")
    print("=" * 50)
    print()
    
    # This would normally connect to ChromaDB
    # For now, we'll use the manifest file
    
    try:
        with open("index_manifest.json", "r") as f:
            manifest = json.load(f)
    except FileNotFoundError:
        print("No index manifest found. Creating new one...")
        manifest = {
            "collection_name": "adk_complete_docs",
            "created_at": datetime.now().isoformat(),
            "indexed_urls": [],
            "pending_urls": []
        }
    
    print(f"Collection: {manifest['collection_name']}")
    print(f"Last Updated: {manifest.get('last_updated', 'Never')}")
    print(f"Total Pages Indexed: {len(manifest.get('indexed_urls', []))}")
    print(f"Total Documents: {manifest.get('total_documents', 0)}")
    print()
    
    print("Indexed Pages:")
    print("-" * 50)
    for idx, page in enumerate(manifest.get('indexed_urls', []), 1):
        print(f"{idx}. {page['title']}")
        print(f"   URL: {page['url']}")
        print(f"   Chunks: {page['chunks']}")
        print(f"   Indexed: {page.get('indexed_at', 'Unknown')}")
        if 'note' in page:
            print(f"   Note: {page['note']}")
        print()
    
    print("\nPending Pages:", len(manifest.get('pending_urls', [])))
    print("-" * 50)
    for idx, url in enumerate(manifest.get('pending_urls', [])[:10], 1):
        print(f"{idx}. {url}")
    
    if len(manifest.get('pending_urls', [])) > 10:
        print(f"... and {len(manifest['pending_urls']) - 10} more")
    
    print("\nStatistics:")
    print("-" * 50)
    stats = manifest.get('statistics', {})
    for category, count in stats.get('by_category', {}).items():
        print(f"{category}: {count} documents")

def update_manifest_from_chromadb():
    """
    Update the manifest by querying ChromaDB directly.
    This would use the ChromaDB MCP to get actual data.
    """
    
    # Example of how to track documents:
    # 1. Query all documents from ChromaDB
    # 2. Group by source URL
    # 3. Update manifest
    
    print("\nTo update from ChromaDB, use:")
    print("mcp__chroma-vana__chroma_get_documents(")
    print('    collection_name="adk_complete_docs",')
    print("    limit=1000")
    print(")")

def generate_index_report():
    """Generate a detailed report of the index status."""
    
    report = {
        "generated_at": datetime.now().isoformat(),
        "recommendations": [],
        "issues": []
    }
    
    # Check for issues
    with open("index_manifest.json", "r") as f:
        manifest = json.load(f)
    
    # Check for missing chunks
    for page in manifest.get('indexed_urls', []):
        if 'note' in page and 'missing' in page['note'].lower():
            report['issues'].append(f"Missing chunks for {page['title']}")
    
    # Check pending vs indexed ratio
    indexed = len(manifest.get('indexed_urls', []))
    pending = len(manifest.get('pending_urls', []))
    
    if pending > indexed:
        report['recommendations'].append(
            f"Consider indexing more pages: {pending} pending vs {indexed} indexed"
        )
    
    # Save report
    with open("index_status_report.json", "w") as f:
        json.dump(report, f, indent=2)
    
    print("\nReport generated: index_status_report.json")

if __name__ == "__main__":
    check_index_status()
    print()
    update_manifest_from_chromadb()
    print()
    generate_index_report()