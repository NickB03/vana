#!/usr/bin/env python3
"""
Process ADK documentation pages and load them into ChromaDB.
This script extracts key documentation pages and creates a searchable knowledge base.
"""

import os
import json
from typing import List, Dict, Any
import requests

# Core documentation URLs to process
DOCUMENTATION_URLS = [
    # Overview and Getting Started
    "https://google.github.io/adk-docs/",
    "https://google.github.io/adk-docs/get-started/",
    "https://google.github.io/adk-docs/get-started/quickstart/",
    "https://google.github.io/adk-docs/get-started/installation/",
    "https://google.github.io/adk-docs/get-started/about/",
    
    # Agents
    "https://google.github.io/adk-docs/agents/",
    "https://google.github.io/adk-docs/agents/llm-agents/",
    "https://google.github.io/adk-docs/agents/workflow-agents/",
    "https://google.github.io/adk-docs/agents/workflow-agents/sequential-agents/",
    "https://google.github.io/adk-docs/agents/workflow-agents/parallel-agents/",
    "https://google.github.io/adk-docs/agents/workflow-agents/loop-agents/",
    "https://google.github.io/adk-docs/agents/custom-agents/",
    "https://google.github.io/adk-docs/agents/multi-agents/",
    "https://google.github.io/adk-docs/agents/models/",
    
    # Tools
    "https://google.github.io/adk-docs/tools/",
    "https://google.github.io/adk-docs/tools/function-tools/",
    "https://google.github.io/adk-docs/tools/built-in-tools/",
    "https://google.github.io/adk-docs/tools/third-party-tools/",
    "https://google.github.io/adk-docs/tools/openapi-tools/",
    "https://google.github.io/adk-docs/tools/google-cloud-tools/",
    "https://google.github.io/adk-docs/tools/mcp-tools/",
    "https://google.github.io/adk-docs/tools/authentication/",
    
    # Sessions and State
    "https://google.github.io/adk-docs/sessions/",
    "https://google.github.io/adk-docs/sessions/session/",
    "https://google.github.io/adk-docs/sessions/state/",
    "https://google.github.io/adk-docs/sessions/memory/",
    
    # Deployment
    "https://google.github.io/adk-docs/deploy/",
    "https://google.github.io/adk-docs/deploy/cloud-run/",
    "https://google.github.io/adk-docs/deploy/gke/",
    "https://google.github.io/adk-docs/deploy/agent-engine/",
    
    # Advanced Topics
    "https://google.github.io/adk-docs/callbacks/",
    "https://google.github.io/adk-docs/callbacks/types-of-callbacks/",
    "https://google.github.io/adk-docs/callbacks/design-patterns-and-best-practices/",
    "https://google.github.io/adk-docs/runtime/",
    "https://google.github.io/adk-docs/runtime/runconfig/",
    "https://google.github.io/adk-docs/events/",
    "https://google.github.io/adk-docs/context/",
    "https://google.github.io/adk-docs/artifacts/",
    "https://google.github.io/adk-docs/evaluate/",
    "https://google.github.io/adk-docs/safety/",
    
    # Tutorials
    "https://google.github.io/adk-docs/tutorials/",
    "https://google.github.io/adk-docs/tutorials/agent-team/",
]

def extract_category(url: str) -> str:
    """Extract category from URL for metadata."""
    parts = url.replace("https://google.github.io/adk-docs/", "").strip("/").split("/")
    if not parts or parts[0] == "":
        return "overview"
    return parts[0]

def extract_subcategory(url: str) -> str:
    """Extract subcategory from URL for metadata."""
    parts = url.replace("https://google.github.io/adk-docs/", "").strip("/").split("/")
    if len(parts) > 1:
        return parts[1]
    return ""

def chunk_text(text: str, chunk_size: int = 2000, overlap: int = 200) -> List[str]:
    """Split text into chunks with overlap."""
    if len(text) <= chunk_size:
        return [text]
    
    chunks = []
    start = 0
    
    while start < len(text):
        # Find end position
        end = start + chunk_size
        
        # Try to break at paragraph
        if end < len(text):
            # Look for paragraph break
            paragraph_break = text.rfind("\n\n", start, end)
            if paragraph_break > start:
                end = paragraph_break
            else:
                # Look for sentence break
                sentence_break = text.rfind(". ", start, end)
                if sentence_break > start:
                    end = sentence_break + 1
        
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        
        # Move start position with overlap
        start = end - overlap if end < len(text) else end
    
    return chunks

def create_document_metadata(url: str, title: str, chunk_index: int, total_chunks: int) -> Dict[str, Any]:
    """Create metadata for a document chunk."""
    return {
        "source": url,
        "title": title,
        "category": extract_category(url),
        "subcategory": extract_subcategory(url),
        "type": "adk_documentation",
        "chunk_index": chunk_index,
        "total_chunks": total_chunks,
        "has_code_examples": "```" in title,  # Simple heuristic
        "last_updated": "2025-01-19"
    }

def main():
    print("ADK Documentation Processing Script")
    print("=" * 50)
    
    # Create documents directory if it doesn't exist
    docs_dir = "/Users/nick/Development/vana/.development/adk-knowledge-base/docs/processed"
    os.makedirs(docs_dir, exist_ok=True)
    
    # Process each documentation URL
    all_documents = []
    all_metadatas = []
    all_ids = []
    
    for i, url in enumerate(DOCUMENTATION_URLS):
        print(f"\nProcessing {i+1}/{len(DOCUMENTATION_URLS)}: {url}")
        
        # For this example, we'll use the already scraped content
        # In production, you would use Firecrawl API here
        
        # Extract page title from URL
        title = url.split("/")[-2].replace("-", " ").title() if url.endswith("/") else url.split("/")[-1].replace("-", " ").title()
        if not title:
            title = "ADK Overview"
        
        # Create mock content for demonstration
        # In production, this would be the actual scraped content
        content = f"# {title}\n\nContent for {url}\n\n[This would be the actual documentation content scraped from the page]"
        
        # Chunk the content
        chunks = chunk_text(content)
        
        # Process each chunk
        for chunk_idx, chunk in enumerate(chunks):
            doc_id = f"{url}#chunk{chunk_idx}"
            metadata = create_document_metadata(url, title, chunk_idx, len(chunks))
            
            all_documents.append(chunk)
            all_metadatas.append(metadata)
            all_ids.append(doc_id)
            
            # Save to file for reference
            safe_filename = url.replace("https://google.github.io/adk-docs/", "").replace("/", "_") or "index"
            with open(f"{docs_dir}/{safe_filename}_chunk{chunk_idx}.md", "w") as f:
                f.write(chunk)
    
    print(f"\n\nProcessed {len(DOCUMENTATION_URLS)} pages into {len(all_documents)} chunks")
    
    # Save summary
    summary = {
        "total_pages": len(DOCUMENTATION_URLS),
        "total_chunks": len(all_documents),
        "categories": list(set(m["category"] for m in all_metadatas)),
        "urls_processed": DOCUMENTATION_URLS
    }
    
    with open(f"{docs_dir}/../processing_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    
    print("\nProcessing complete!")
    print(f"Total documents ready for ChromaDB: {len(all_documents)}")
    print("\nTo load into ChromaDB, use the ChromaDB MCP with:")
    print("- Collection name: 'adk_complete_docs'")
    print(f"- Documents: {len(all_documents)} chunks")
    print(f"- IDs: {len(all_ids)} unique identifiers")

if __name__ == "__main__":
    main()