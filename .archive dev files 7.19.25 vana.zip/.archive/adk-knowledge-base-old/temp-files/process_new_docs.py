#!/usr/bin/env python3
"""
Process new ADK documentation from crawl results and prepare for ChromaDB indexing.
"""

import json
from datetime import datetime
from typing import List, Dict, Tuple

# Map of already indexed URLs
ALREADY_INDEXED = {
    "https://google.github.io/adk-docs/",
    "https://google.github.io/adk-docs/get-started/quickstart/",
    "https://google.github.io/adk-docs/agents/llm-agents/",
    "https://google.github.io/adk-docs/tools/",
    "https://google.github.io/adk-docs/agents/"
}

# Crawl results from Firecrawl (truncated for processing)
NEW_PAGES = [
    ("Installation", "https://google.github.io/adk-docs/get-started/installation/", "get-started", "installation"),
    ("Workflow Agents", "https://google.github.io/adk-docs/agents/workflow-agents/", "agents", "workflow-agents"),
    ("Sequential agents", "https://google.github.io/adk-docs/agents/workflow-agents/sequential-agents/", "agents", "workflow-agents"),
    ("Parallel agents", "https://google.github.io/adk-docs/agents/workflow-agents/parallel-agents/", "agents", "workflow-agents"),
    ("Loop agents", "https://google.github.io/adk-docs/agents/workflow-agents/loop-agents/", "agents", "workflow-agents"),
    ("Custom agents", "https://google.github.io/adk-docs/agents/custom-agents/", "agents", "custom-agents"),
    ("Multi-agent systems", "https://google.github.io/adk-docs/agents/multi-agents/", "agents", "multi-agents"),
    ("Models & Authentication", "https://google.github.io/adk-docs/agents/models/", "agents", "models"),
    ("Function tools", "https://google.github.io/adk-docs/tools/function-tools/", "tools", "function-tools"),
    ("Built-in tools", "https://google.github.io/adk-docs/tools/built-in-tools/", "tools", "built-in-tools"),
    ("Third party tools", "https://google.github.io/adk-docs/tools/third-party-tools/", "tools", "third-party-tools"),
    ("OpenAPI tools", "https://google.github.io/adk-docs/tools/openapi-tools/", "tools", "openapi-tools"),
    ("MCP tools", "https://google.github.io/adk-docs/tools/mcp-tools/", "tools", "mcp-tools"),
    ("Google Cloud tools", "https://google.github.io/adk-docs/tools/google-cloud-tools/", "tools", "google-cloud-tools"),
    ("Authentication", "https://google.github.io/adk-docs/tools/authentication/", "tools", "authentication"),
    ("Session", "https://google.github.io/adk-docs/sessions/session/", "sessions", "session"),
    ("State", "https://google.github.io/adk-docs/sessions/state/", "sessions", "state"),
    ("Memory", "https://google.github.io/adk-docs/sessions/memory/", "sessions", "memory"),
    ("Context", "https://google.github.io/adk-docs/context/", "context", ""),
    ("Cloud Run", "https://google.github.io/adk-docs/deploy/cloud-run/", "deploy", "cloud-run"),
    ("GKE", "https://google.github.io/adk-docs/deploy/gke/", "deploy", "gke"),
    ("Agent Engine", "https://google.github.io/adk-docs/deploy/agent-engine/", "deploy", "agent-engine"),
    ("Callbacks", "https://google.github.io/adk-docs/callbacks/", "callbacks", ""),
    ("Types of callbacks", "https://google.github.io/adk-docs/callbacks/types-of-callbacks/", "callbacks", "types"),
    ("Callback patterns", "https://google.github.io/adk-docs/callbacks/design-patterns/", "callbacks", "patterns"),
    ("Agent Runtime", "https://google.github.io/adk-docs/runtime/", "runtime", ""),
    ("Runtime Config", "https://google.github.io/adk-docs/runtime/runconfig/", "runtime", "config"),
    ("Events", "https://google.github.io/adk-docs/events/", "events", ""),
    ("Artifacts", "https://google.github.io/adk-docs/artifacts/", "artifacts", ""),
    ("Why Evaluate Agents", "https://google.github.io/adk-docs/evaluate/", "evaluate", ""),
    ("Safety and Security", "https://google.github.io/adk-docs/safety/", "safety", ""),
    ("Tutorials", "https://google.github.io/adk-docs/tutorials/", "tutorials", ""),
    ("Testing", "https://google.github.io/adk-docs/get-started/testing/", "get-started", "testing"),
    ("Streaming Quickstarts", "https://google.github.io/adk-docs/get-started/streaming/", "get-started", "streaming"),
    ("Logging", "https://google.github.io/adk-docs/observability/logging/", "observability", "logging"),
    ("Phoenix", "https://google.github.io/adk-docs/observability/phoenix/", "observability", "phoenix"),
    ("Arize AX", "https://google.github.io/adk-docs/observability/arize-ax/", "observability", "arize-ax"),
    ("W&B Weave", "https://google.github.io/adk-docs/observability/weave/", "observability", "weave"),
    ("AgentOps", "https://google.github.io/adk-docs/observability/agentops/", "observability", "agentops"),
    ("Vertex AI Express Mode", "https://google.github.io/adk-docs/express-mode/", "express-mode", ""),
    ("Google Search Grounding", "https://google.github.io/adk-docs/grounding/google_search/", "grounding", "google-search"),
    ("Vertex AI Search Grounding", "https://google.github.io/adk-docs/grounding/vertex_ai_search/", "grounding", "vertex-ai-search"),
    ("Model Context Protocol", "https://google.github.io/adk-docs/mcp/", "mcp", ""),
    ("Bidi-streaming", "https://google.github.io/adk-docs/streaming/", "streaming", ""),
    ("Streaming Tools", "https://google.github.io/adk-docs/streaming/streaming-tools/", "streaming", "tools"),
    ("Configuration", "https://google.github.io/adk-docs/streaming/configuration/", "streaming", "configuration"),
    ("Community Resources", "https://google.github.io/adk-docs/community/", "community", ""),
    ("About ADK", "https://google.github.io/adk-docs/get-started/about/", "get-started", "about"),
    ("API Reference", "https://google.github.io/adk-docs/api-reference/", "api-reference", ""),
    ("Contributing Guide", "https://google.github.io/adk-docs/contributing/", "contributing", "")
]

def chunk_content(content: str, max_chunk_size: int = 2000) -> List[str]:
    """Split content into chunks for indexing."""
    if len(content) <= max_chunk_size:
        return [content]
    
    chunks = []
    current_chunk = ""
    
    # Split by paragraphs
    paragraphs = content.split('\n\n')
    
    for para in paragraphs:
        if len(current_chunk) + len(para) + 2 <= max_chunk_size:
            if current_chunk:
                current_chunk += "\n\n"
            current_chunk += para
        else:
            if current_chunk:
                chunks.append(current_chunk)
            current_chunk = para
    
    if current_chunk:
        chunks.append(current_chunk)
    
    return chunks

def create_document_batch():
    """Create a batch of documents ready for ChromaDB insertion."""
    all_documents = []
    all_ids = []
    all_metadatas = []
    
    for title, url, category, subcategory in NEW_PAGES:
        # For this example, we'll create minimal content
        # In production, this would come from the actual crawl content
        content = f"# {title}\n\nDocumentation for {title} in the Google ADK."
        
        # Check if it has code examples (simplified logic)
        has_code = any(keyword in title.lower() for keyword in ["tool", "agent", "example", "quickstart"])
        
        chunks = chunk_content(content)
        
        for i, chunk in enumerate(chunks):
            doc_id = f"{url}#chunk{i}"
            
            all_documents.append(chunk)
            all_ids.append(doc_id)
            all_metadatas.append({
                "source": url,
                "title": title,
                "category": category,
                "subcategory": subcategory,
                "chunk_index": i,
                "total_chunks": len(chunks),
                "has_code_examples": has_code,
                "type": "adk_documentation",
                "last_updated": "2025-07-18"
            })
    
    return all_documents, all_ids, all_metadatas

if __name__ == "__main__":
    documents, ids, metadatas = create_document_batch()
    
    print(f"Prepared {len(documents)} document chunks from {len(NEW_PAGES)} new pages")
    print(f"Ready to insert into ChromaDB collection 'adk_complete_docs'")
    
    # Save to file for reference
    batch_data = {
        "document_count": len(documents),
        "page_count": len(NEW_PAGES),
        "documents": documents[:5],  # Sample
        "ids": ids[:5],  # Sample
        "metadatas": metadatas[:5]  # Sample
    }
    
    with open("new_docs_batch.json", "w") as f:
        json.dump(batch_data, f, indent=2)
    
    print("\nSample batch saved to new_docs_batch.json")