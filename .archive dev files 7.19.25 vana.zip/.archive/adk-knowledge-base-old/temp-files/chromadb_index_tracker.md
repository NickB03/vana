# ChromaDB Index Tracking System

## Overview
This document explains how to track what files are indexed in the ADK ChromaDB collection.

## Tracking Methods

### 1. Index Manifest File
**File**: `index_manifest.json`
- Tracks all indexed URLs and their document IDs
- Records indexing timestamps
- Lists pending URLs to be indexed
- Provides statistics by category

### 2. Query ChromaDB Directly

#### Get All Documents
```python
# Get all documents in the collection
mcp__chroma-vana__chroma_get_documents(
    collection_name="adk_complete_docs",
    limit=1000,  # Adjust based on expected size
    include=["documents", "metadatas"]
)
```

#### Get Document Count
```python
# Quick count check
mcp__chroma-vana__chroma_get_collection_count(
    collection_name="adk_complete_docs"
)
```

#### Get Collection Info
```python
# Get metadata about the collection
mcp__chroma-vana__chroma_get_collection_info(
    collection_name="adk_complete_docs"
)
```

### 3. Search by Category
```python
# Find all documents in a specific category
mcp__chroma-vana__chroma_get_documents(
    collection_name="adk_complete_docs",
    where={"category": "agents"},
    limit=100
)
```

### 4. Check Specific URL
```python
# Check if a specific URL is indexed
mcp__chroma-vana__chroma_get_documents(
    collection_name="adk_complete_docs",
    where={"source": "https://google.github.io/adk-docs/agents/"},
    limit=10
)
```

## Maintenance Commands

### List All Unique Sources
```python
# This would require processing results to extract unique sources
results = mcp__chroma-vana__chroma_get_documents(
    collection_name="adk_complete_docs",
    limit=1000,
    include=["metadatas"]
)
# Then extract unique sources from metadatas
```

### Check for Duplicates
```python
# Look for documents with same source and chunk_index
mcp__chroma-vana__chroma_get_documents(
    collection_name="adk_complete_docs",
    where={
        "$and": [
            {"source": "https://google.github.io/adk-docs/agents/"},
            {"chunk_index": 0}
        ]
    }
)
```

## Update Process

### Adding New Documents
1. Check if URL already indexed
2. Scrape content with Firecrawl
3. Chunk the content
4. Add to ChromaDB with proper IDs
5. Update index_manifest.json

### Removing Documents
```python
# Remove by IDs
mcp__chroma-vana__chroma_delete_documents(
    collection_name="adk_complete_docs",
    ids=["doc_id_1", "doc_id_2"]
)
```

### Updating Documents
```python
# Update existing documents
mcp__chroma-vana__chroma_update_documents(
    collection_name="adk_complete_docs",
    ids=["doc_id"],
    documents=["Updated content"],
    metadatas=[{"last_updated": "2025-01-20"}]
)
```

## Best Practices

1. **Consistent ID Format**: Use URL#chunkN format for document IDs
2. **Metadata Standards**: Always include source, category, chunk_index
3. **Regular Audits**: Run check_index_status.py weekly
4. **Version Tracking**: Add version field to metadata for updates
5. **Backup Manifest**: Keep index_manifest.json in version control

## Quick Status Check
```bash
# Run the status check script
python check_index_status.py
```

This will show:
- Total indexed pages
- Documents per category
- Pending URLs
- Any identified issues