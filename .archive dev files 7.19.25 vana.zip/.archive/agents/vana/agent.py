from .team import root_agent

agent = root_agent
