"""Memory module stub for testing."""
