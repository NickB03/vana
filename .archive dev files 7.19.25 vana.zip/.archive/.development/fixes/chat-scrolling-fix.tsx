// CRITICAL FIX: Chat Scrolling Issue
// File: src/pages/Chat.tsx

// PROBLEM: Line 144 has overflow-hidden preventing scroll
// OLD CODE:
// <div className="h-screen bg-[var(--bg-main)] flex w-full relative overflow-hidden">

// FIXED CODE:
// Replace line 144 with:
<div className="h-screen bg-[var(--bg-main)] flex w-full relative">

// Additional recommended changes for better layout management:

// 1. Update the main content wrapper (around line 163):
<div className="flex-1 flex flex-col min-h-0">

// 2. Update the chat messages container (around line 261-263):
<main className="flex-1 flex flex-col w-full overflow-hidden">
  {/* Chat Messages Area */}
  <div className="flex-1 overflow-y-auto px-4 py-4">
    <div className="max-w-4xl mx-auto w-full">
      {/* Messages content */}
    </div>
  </div>

  {/* Input Area - Fixed at bottom */}
  <div className="flex-shrink-0 bg-[var(--bg-main)] p-4">
    <div className="max-w-4xl mx-auto w-full">
      {/* Input form */}
    </div>
  </div>
</main>

// 3. For mobile responsiveness, add viewport handling:
// In the component, add:
React.useEffect(() => {
  // Handle mobile viewport resize when keyboard appears
  const handleResize = () => {
    const vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);
  };
  
  handleResize();
  window.addEventListener('resize', handleResize);
  return () => window.removeEventListener('resize', handleResize);
}, []);

// Then use CSS custom property:
// Replace h-screen with:
style={{ height: 'calc(var(--vh, 1vh) * 100)' }}

// 4. Ensure messages container scrolls to bottom on new messages:
const messagesEndRef = React.useRef<HTMLDivElement>(null);

React.useEffect(() => {
  messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
}, [currentMessages]);

// Add this after the messages map:
<div ref={messagesEndRef} />