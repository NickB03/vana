# Directory Navigation Issues Analysis - VANA Project

## Executive Summary

The VANA project experiences recurring directory navigation issues where commands are executed from the `vana-ui` subdirectory instead of the project root, causing deployment failures and incorrect file counts. This analysis identifies the root causes and provides comprehensive recommendations.

## Key Findings

### 1. File Count Discrepancy
- **From project root**: ~561 source files (excluding node_modules, venv)
- **From vana-ui**: ~85 source files
- **Google Cloud deployment**: Reports different counts based on working directory
  - Root directory: 795+ files (includes all project files)
  - vana-ui directory: 102 files (only frontend files)

### 2. Build Detection Issues
- **From project root**: Detects `Dockerfile.prod` → Uses Docker build
- **From vana-ui**: No Dockerfile → Falls back to Buildpacks
- **Impact**: Wrong build process leads to deployment failures

### 3. Directory Navigation Patterns

#### Scripts That Change Directory
Multiple scripts explicitly change to `vana-ui`:
```bash
# start-vana-ui.sh
cd vana-ui  # Line 113

# scripts/quick_deploy_local.sh
cd vana-ui  # Line 70

# Makefile
cd vana-ui && npm install  # Line 40
```

#### Scripts Using Subshells (Safer)
```bash
# start-vana-ui.sh
(cd vana-ui && npm install)  # Line 71 - Better practice

# scripts/start-dev.sh
(cd vana-ui && npm install)  # Line 125
```

### 4. Common Problem Scenarios

#### Scenario 1: Frontend Script Execution
```bash
# User runs frontend script
./start-vana-ui.sh
# Script changes to vana-ui directory
cd vana-ui
# Script ends or errors, leaving terminal in vana-ui
# Next command (e.g., gcloud deploy) runs from wrong directory
```

#### Scenario 2: Manual Navigation
```bash
# Developer navigates to check frontend
cd vana-ui
# Forgets to return to root
# Runs deployment command
gcloud run deploy --source .  # Deploys only frontend!
```

#### Scenario 3: Error Recovery
```bash
# Command fails in vana-ui
npm run dev  # Error
# Developer troubleshoots, stays in vana-ui
# Tries to deploy
./deploy-staging.sh  # Fails: script not found or wrong context
```

## Root Causes

### 1. Script Design Issues
- Scripts use `cd` without returning to original directory
- No consistent use of `pushd`/`popd` or subshells
- Missing directory validation before critical operations

### 2. Deployment Script Assumptions
- Deployment scripts assume execution from project root
- No validation of current working directory
- `--source .` uses current directory without checks

### 3. Project Structure Confusion
- `vana-ui` is both a subdirectory and a valid project
- Has its own `package.json`, making it seem like a standalone project
- No clear indicators when in wrong directory

### 4. Terminal State Persistence
- Scripts change directory but don't restore on exit
- Error conditions leave terminal in unexpected state
- No visual cues about current project context

## Impact Analysis

### Deployment Failures
1. **Wrong source files**: Only 102 files instead of 795+
2. **Missing backend**: No Python files included
3. **Build process**: Buildpacks instead of Dockerfile
4. **Configuration**: Missing environment setup

### Development Confusion
1. **Commands not found**: Scripts exist in parent directory
2. **Configuration missing**: `.env` files in wrong location
3. **Git operations**: May affect wrong repository level
4. **Testing**: Running wrong test suites

## Recommendations

### 1. Immediate Fixes

#### A. Add Directory Validation to All Deployment Scripts
```bash
#!/bin/bash
# Add to beginning of all deployment scripts

# Ensure we're in project root
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

# Validate we're in the right place
if [ ! -f "main.py" ] || [ ! -d "vana-ui" ]; then
    echo "❌ ERROR: Must run from project root directory"
    echo "   Current directory: $(pwd)"
    echo "   Expected files: main.py, vana-ui/"
    exit 1
fi
```

#### B. Update Scripts to Use Subshells
```bash
# Instead of:
cd vana-ui
npm install

# Use:
(cd vana-ui && npm install)
# or
pushd vana-ui > /dev/null
npm install
popd > /dev/null
```

#### C. Add Visual Indicators
```bash
# Add to .bashrc or .zshrc
function prompt_command {
    if [[ "$PWD" == *"/vana-ui" ]]; then
        echo -e "\033[33m⚠️  WARNING: You are in vana-ui subdirectory\033[0m"
    fi
}
PROMPT_COMMAND=prompt_command
```

### 2. Script Improvements

#### Create a Directory-Safe Wrapper
```bash
#!/bin/bash
# scripts/safe-deploy.sh

# Always ensure correct directory
cd "$(dirname "$0")/.."

# Validate environment
if [ ! -f "Dockerfile.prod" ]; then
    echo "❌ ERROR: Dockerfile.prod not found"
    echo "   This suggests you're in the wrong directory"
    echo "   Current: $(pwd)"
    exit 1
fi

# Count files for verification
FILE_COUNT=$(find . -type f -name "*.py" -o -name "*.ts" -o -name "*.tsx" | grep -v node_modules | grep -v venv | wc -l)
echo "📊 Found $FILE_COUNT source files"

if [ "$FILE_COUNT" -lt 500 ]; then
    echo "⚠️  WARNING: Fewer files than expected"
    echo "   Expected: 500+ files"
    echo "   Found: $FILE_COUNT files"
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Execute actual deployment
exec "$@"
```

### 3. Long-term Solutions

#### A. Project Structure Markers
Create `.vana-root` file in project root:
```bash
# .vana-root
PROJECT_NAME=vana
PROJECT_TYPE=fullstack
REQUIRED_DIRS=vana-ui,agents,lib
```

#### B. Unified Entry Point
Create a master control script:
```bash
#!/bin/bash
# vana.sh - Master control script

VANA_ROOT="$(cd "$(dirname "$0")" && pwd)"
export VANA_ROOT

case "$1" in
    deploy)
        cd "$VANA_ROOT" && ./deploy-staging.sh
        ;;
    dev)
        cd "$VANA_ROOT" && make dev
        ;;
    frontend)
        cd "$VANA_ROOT" && (cd vana-ui && npm run dev)
        ;;
    *)
        echo "Usage: vana.sh {deploy|dev|frontend}"
        ;;
esac
```

#### C. Git Hooks
Add pre-commit hook to check directory:
```bash
#!/bin/bash
# .git/hooks/pre-commit

if [[ "$PWD" == *"/vana-ui" ]]; then
    echo "❌ ERROR: Cannot commit from vana-ui subdirectory"
    echo "   Please cd to project root first"
    exit 1
fi
```

### 4. Documentation Updates

#### Add to README.md
```markdown
## ⚠️ Important: Directory Context

Always ensure you're in the project root directory before running commands:

```bash
# Check current directory
pwd  # Should show: /path/to/vana (NOT /path/to/vana/vana-ui)

# If in wrong directory:
cd ..  # or cd /path/to/vana
```

**Common Issues**:
- If deployment shows "102 files", you're in `vana-ui/`
- If deployment uses Buildpacks, you're in wrong directory
- If scripts are "not found", check your directory
```

### 5. Monitoring and Alerts

#### Add Deployment Validation
```bash
# In deployment scripts
echo "🔍 Pre-deployment validation..."
echo "   Directory: $(pwd)"
echo "   Files: $(find . -type f | wc -l)"
echo "   Dockerfile: $([ -f Dockerfile.prod ] && echo "✓" || echo "✗")"
echo "   Backend: $([ -f main.py ] && echo "✓" || echo "✗")"
echo "   Frontend: $([ -d vana-ui ] && echo "✓" || echo "✗")"
```

## Conclusion

The directory navigation issues stem from a combination of script design, project structure, and missing safeguards. Implementing these recommendations will:

1. Prevent accidental deployments from wrong directories
2. Provide clear feedback about current context
3. Automate directory management in scripts
4. Create fail-safes for common error scenarios

The most critical immediate action is adding directory validation to all deployment scripts and converting all `cd` commands to use subshells or pushd/popd pairs.