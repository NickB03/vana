# VANA Agent Expansion: Phased Implementation Plan
## Complete Roadmap with Integrated Testing

**Version**: 1.0  
**Date**: July 11, 2025  
**Duration**: 10 weeks (Phase 2-4 implementation)

---

## Executive Overview

This plan details the sequential implementation of VANA's agent expansion, incorporating:
- ADK best practices and patterns
- Industry learnings on agent autonomy and tool organization
- Comprehensive testing at each phase
- Clear success metrics and validation criteria

### Implementation Philosophy
- **Sequential Execution**: Each phase builds on previous work
- **Test-Driven Development**: Write tests before implementation
- **Incremental Validation**: Verify each component before proceeding
- **ADK Compliance**: Maintain Google ADK patterns throughout

---

## Phase 2: Enhanced Tool Distribution & Core Improvements
### Duration: 2 weeks (Weeks 3-4)

### Week 3: Tool Categorization & Security Elevation

#### Day 1-2: Tool Registry Implementation

**Tasks:**
```python
# 1. Create tool categorization framework
# Location: lib/_tools/registry.py
class ToolCategory(Enum):
    ANALYSIS = "analysis"      # Information processing
    EXECUTION = "execution"    # Direct actions
    INTEGRATION = "integration" # External connections
    UTILITY = "utility"        # Support functions

class ToolRegistry:
    """Central registry for tool management"""
    
    def __init__(self):
        self.tools = {}
        self.categories = defaultdict(list)
        
    def register_tool(self, tool: FunctionTool, category: ToolCategory):
        """Register tool with category"""
        self.tools[tool.name] = {
            "tool": tool,
            "category": category,
            "usage_count": 0
        }
        self.categories[category].append(tool)
```

**Testing:**
```python
# Location: tests/unit/test_tool_registry.py
@pytest.mark.unit
class TestToolRegistry:
    def test_tool_registration(self):
        registry = ToolRegistry()
        tool = FunctionTool(lambda x: x, name="test_tool")
        registry.register_tool(tool, ToolCategory.UTILITY)
        
        assert "test_tool" in registry.tools
        assert tool in registry.categories[ToolCategory.UTILITY]
    
    def test_category_assignment(self):
        registry = ToolRegistry()
        # Test each category gets appropriate tools
        analysis_tools = registry.get_tools_for_category(ToolCategory.ANALYSIS)
        assert all(t.name.contains("analyze") for t in analysis_tools)
```

#### Day 3-4: Security Specialist Implementation

**Tasks:**
```python
# Location: agents/specialists/security_specialist.py
from google.adk.agents import LlmAgent
from lib._tools.security import *

security_specialist = LlmAgent(
    name="security_specialist",
    model="gemini-2.0-flash",
    description="Expert in code security and vulnerability analysis",
    instruction="""
    You are VANA's security specialist. Your responsibilities:
    1. Proactively analyze code for vulnerabilities
    2. Suggest security improvements
    3. Validate inputs and configurations
    4. Report security findings clearly
    
    Work autonomously within your domain. Use tools proactively.
    """,
    tools=[
        # Analysis Tools (primary)
        FunctionTool(analyze_code_security),
        FunctionTool(scan_vulnerabilities),
        # Execution Tools
        FunctionTool(generate_security_report),
        # Integration Tools
        adk_search_security_db,
        # Utility Tools
        FunctionTool(validate_inputs),
        FunctionTool(sanitize_data),
    ]  # 6 tools max
)
```

**Integration Testing:**
```python
# Location: tests/integration/test_security_specialist.py
@pytest.mark.integration
@pytest.mark.asyncio
async def test_security_routing():
    """Test security tasks route to security specialist"""
    
    # Create test context
    task = "Scan this code for SQL injection vulnerabilities"
    
    # Test routing
    routing_result = await orchestrator.analyze_task(task)
    assert routing_result.specialist == "security_specialist"
    assert routing_result.complexity == "SIMPLE"
    
    # Test execution
    result = await security_specialist.run_async(task)
    assert result.success
    assert "vulnerability" in result.content.lower()
```

#### Day 5: Enhanced Complexity Analysis

**Tasks:**
```python
# Location: agents/orchestration/enhanced_complexity.py
def analyze_task_complexity_enhanced(task: str) -> ComplexityResult:
    """Enhanced complexity analysis with domain factors"""
    
    # Base complexity factors
    base_factors = {
        "task_count": estimate_subtasks(task),
        "coordination_needed": requires_multiple_agents(task),
        "data_volume": estimate_data_size(task)
    }
    
    # Domain-aware factors (NEW)
    domain_factors = {
        'security_critical': detect_security_keywords(task),
        'compliance_required': detect_regulatory_terms(task),
        'data_sensitive': detect_data_privacy_concerns(task),
        'time_critical': detect_urgency_indicators(task),
        'multi_domain': detect_cross_domain_requirements(task)
    }
    
    # Calculate complexity
    complexity_score = calculate_weighted_score(base_factors, domain_factors)
    complexity_level = map_score_to_level(complexity_score)
    
    # Adjust for critical factors
    if any([domain_factors['security_critical'], 
            domain_factors['compliance_required']]):
        complexity_level = max(complexity_level, ComplexityLevel.MODERATE)
    
    return ComplexityResult(
        level=complexity_level,
        base_factors=base_factors,
        domain_factors=domain_factors,
        routing_hints=generate_routing_hints(domain_factors),
        confidence=calculate_confidence(base_factors, domain_factors)
    )
```

**Testing:**
```python
# Location: tests/unit/test_complexity_analysis.py
@pytest.mark.unit
def test_security_factor_detection():
    """Test security-critical task detection"""
    
    security_tasks = [
        "Find vulnerabilities in this code",
        "Check for SQL injection",
        "Validate authentication flow"
    ]
    
    for task in security_tasks:
        result = analyze_task_complexity_enhanced(task)
        assert result.domain_factors['security_critical'] == True
        assert result.level >= ComplexityLevel.MODERATE
```

### Week 3 Validation & Testing

**End-to-End Test Suite:**
```python
# Location: tests/e2e/test_phase2_week3.py
@pytest.mark.e2e
@pytest.mark.asyncio
class TestPhase2Week3:
    """Comprehensive tests for Week 3 deliverables"""
    
    async def test_tool_registry_integration(self):
        """Test complete tool registry flow"""
        # 1. Register all tools
        registry = await initialize_tool_registry()
        
        # 2. Verify categorization
        for category in ToolCategory:
            tools = registry.get_tools_for_category(category)
            assert len(tools) > 0
            assert all(t.category == category for t in tools)
        
        # 3. Test assignment to agents
        security_tools = registry.assign_tools_to_agent("security_specialist")
        assert len(security_tools) <= 6  # ADK limit
        assert any(t.category == ToolCategory.ANALYSIS for t in security_tools)
    
    async def test_security_specialist_complete(self):
        """Test security specialist end-to-end"""
        # Test various security scenarios
        test_cases = [
            ("SQL injection in login.py", "vulnerability", "high"),
            ("Review authentication flow", "security", "moderate"),
            ("Check OWASP compliance", "compliance", "high")
        ]
        
        for task, expected_keyword, expected_priority in test_cases:
            result = await vana_chat.process(task)
            assert expected_keyword in result.lower()
            assert result.metadata['priority'] == expected_priority
```

### Week 4: Tool Redistribution & Integration

#### Day 1-2: Strip Tools from VANA

**Tasks:**
```python
# Location: agents/vana/team_agentic_v2.py
# Refactor VANA Chat to minimal tool set
vana_chat_agent = LlmAgent(
    name="VANA_Chat",
    model="gemini-2.0-flash",
    instruction="""
    You are VANA's conversational interface. Your role:
    1. Understand user intent
    2. Delegate to the Master Orchestrator for all technical tasks
    3. Present results naturally
    
    You have minimal tools - rely on specialists via the orchestrator.
    """,
    tools=[
        adk_transfer_to_agent,      # Delegate to orchestrator
        adk_get_session_context,    # Access context
        FunctionTool(format_response) # Format output
    ]  # Only 3 tools
)
```

#### Day 3-4: Redistribute Tools to Specialists

**Tasks:**
```python
# Location: scripts/redistribute_tools.py
def redistribute_tools_to_specialists():
    """Redistribute tools from VANA to appropriate specialists"""
    
    tool_assignments = {
        "architecture_specialist": {
            "category_focus": [ToolCategory.ANALYSIS],
            "specific_tools": [
                "analyze_system_architecture",
                "evaluate_design_patterns",
                "generate_architecture_diagram"
            ]
        },
        "data_science_specialist": {
            "category_focus": [ToolCategory.ANALYSIS, ToolCategory.EXECUTION],
            "specific_tools": [
                "pandas_operations",
                "plot_data",
                "run_statistical_analysis"
            ]
        },
        "devops_specialist": {
            "category_focus": [ToolCategory.EXECUTION, ToolCategory.INTEGRATION],
            "specific_tools": [
                "deploy_application",
                "manage_infrastructure",
                "monitor_services"
            ]
        }
    }
    
    for agent_name, config in tool_assignments.items():
        agent = get_agent(agent_name)
        tools = ToolRegistry.get_tools_for_agent(agent_name, config)
        agent.update_tools(tools)
        print(f"Updated {agent_name} with {len(tools)} tools")
```

**Testing:**
```python
# Location: tests/integration/test_tool_redistribution.py
@pytest.mark.integration
async def test_tool_access_after_redistribution():
    """Verify specialists have correct tools after redistribution"""
    
    # Test VANA has minimal tools
    vana_tools = vana_chat_agent.tools
    assert len(vana_tools) == 3
    assert not any("file" in t.name for t in vana_tools)
    
    # Test specialists have appropriate tools
    specialists = [
        architecture_specialist,
        data_science_specialist,
        devops_specialist,
        security_specialist
    ]
    
    for specialist in specialists:
        tools = specialist.tools
        assert 4 <= len(tools) <= 6  # ADK recommended range
        
        # Verify category alignment
        categories = [ToolRegistry.get_category(t) for t in tools]
        assert len(set(categories)) >= 2  # At least 2 categories
```

#### Day 5: Integration & Performance Testing

**Performance Benchmarks:**
```python
# Location: tests/performance/test_phase2_performance.py
@pytest.mark.performance
class TestPhase2Performance:
    """Performance benchmarks for Phase 2 changes"""
    
    @pytest.mark.asyncio
    async def test_routing_performance(self):
        """Test routing speed with enhanced complexity analysis"""
        
        tasks = generate_test_tasks(100)  # 100 diverse tasks
        
        start_time = time.time()
        routing_results = []
        
        for task in tasks:
            result = await orchestrator.analyze_task(task)
            routing_results.append(result)
        
        end_time = time.time()
        avg_time = (end_time - start_time) / len(tasks)
        
        # Performance assertions
        assert avg_time < 0.1  # Less than 100ms per task
        assert all(r.confidence > 0.8 for r in routing_results)
    
    @pytest.mark.asyncio
    async def test_security_scan_performance(self):
        """Test security specialist performance"""
        
        code_samples = load_test_code_samples()
        
        scan_times = []
        for code in code_samples:
            start = time.time()
            result = await security_specialist.scan_code(code)
            scan_times.append(time.time() - start)
        
        avg_scan_time = sum(scan_times) / len(scan_times)
        assert avg_scan_time < 2.0  # Less than 2 seconds per scan
```

### Week 4 Validation & Testing

**Integration Test Suite:**
```python
# Location: tests/integration/test_phase2_complete.py
@pytest.mark.integration
@pytest.mark.asyncio
class TestPhase2Complete:
    """Comprehensive Phase 2 validation"""
    
    async def test_complete_workflow(self):
        """Test complete user journey with all Phase 2 changes"""
        
        # Test scenarios covering all improvements
        test_scenarios = [
            {
                "input": "Find security vulnerabilities in auth.py",
                "expected_specialist": "security_specialist",
                "expected_tools_used": ["analyze_code_security", "scan_vulnerabilities"],
                "success_criteria": lambda r: "vulnerability" in r.lower()
            },
            {
                "input": "Design a microservices architecture for e-commerce",
                "expected_specialist": "architecture_specialist",
                "expected_tools_used": ["analyze_system_architecture"],
                "success_criteria": lambda r: "microservice" in r.lower()
            }
        ]
        
        for scenario in test_scenarios:
            # Execute through full stack
            session = await create_test_session()
            result = await vana_chat.process(
                scenario["input"],
                session=session
            )
            
            # Verify routing
            assert session.metadata["routed_to"] == scenario["expected_specialist"]
            
            # Verify tool usage
            tools_used = session.metadata["tools_used"]
            for expected_tool in scenario["expected_tools_used"]:
                assert expected_tool in tools_used
            
            # Verify result quality
            assert scenario["success_criteria"](result.content)
```

### Phase 2 Success Metrics

**Automated Metrics Collection:**
```python
# Location: scripts/collect_phase2_metrics.py
def collect_phase2_metrics():
    """Collect and validate Phase 2 success metrics"""
    
    metrics = {
        "tool_categorization": {
            "target": 100,  # 100% of tools categorized
            "actual": calculate_categorization_percentage()
        },
        "specialist_tool_boundaries": {
            "target": 100,  # Each agent has clear boundaries
            "actual": validate_tool_boundaries()
        },
        "security_routing_accuracy": {
            "target": 95,   # 95% accuracy
            "actual": test_security_routing_accuracy()
        },
        "complexity_domain_detection": {
            "target": 90,   # 90% accurate domain detection
            "actual": test_domain_factor_detection()
        }
    }
    
    # Generate report
    generate_metrics_report(metrics, "Phase 2")
    
    # Validate success
    assert all(m["actual"] >= m["target"] for m in metrics.values())
```

---

## Phase 3: Workflow Enhancement
### Duration: 2 weeks (Weeks 5-6)

### Week 5: Project Manager Implementation

#### Day 1-2: Sequential Project Manager

**Implementation:**
```python
# Location: agents/project_managers/sequential_pm.py
class SequentialProjectManager(LlmAgent):
    """Manages step-by-step task execution"""
    
    def __init__(self):
        super().__init__(
            name="sequential_project_manager",
            model="gemini-2.0-flash",
            instruction="""
            You coordinate sequential task execution. For each task:
            1. Break down into ordered steps
            2. Assign each step to appropriate specialist
            3. Ensure previous step completes before proceeding
            4. Validate outputs meet requirements
            5. Aggregate results coherently
            """,
            tools=[
                FunctionTool(decompose_task_sequential),
                FunctionTool(assign_to_specialist),
                FunctionTool(validate_step_output),
                FunctionTool(aggregate_sequential_results),
                FunctionTool(track_progress)
            ]
        )
```

**Testing:**
```python
# Location: tests/unit/test_sequential_pm.py
@pytest.mark.unit
@pytest.mark.asyncio
async def test_sequential_decomposition():
    """Test sequential task breakdown"""
    
    task = "Build and deploy a REST API"
    pm = SequentialProjectManager()
    
    steps = await pm.decompose_task(task)
    
    # Verify sequential ordering
    expected_order = ["design", "implement", "test", "deploy"]
    actual_order = [s.phase for s in steps]
    
    assert actual_order == expected_order
    assert all(s.dependencies == [s.id - 1] for s in steps[1:])
```

#### Day 3-4: Parallel Project Manager

**Implementation:**
```python
# Location: agents/project_managers/parallel_pm.py
class ParallelProjectManager(LlmAgent):
    """Manages concurrent task execution"""
    
    def __init__(self):
        super().__init__(
            name="parallel_project_manager",
            model="gemini-2.0-flash",
            instruction="""
            You coordinate parallel task execution. Your approach:
            1. Identify independent subtasks
            2. Assign to multiple specialists concurrently
            3. Monitor parallel execution
            4. Synchronize results
            5. Handle dependencies intelligently
            """,
            tools=[
                FunctionTool(identify_parallel_tasks),
                FunctionTool(spawn_concurrent_agents),
                FunctionTool(monitor_parallel_execution),
                FunctionTool(synchronize_results),
                FunctionTool(resolve_conflicts)
            ]
        )
```

**Testing:**
```python
# Location: tests/integration/test_parallel_pm.py
@pytest.mark.integration
@pytest.mark.asyncio
async def test_parallel_execution():
    """Test parallel task execution"""
    
    task = "Analyze codebase for security, performance, and quality"
    pm = ParallelProjectManager()
    
    # Execute task
    start_time = time.time()
    results = await pm.execute(task)
    execution_time = time.time() - start_time
    
    # Verify parallel execution
    assert len(results.parallel_tasks) == 3
    assert results.execution_mode == "parallel"
    
    # Performance check - should be faster than sequential
    sequential_estimate = 3 * 2.0  # 3 tasks × 2 seconds each
    assert execution_time < sequential_estimate * 0.6  # 40% faster
```

#### Day 5: Loop Project Manager

**Implementation:**
```python
# Location: agents/project_managers/loop_pm.py
class LoopProjectManager(LlmAgent):
    """Manages iterative refinement workflows"""
    
    def __init__(self):
        super().__init__(
            name="loop_project_manager", 
            model="gemini-2.0-flash",
            instruction="""
            You coordinate iterative refinement. Process:
            1. Generate initial solution
            2. Evaluate against criteria
            3. Identify improvements
            4. Refine solution
            5. Repeat until criteria met or max iterations
            """,
            tools=[
                FunctionTool(generate_initial_solution),
                FunctionTool(evaluate_against_criteria),
                FunctionTool(identify_improvements),
                FunctionTool(apply_refinements),
                FunctionTool(check_termination_criteria)
            ],
            config={
                "max_iterations": 5,
                "improvement_threshold": 0.1
            }
        )
```

### Week 6: Workflow Integration & Testing

#### Day 1-2: Orchestrator Integration

**Implementation:**
```python
# Location: agents/orchestration/workflow_router.py
class WorkflowRouter:
    """Routes tasks to appropriate project managers"""
    
    def __init__(self):
        self.project_managers = {
            "sequential": SequentialProjectManager(),
            "parallel": ParallelProjectManager(), 
            "loop": LoopProjectManager()
        }
    
    def determine_workflow_type(self, task: dict) -> str:
        """Determine optimal workflow pattern"""
        
        if task.get("requires_order") or self.has_dependencies(task):
            return "sequential"
        elif task.get("independent_subtasks") or self.can_parallelize(task):
            return "parallel"
        elif task.get("requires_refinement") or self.needs_iteration(task):
            return "loop"
        else:
            return "sequential"  # Default
    
    async def route_to_pm(self, task: dict) -> WorkflowResult:
        """Route task to appropriate PM"""
        workflow_type = self.determine_workflow_type(task)
        pm = self.project_managers[workflow_type]
        
        return await pm.execute(task)
```

#### Day 3-5: Comprehensive Workflow Testing

**Test Suite:**
```python
# Location: tests/e2e/test_workflow_patterns.py
@pytest.mark.e2e
@pytest.mark.asyncio
class TestWorkflowPatterns:
    """Test all workflow patterns end-to-end"""
    
    async def test_sequential_workflow_complete(self):
        """Test complete sequential workflow"""
        task = {
            "description": "Create API: Design → Implement → Test → Deploy",
            "requires_order": True
        }
        
        result = await orchestrator.process(task)
        
        # Verify sequential execution
        assert result.workflow_type == "sequential"
        assert len(result.steps) == 4
        
        # Verify step order
        for i, step in enumerate(result.steps[1:], 1):
            assert step.started_after == result.steps[i-1].completed_at
    
    async def test_parallel_workflow_complete(self):
        """Test complete parallel workflow"""
        task = {
            "description": "Analyze all aspects: Security, Performance, Quality",
            "independent_subtasks": True
        }
        
        result = await orchestrator.process(task)
        
        # Verify parallel execution
        assert result.workflow_type == "parallel"
        assert len(result.parallel_executions) >= 3
        
        # Verify timing overlap
        start_times = [e.started_at for e in result.parallel_executions]
        assert max(start_times) - min(start_times) < 0.5  # Started within 500ms
    
    async def test_loop_workflow_complete(self):
        """Test iterative refinement workflow"""
        task = {
            "description": "Optimize algorithm performance until < 100ms",
            "requires_refinement": True,
            "success_criteria": {"performance": "< 100ms"}
        }
        
        result = await orchestrator.process(task)
        
        # Verify iterative execution
        assert result.workflow_type == "loop"
        assert 1 <= result.iterations <= 5
        assert result.final_performance < 100  # Success criteria met
```

### Phase 3 Success Metrics

```python
# Location: scripts/collect_phase3_metrics.py
def collect_phase3_metrics():
    """Collect Phase 3 success metrics"""
    
    metrics = {
        "workflow_completion_rate": {
            "target": 90,
            "actual": test_workflow_completion_rate()
        },
        "context_propagation_accuracy": {
            "target": 95,
            "actual": test_context_propagation()
        },
        "parallel_speedup": {
            "target": 1.5,  # 50% faster than sequential
            "actual": measure_parallel_speedup()
        },
        "iteration_efficiency": {
            "target": 80,   # 80% reach criteria within 3 iterations
            "actual": measure_iteration_efficiency()
        }
    }
    
    generate_metrics_report(metrics, "Phase 3")
```

---

## Phase 4: Smart Memory Integration
### Duration: 2 weeks (Weeks 7-8)

### Week 7: Enhanced Memory Agent

#### Day 1-3: Memory Value Scoring

**Implementation:**
```python
# Location: agents/maintenance/enhanced_memory_agent.py
class EnhancedMemoryAgent(LlmAgent):
    """Intelligent memory management agent"""
    
    def __init__(self):
        super().__init__(
            name="memory_agent",
            model="gemini-2.0-flash",
            instruction="""
            You manage VANA's long-term memory. Responsibilities:
            1. Evaluate information for long-term value
            2. Store only high-value memories (score >= 4)
            3. Maintain memory relevance over time
            4. Extract patterns from memories
            5. Optimize retrieval efficiency
            """,
            tools=[
                FunctionTool(evaluate_memory_value),
                FunctionTool(store_high_value_memory),
                FunctionTool(retrieve_relevant_memories),
                FunctionTool(extract_patterns),
                FunctionTool(prune_low_value_memories)
            ]
        )
    
    def evaluate_memory_value(self, content: str, context: dict) -> int:
        """Score memory from 1-5 based on value criteria"""
        
        score = 0
        
        # Reusability (0-2 points)
        if self.is_pattern_not_instance(content):
            score += 2
        elif self.has_general_applicability(content):
            score += 1
        
        # Domain relevance (0-2 points)
        if self.is_domain_expert_knowledge(content, context):
            score += 2
        elif self.is_technical_insight(content):
            score += 1
        
        # Actionability (0-1 point)
        if self.contains_actionable_guidance(content):
            score += 1
        
        return min(score, 5)
```

**Testing:**
```python
# Location: tests/unit/test_memory_scoring.py
@pytest.mark.unit
def test_memory_value_scoring():
    """Test memory value evaluation"""
    
    memory_agent = EnhancedMemoryAgent()
    
    # High-value memories (score 4-5)
    high_value = [
        "Always validate user input before database operations",
        "Use connection pooling for database connections > 10 concurrent users",
        "Implement circuit breakers for external API calls"
    ]
    
    for memory in high_value:
        score = memory_agent.evaluate_memory_value(memory, {})
        assert score >= 4
    
    # Low-value memories (score 1-2)
    low_value = [
        "Fixed bug in user.py line 42",
        "Today's weather is sunny",
        "User prefers blue background"
    ]
    
    for memory in low_value:
        score = memory_agent.evaluate_memory_value(memory, {})
        assert score <= 2
```

#### Day 4-5: Pattern Extraction

**Implementation:**
```python
# Location: lib/_shared_libraries/pattern_extractor.py
class PatternExtractor:
    """Extract patterns from memory collection"""
    
    def extract_patterns(self, memories: List[Memory]) -> List[Pattern]:
        """Identify recurring patterns in memories"""
        
        patterns = []
        
        # Group by similarity
        clusters = self.cluster_memories(memories)
        
        for cluster in clusters:
            if len(cluster) >= 3:  # Pattern threshold
                pattern = self.synthesize_pattern(cluster)
                patterns.append(pattern)
        
        return patterns
    
    def synthesize_pattern(self, similar_memories: List[Memory]) -> Pattern:
        """Create pattern from similar memories"""
        
        # Extract common elements
        common_elements = self.find_common_elements(similar_memories)
        
        # Generate pattern description
        pattern = Pattern(
            description=self.generate_pattern_description(common_elements),
            confidence=self.calculate_pattern_confidence(similar_memories),
            applicable_domains=self.identify_domains(similar_memories),
            examples=[m.id for m in similar_memories[:3]]
        )
        
        return pattern
```

### Week 8: Memory Evolution & Performance

#### Day 1-2: Memory Evolution System

**Implementation:**
```python
# Location: agents/maintenance/memory_evolution.py
class MemoryEvolutionSystem:
    """Evolve memories based on usage and relevance"""
    
    def __init__(self, memory_store: MemoryStore):
        self.memory_store = memory_store
        self.evolution_rules = self.define_evolution_rules()
    
    def define_evolution_rules(self) -> List[EvolutionRule]:
        """Define how memories evolve over time"""
        return [
            EvolutionRule(
                name="deprecate_contradicted",
                condition=lambda m: m.contradicted_by_newer,
                action=lambda m: self.deprecate_memory(m)
            ),
            EvolutionRule(
                name="promote_frequently_used",
                condition=lambda m: m.access_count > 10,
                action=lambda m: self.promote_memory(m)
            ),
            EvolutionRule(
                name="archive_unused",
                condition=lambda m: m.days_since_access > 30,
                action=lambda m: self.archive_memory(m)
            )
        ]
    
    async def evolve_memories(self):
        """Run evolution rules on all memories"""
        
        memories = await self.memory_store.get_all_active()
        evolution_report = EvolutionReport()
        
        for memory in memories:
            for rule in self.evolution_rules:
                if rule.condition(memory):
                    result = await rule.action(memory)
                    evolution_report.add_action(memory.id, rule.name, result)
        
        return evolution_report
```

#### Day 3-5: Performance Optimization & Testing

**Performance Testing:**
```python
# Location: tests/performance/test_memory_performance.py
@pytest.mark.performance
@pytest.mark.asyncio
class TestMemoryPerformance:
    """Test memory system performance"""
    
    async def test_retrieval_speed(self):
        """Test memory retrieval performance"""
        
        # Load test memories
        memory_store = await create_test_memory_store(10000)  # 10k memories
        memory_agent = EnhancedMemoryAgent(memory_store)
        
        # Test retrieval speed
        queries = generate_test_queries(100)
        retrieval_times = []
        
        for query in queries:
            start = time.time()
            memories = await memory_agent.retrieve_relevant_memories(query)
            retrieval_times.append(time.time() - start)
        
        avg_retrieval_time = sum(retrieval_times) / len(retrieval_times)
        assert avg_retrieval_time < 0.1  # Less than 100ms average
    
    async def test_pattern_extraction_performance(self):
        """Test pattern extraction efficiency"""
        
        memories = await load_test_memories(1000)
        extractor = PatternExtractor()
        
        start = time.time()
        patterns = extractor.extract_patterns(memories)
        extraction_time = time.time() - start
        
        assert extraction_time < 5.0  # Less than 5 seconds
        assert len(patterns) > 10     # Found meaningful patterns
```

### Phase 4 Comprehensive Testing

```python
# Location: tests/e2e/test_phase4_complete.py
@pytest.mark.e2e
@pytest.mark.asyncio
class TestPhase4Complete:
    """End-to-end tests for Phase 4"""
    
    async def test_memory_lifecycle(self):
        """Test complete memory lifecycle"""
        
        # 1. Create memories with varying values
        test_memories = [
            ("Use async/await for I/O operations", {"domain": "performance"}),
            ("User John prefers dark mode", {"user": "john"}),
            ("Always sanitize SQL inputs", {"domain": "security"}),
            ("Meeting scheduled for 3pm", {"temporal": True})
        ]
        
        memory_agent = EnhancedMemoryAgent()
        stored_memories = []
        
        for content, context in test_memories:
            score = memory_agent.evaluate_memory_value(content, context)
            if score >= 4:
                memory_id = await memory_agent.store_memory(content, context)
                stored_memories.append(memory_id)
        
        # Verify only high-value memories stored
        assert len(stored_memories) == 2  # async/await and SQL sanitization
        
        # 2. Test pattern extraction
        await simulate_memory_usage(stored_memories, cycles=20)
        patterns = await memory_agent.extract_patterns()
        
        assert any("async" in p.description for p in patterns)
        assert any("security" in p.description for p in patterns)
        
        # 3. Test memory evolution
        evolution_system = MemoryEvolutionSystem(memory_agent.memory_store)
        evolution_report = await evolution_system.evolve_memories()
        
        # Verify evolution actions
        assert evolution_report.promoted_count >= 2
        assert evolution_report.archived_count >= 1
```

### Phase 4 Success Metrics

```python
# Location: scripts/collect_phase4_metrics.py
def collect_phase4_metrics():
    """Collect Phase 4 success metrics"""
    
    metrics = {
        "high_value_memory_ratio": {
            "target": 60,  # 60% of memories score 4-5
            "actual": calculate_high_value_ratio()
        },
        "memory_retrieval_speed": {
            "target": 0.1,  # 100ms average
            "actual": measure_retrieval_speed()
        },
        "pattern_recognition_accuracy": {
            "target": 85,   # 85% accurate patterns
            "actual": test_pattern_accuracy()
        },
        "memory_usage_improvement": {
            "target": 20,   # 20% performance improvement
            "actual": measure_performance_impact()
        }
    }
    
    generate_metrics_report(metrics, "Phase 4")
```

---

## Continuous Integration & Testing Strategy

### Test Automation Pipeline

```yaml
# Location: .github/workflows/agent-expansion-tests.yml
name: Agent Expansion Test Suite

on:
  push:
    branches: [main, agent-expansion-*]
  pull_request:
    branches: [main]

jobs:
  phase-tests:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        phase: [2, 3, 4]
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'
    
    - name: Install dependencies
      run: |
        pip install poetry
        poetry install
    
    - name: Run Phase ${{ matrix.phase }} Tests
      run: |
        # Unit tests
        poetry run pytest tests/unit/phase${{ matrix.phase }} -v
        
        # Integration tests
        poetry run pytest tests/integration/phase${{ matrix.phase }} -v
        
        # E2E tests (if not PR)
        if [ "${{ github.event_name }}" != "pull_request" ]; then
          poetry run pytest tests/e2e/phase${{ matrix.phase }} -v
        fi
    
    - name: Collect Metrics
      if: github.ref == 'refs/heads/main'
      run: |
        poetry run python scripts/collect_phase${{ matrix.phase }}_metrics.py
```

### Testing Best Practices

1. **Test Categories**:
   - **Unit**: Individual component functionality
   - **Integration**: Component interactions
   - **E2E**: Complete user journeys
   - **Performance**: Speed and resource usage

2. **Test Data Management**:
```python
# Location: tests/fixtures/test_data_factory.py
class TestDataFactory:
    """Generate consistent test data"""
    
    @staticmethod
    def create_test_task(complexity: str = "SIMPLE") -> dict:
        """Create test task with known properties"""
        return {
            "id": str(uuid.uuid4()),
            "description": f"Test task - {complexity}",
            "complexity": complexity,
            "metadata": {
                "test": True,
                "created_at": datetime.now()
            }
        }
```

3. **Mock External Dependencies**:
```python
# Location: tests/mocks/external_services.py
class MockGeminiModel:
    """Mock Gemini model for testing"""
    
    def __init__(self, responses: dict):
        self.responses = responses
    
    async def generate(self, prompt: str) -> str:
        """Return predetermined response"""
        for pattern, response in self.responses.items():
            if pattern in prompt:
                return response
        return "Default test response"
```

---

## Risk Mitigation & Rollback Strategy

### Risk Matrix

| Risk | Probability | Impact | Mitigation | Rollback |
|------|------------|--------|-----------|----------|
| Tool redistribution breaks existing flows | Medium | High | Gradual rollout, feature flags | Revert tool assignments |
| Memory scoring too restrictive | Medium | Medium | Adjustable thresholds | Lower score requirements |
| Workflow deadlocks | Low | High | Timeout mechanisms | Kill workflow, return error |
| Performance degradation | Low | Medium | Performance tests, monitoring | Disable new features |

### Feature Flags

```python
# Location: lib/config/feature_flags.py
class FeatureFlags:
    """Control feature rollout"""
    
    FLAGS = {
        "enhanced_complexity_analysis": True,
        "security_specialist": True,
        "tool_categorization": True,
        "workflow_managers": False,  # Phase 3
        "smart_memory": False,       # Phase 4
    }
    
    @classmethod
    def is_enabled(cls, feature: str) -> bool:
        """Check if feature is enabled"""
        return cls.FLAGS.get(feature, False)
```

---

## Success Criteria Summary

### Overall Implementation Success
- ✅ All phases completed within 10-week timeline
- ✅ Each phase passes 95%+ of tests
- ✅ Performance metrics meet or exceed targets
- ✅ Zero critical bugs in production
- ✅ ADK compliance maintained throughout

### Phase-Specific Success
- **Phase 2**: 100% tool categorization, 95% routing accuracy
- **Phase 3**: 90% workflow completion, 50% parallel speedup
- **Phase 4**: 60% high-value memories, 20% performance gain

---

## Conclusion

This phased implementation plan provides:
1. **Clear sequential steps** with dependencies
2. **Comprehensive testing** at each phase
3. **Measurable success metrics**
4. **Risk mitigation strategies**
5. **ADK compliance throughout**

The plan balances ambition with pragmatism, ensuring each phase builds on solid foundations while maintaining system stability and performance.

---

*Next Steps: Begin Phase 2 Week 3 implementation with tool categorization framework*