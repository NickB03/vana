# Directory Navigation Prevention Guide - Quick Reference

## 🚨 Quick Checks Before Any Command

### Am I in the right directory?
```bash
pwd
# ✅ GOOD: /Users/nick/Development/vana
# ❌ BAD:  /Users/nick/Development/vana/vana-ui
```

### Quick validation:
```bash
ls main.py
# Should show: main.py (not "No such file")
```

## 🛡️ Safe Command Patterns

### ✅ ALWAYS USE (Safe Patterns)

```bash
# Pattern 1: Subshells (Recommended)
(cd vana-ui && npm install)
# Returns to original directory automatically

# Pattern 2: Pushd/Popd
pushd vana-ui
npm install
popd

# Pattern 3: Absolute paths
npm --prefix ./vana-ui install

# Pattern 4: Make commands (built-in safety)
make dev
make deploy
```

### ❌ NEVER USE (Unsafe Patterns)

```bash
# DON'T: Direct cd without return
cd vana-ui
npm install
# Leaves you in wrong directory!

# DON'T: Relative deployment
gcloud run deploy --source .
# Uses current directory - dangerous!

# DON'T: Assume directory
./deploy-staging.sh
# Fails if not in root
```

## 📊 Warning Signs You're in Wrong Directory

| Symptom | Meaning | Fix |
|---------|---------|-----|
| "102 files" in deployment | In vana-ui/ | `cd ..` |
| "Buildpacks" detected | No Dockerfile found | `cd` to project root |
| Scripts "not found" | Wrong directory | `cd /path/to/vana` |
| No `main.py` | Not in root | Navigate to root |
| Git shows different branch | In submodule | `cd ..` |

## 🚀 Safe Deployment Checklist

```bash
# 1. Verify location
pwd  # Must show project root

# 2. Verify files
ls -la main.py Dockerfile.prod vana-ui/
# All three must exist

# 3. Count files (optional)
find . -name "*.py" -o -name "*.ts" | grep -v node_modules | wc -l
# Should be 500+ files

# 4. Deploy with validation
./deploy-staging.sh
# Script should validate directory
```

## 🛠️ Emergency Recovery

### If deployment started from wrong directory:
```bash
# 1. Cancel immediately (Ctrl+C)
# 2. Return to root
cd /Users/nick/Development/vana
# 3. Verify
ls main.py
# 4. Re-run deployment
./deploy-staging.sh
```

### If unsure of location:
```bash
# Find project root
find ~ -name "main.py" -path "*/vana/*" 2>/dev/null | grep -v venv
# Navigate there
cd /Users/nick/Development/vana
```

## 💡 Pro Tips

1. **Add to shell profile** (.bashrc/.zshrc):
   ```bash
   alias vana-root='cd /Users/nick/Development/vana'
   alias vana-ui='cd /Users/nick/Development/vana/vana-ui'
   alias vana-check='pwd && ls main.py 2>/dev/null || echo "NOT IN ROOT"'
   ```

2. **Use terminal title**:
   ```bash
   # Add to .bashrc/.zshrc
   PROMPT_COMMAND='echo -ne "\033]0;${PWD##*/}\007"'
   ```

3. **Create safety wrapper**:
   ```bash
   # ~/.local/bin/safe-deploy
   #!/bin/bash
   if [ ! -f "main.py" ]; then
       echo "❌ Not in VANA root directory!"
       exit 1
   fi
   exec "$@"
   ```

## 📋 Common Workflows (Safe)

### Frontend Development
```bash
vana-root  # Use alias
(cd vana-ui && npm run dev)  # Subshell
```

### Backend Development
```bash
vana-root
poetry run python main.py
```

### Full Stack
```bash
vana-root
make dev  # Handles directories safely
```

### Deployment
```bash
vana-root
vana-check  # Verify first
./deploy-staging.sh
```

## ⚡ Quick Reference Card

```
Before ANY deployment or important command:
1. pwd         → Check directory
2. ls main.py  → Verify in root
3. Execute     → Run command

If anything fails:
- cd /Users/nick/Development/vana
- Try again
```

Remember: **When in doubt, check your directory!**