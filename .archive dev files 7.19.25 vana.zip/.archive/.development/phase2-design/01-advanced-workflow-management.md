# Phase 2: Advanced Workflow Management System

**Component**: Advanced Workflow Management  
**Version**: 2.0.0  
**Status**: Design Phase  
**Updated**: July 11, 2025

## Executive Summary

Based on the ADK agent research findings, we need to evolve from our current 7-agent system to support 22+ specialized agents through an advanced workflow management system. This design implements dynamic agent spawning, workflow templates, and intelligent orchestration patterns.

## Architecture Overview

```mermaid
graph TB
    subgraph "Workflow Management Layer"
        WE[Workflow Engine]
        WT[Workflow Templates]
        WC[Workflow Coordinator]
        AS[Agent Spawner]
    end
    
    subgraph "Execution Patterns"
        SEQ[Sequential Executor]
        PAR[Parallel Executor]
        LOOP[Loop Executor]
        COND[Conditional Router]
    end
    
    subgraph "Resource Management"
        AP[Agent Pool]
        DAS[Dynamic Agent Spawner]
        RM[Resource Monitor]
        CB[Circuit Breaker]
    end
    
    MO[Master Orchestrator] --> WE
    WE --> WT
    WE --> WC
    WC --> SEQ
    WC --> PAR
    WC --> LOOP
    WC --> COND
    
    AS --> AP
    AS --> DAS
    DAS --> RM
    RM --> CB
```

## Core Components

### 1. Workflow Engine

```python
# lib/workflow/workflow_engine.py
from typing import Dict, List, Optional, Any
from enum import Enum
from google.adk import LlmAgent
from dataclasses import dataclass

class WorkflowType(Enum):
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    CONDITIONAL = "conditional"
    LOOP = "loop"
    HYBRID = "hybrid"

@dataclass
class WorkflowStep:
    agent_name: str
    task: str
    dependencies: List[str] = None
    condition: Optional[str] = None
    max_retries: int = 3
    timeout: int = 300

class WorkflowEngine:
    def __init__(self):
        self.templates = WorkflowTemplateRegistry()
        self.executor = WorkflowExecutor()
        self.spawner = DynamicAgentSpawner()
        
    async def execute_workflow(
        self,
        workflow_type: WorkflowType,
        steps: List[WorkflowStep],
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute a workflow with dynamic agent management."""
        # Analyze resource requirements
        required_agents = self._analyze_required_agents(steps)
        
        # Spawn agents dynamically
        active_agents = await self.spawner.ensure_agents(required_agents)
        
        # Execute workflow
        result = await self.executor.run(
            workflow_type=workflow_type,
            steps=steps,
            agents=active_agents,
            context=context
        )
        
        # Cleanup idle agents
        await self.spawner.cleanup_idle_agents()
        
        return result
```

### 2. Dynamic Agent Spawner

```python
# lib/workflow/dynamic_agent_spawner.py
from collections import defaultdict
from datetime import datetime, timedelta

class DynamicAgentSpawner:
    def __init__(self):
        self.agent_pool = {}
        self.agent_stats = defaultdict(lambda: {
            'last_used': None,
            'usage_count': 0,
            'avg_response_time': 0
        })
        self.idle_timeout = timedelta(minutes=5)
        
    async def ensure_agents(self, required_agents: List[str]) -> Dict[str, LlmAgent]:
        """Ensure required agents are available, spawning if needed."""
        active_agents = {}
        
        for agent_name in required_agents:
            if agent_name in self.agent_pool:
                # Reuse existing agent
                agent = self.agent_pool[agent_name]
                self.agent_stats[agent_name]['last_used'] = datetime.now()
            else:
                # Spawn new agent based on catalog
                agent = await self._spawn_agent(agent_name)
                self.agent_pool[agent_name] = agent
                
            active_agents[agent_name] = agent
            
        return active_agents
        
    async def _spawn_agent(self, agent_name: str) -> LlmAgent:
        """Spawn agent based on ADK catalog specifications."""
        agent_spec = AGENT_CATALOG.get(agent_name)
        
        # Select model tier based on research recommendations
        model = self._select_model_tier(agent_spec)
        
        return LlmAgent(
            name=agent_name,
            model=model,
            description=agent_spec['description'],
            instruction=agent_spec['instruction'],
            tools=agent_spec['tools'][:6]  # ADK limit: 6 tools max
        )
```

### 3. Workflow Templates

```python
# lib/workflow/workflow_templates.py
class WorkflowTemplateRegistry:
    def __init__(self):
        self.templates = {
            "full_stack_development": self._full_stack_template(),
            "data_analysis_pipeline": self._data_analysis_template(),
            "system_architecture": self._architecture_template(),
            "bug_investigation": self._bug_investigation_template(),
            "research_synthesis": self._research_template()
        }
        
    def _full_stack_template(self) -> Dict[str, Any]:
        return {
            "type": WorkflowType.HYBRID,
            "steps": [
                WorkflowStep(
                    agent_name="architecture_specialist",
                    task="Design system architecture",
                ),
                WorkflowStep(
                    agent_name="ui_specialist",
                    task="Create frontend components",
                    dependencies=["architecture_specialist"]
                ),
                WorkflowStep(
                    agent_name="code_execution",
                    task="Implement backend logic",
                    dependencies=["architecture_specialist"]
                ),
                WorkflowStep(
                    agent_name="qa_specialist",
                    task="Generate tests",
                    dependencies=["ui_specialist", "code_execution"]
                ),
                WorkflowStep(
                    agent_name="devops_specialist",
                    task="Create deployment config",
                    dependencies=["qa_specialist"]
                )
            ],
            "parallel_groups": [
                ["ui_specialist", "code_execution"]
            ]
        }
```

### 4. Execution Patterns

```python
# lib/workflow/execution_patterns.py
class ParallelExecutor:
    async def execute(
        self,
        steps: List[WorkflowStep],
        agents: Dict[str, LlmAgent],
        context: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Execute steps in parallel with resource management."""
        tasks = []
        
        for step in steps:
            agent = agents[step.agent_name]
            task = asyncio.create_task(
                self._execute_with_timeout(agent, step, context)
            )
            tasks.append(task)
            
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return self._process_results(results, steps)

class ConditionalRouter:
    def evaluate_condition(
        self,
        condition: str,
        context: Dict[str, Any]
    ) -> bool:
        """Evaluate workflow branching conditions."""
        # Safe evaluation of conditions
        allowed_vars = {
            'context': context,
            'len': len,
            'any': any,
            'all': all
        }
        return eval(condition, {"__builtins__": {}}, allowed_vars)
```

## API Design

### Workflow Management API

```yaml
openapi: 3.0.0
info:
  title: VANA Workflow Management API
  version: 2.0.0

paths:
  /api/v2/workflows:
    post:
      summary: Execute a workflow
      requestBody:
        content:
          application/json:
            schema:
              type: object
              properties:
                workflow_type:
                  type: string
                  enum: [sequential, parallel, conditional, loop, hybrid]
                template_name:
                  type: string
                  description: Optional pre-defined template
                steps:
                  type: array
                  items:
                    $ref: '#/components/schemas/WorkflowStep'
                context:
                  type: object
                  description: Workflow execution context
      responses:
        200:
          description: Workflow execution result
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/WorkflowResult'
                
  /api/v2/workflows/templates:
    get:
      summary: List available workflow templates
      responses:
        200:
          description: Available templates
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/WorkflowTemplate'
                  
  /api/v2/workflows/{workflow_id}/status:
    get:
      summary: Get workflow execution status
      parameters:
        - name: workflow_id
          in: path
          required: true
          schema:
            type: string
      responses:
        200:
          description: Workflow status
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/WorkflowStatus'

components:
  schemas:
    WorkflowStep:
      type: object
      required: [agent_name, task]
      properties:
        agent_name:
          type: string
        task:
          type: string
        dependencies:
          type: array
          items:
            type: string
        condition:
          type: string
        max_retries:
          type: integer
          default: 3
        timeout:
          type: integer
          default: 300
          
    WorkflowResult:
      type: object
      properties:
        workflow_id:
          type: string
        status:
          type: string
          enum: [completed, failed, partial]
        results:
          type: array
          items:
            type: object
        execution_time:
          type: number
        resource_usage:
          type: object
```

## Integration with Current System

### 1. Master Orchestrator Enhancement

```python
# Updates to agents/orchestration/hierarchical_task_manager.py
class EnhancedHierarchicalTaskManager:
    def __init__(self):
        self.workflow_engine = WorkflowEngine()
        self.complexity_analyzer = ComplexityAnalyzer()
        
    async def route_task(self, task: str, context: Dict) -> Any:
        complexity = self.complexity_analyzer.analyze(task)
        
        if complexity.level == "ENTERPRISE":
            # Use workflow for complex multi-agent tasks
            workflow = self._design_workflow(task, complexity)
            return await self.workflow_engine.execute_workflow(
                workflow_type=workflow.type,
                steps=workflow.steps,
                context=context
            )
        else:
            # Continue with existing single-agent routing
            return await self._route_to_specialist(task, complexity)
```

### 2. Resource Monitoring

```python
# lib/workflow/resource_monitor.py
class WorkflowResourceMonitor:
    def __init__(self):
        self.metrics = {
            'active_agents': 0,
            'queued_tasks': 0,
            'avg_response_time': 0,
            'memory_usage': 0,
            'token_usage': 0
        }
        
    async def monitor_workflow_execution(self, workflow_id: str):
        """Track resource usage during workflow execution."""
        # Implementation for resource tracking
        pass
```

## Benefits

1. **Dynamic Scaling**: Spawn agents only when needed, reducing resource usage
2. **Complex Task Handling**: Support for sophisticated multi-agent workflows
3. **Template Library**: Pre-built workflows for common scenarios
4. **Resource Efficiency**: Automatic cleanup of idle agents
5. **Fault Tolerance**: Built-in retry and circuit breaker patterns

## Next Steps

1. Implement workflow execution engine
2. Create agent spawning mechanism
3. Build workflow template library
4. Integrate with existing orchestrator
5. Add monitoring and metrics

---

*This design incorporates insights from the ADK agent research document to create a scalable, efficient workflow management system for Phase 2.*