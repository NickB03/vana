# 📁 VANA Subdirectory Cleanup Report

Generated: July 10, 2025

## 🔍 Executive Summary

After reviewing all subdirectories, several areas have been identified for potential cleanup. Most require careful consideration as they may impact code functionality.

## 📊 Cleanup Opportunities by Directory

### 1. **agents/** - Test Agent Directories
**Status**: ⚠️ Requires Review
- `test_minimal/`, `test_output_key/`, `test_output_key_tools/`, `test_single_tool/`, `test_sub_agents/`
- **Finding**: These appear to be legitimate test agents for ADK validation
- **Recommendation**: Keep for now, but review if actively used in test suite

### 2. **lib/_tools/** - Deprecated Code
**Status**: ✅ Safe to Clean
- `archived_code/deprecated_web_search/` contains 5 deprecated implementations
- **Finding**: Already archived, not imported anywhere
- **Recommendation**: Can be removed if no longer needed for reference

### 3. **tests/** - One-Time Test Files
**Status**: ✅ Safe to Clean
- `one_time_tests/` contains 21 test files
- **Finding**: Appears to be development/debugging tests
- **Recommendation**: Archive or remove after confirming they're not part of CI/CD

### 4. **scripts/** - Duplicate Test Scripts
**Status**: ⚠️ Requires Consolidation
- Multiple `run_*.sh` scripts with similar purposes
- Test files mixed with operational scripts
- **Finding**: Potential for consolidation
- **Recommendation**: 
  - Consolidate test runners
  - Move test files to tests/ directory
  - Keep only essential operational scripts

### 5. **tools/** - Multiple Search Implementations
**Status**: 🚨 Code Refactoring Required
- Multiple search files: `enhanced_hybrid_search.py`, `hybrid_search.py`, `web_search.py`
- Multiple memory implementations
- **Finding**: Possible redundancy, but may be in active use
- **Recommendation**: Requires code analysis to determine which are actively used

### 6. **archived_docs/** & **vscode-dev-docs/**
**Status**: ✅ Already Organized
- 10 files each, properly archived
- **Finding**: Already in appropriate archive locations
- **Recommendation**: No action needed

### 7. **tests/results/** - Old Test Results
**Status**: ✅ Safe to Clean
- 18 JSON result files from previous test runs
- **Finding**: Historical test results
- **Recommendation**: Keep recent results, archive/remove older ones

## 🎯 Recommended Actions

### Immediate (Safe to Clean):
1. **Remove** `lib/_tools/archived_code/deprecated_web_search/` if no longer needed
2. **Archive/Remove** `tests/one_time_tests/` after verification
3. **Clean** old test results in `tests/results/` (keep last 30 days)

### Requires Investigation:
1. **Review** agent test directories in `agents/test_*/`
2. **Consolidate** scripts in `scripts/` directory
3. **Analyze** multiple search/memory implementations in `tools/`

### Code-Impacting (Requires Refactoring):
1. **tools/** directory - Multiple implementations may require:
   - Dependency analysis to see what's actively used
   - Update imports if files are consolidated
   - Ensure no breaking changes to API

## 📈 Potential Space Savings

- **Immediate cleanup**: ~2-3 MB
- **After consolidation**: ~5-10 MB
- **Code refactoring**: ~10-15 MB

## ⚠️ Risk Assessment

- **Low Risk**: Removing archived/deprecated code, old test results
- **Medium Risk**: Consolidating scripts, removing test files
- **High Risk**: Modifying tools/ directory structure (requires careful refactoring)

## 📋 Next Steps

1. Start with low-risk cleanups
2. Create backups before any medium-risk changes
3. Plan refactoring sprint for high-risk consolidations
4. Update documentation after changes
5. Run full test suite after each cleanup phase

---

*Note: All file counts and recommendations are based on current state as of July 10, 2025*