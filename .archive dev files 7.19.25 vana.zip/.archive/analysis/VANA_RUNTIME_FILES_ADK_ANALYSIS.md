# VANA Runtime Files - ADK Standard vs Custom Analysis

This document categorizes each VANA runtime file as either Google ADK standard or VANA custom implementation.

## Summary
- **Total Runtime Files**: ~39 (excluding main_agentic.py)
- **ADK Standard**: ~6 files (using ADK patterns/classes)
- **VANA Custom**: ~33 files (custom implementations)

## File-by-File Analysis

### Entry Points

#### ❌ `main.py` - **CUSTOM**
- **Why Custom**: FastAPI integration is not part of ADK
- **ADK Standard**: Would use simple `Runner` class
- **VANA Addition**: Web API layer, streaming responses, CORS

### API Layer

#### ❌ `api/endpoints.py` - **CUSTOM**
- **Why Custom**: API endpoints are VANA-specific
- **Not in ADK**: ADK doesn't define web APIs

### Core Orchestration

#### ❌ `agents/base_agents.py` - **CUSTOM**
- **Why Custom**: Workaround for circular dependencies
- **ADK Standard**: Direct `root_agent` variable in module
- **VANA Pattern**: Getter/setter pattern for agent management

#### ✅ `agents/vana/team.py` - **PARTIALLY ADK STANDARD**
- **ADK Parts**: Uses `Agent` class from `google.adk.agents`
- **Custom Parts**: Specific agent configuration and tool selection

#### ❌ `agents/vana/enhanced_orchestrator.py` - **CUSTOM**
- **Why Custom**: Custom routing logic, metrics integration
- **ADK Standard**: Would use `SequentialAgent`, `ParallelAgent`
- **VANA Addition**: MetricsTimer, specialist routing, caching

### Active Specialists

#### ✅ All Specialist Files - **PARTIALLY ADK STANDARD**
- **ADK Parts**: Use `LlmAgent` from `google.adk.agents`
- **Custom Parts**: Specific instructions, tool selections
- **Note**: `LlmAgent` vs `Agent` - both are ADK but different classes

Files:
- `agents/specialists/architecture_specialist.py`
- `agents/specialists/data_science_specialist.py`
- `agents/specialists/security_specialist.py`
- `agents/specialists/devops_specialist.py`
- `agents/specialists/content_creation_specialist.py`
- `agents/specialists/research_specialist.py`

### Specialist Tools

#### ❌ All Tool Implementation Files - **CUSTOM**
- **Why Custom**: Tool logic is entirely VANA-specific
- **ADK Provides**: Only `FunctionTool` wrapper
- **VANA Implements**: Actual tool functionality

Files:
- `agents/specialists/architecture_tools.py`
- `agents/specialists/data_science_tools.py`
- `agents/specialists/security_tools.py`
- `agents/specialists/devops_tools.py`

### Core Tools

#### ❌ `lib/_tools/__init__.py` - **CUSTOM**
- Tool exports are VANA-specific

#### ❌ `lib/_tools/adk_tools.py` - **CUSTOM**
- **ADK Part**: Uses `FunctionTool` wrapper
- **Custom Part**: All tool implementations (read_file, write_file, etc.)

#### ❌ `lib/_tools/adk_mcp_tools.py` - **CUSTOM**
- MCP integration is VANA-specific

#### ❌ `lib/_tools/google_search_v2.py` - **CUSTOM**
- Web search implementation is VANA-specific

#### ❌ `lib/_tools/web_search_sync.py` - **CUSTOM**
- Synchronous wrapper is VANA-specific

### Essential Libraries

#### ❌ All Library Files - **CUSTOM**
- **Why Custom**: All are VANA-specific implementations
- **Not in ADK**: Logging, formatting, context, metrics, memory

Files:
- `lib/logging_config.py`
- `lib/response_formatter.py`
- `lib/context/specialist_context.py`
- `lib/_shared_libraries/orchestrator_metrics.py`
- `lib/_shared_libraries/adk_memory_service.py`

### ADK Integration

#### ❌ All Integration Files - **CUSTOM**
- **Why Custom**: Bridge between ADK and VANA architecture
- **Purpose**: Adapt ADK to VANA's needs

Files:
- `lib/adk_integration/__init__.py`
- `lib/adk_integration/event_stream.py`
- `lib/adk_integration/silent_handoff.py`
- `lib/adk_integration/main_integration.py`

### Configuration Files

#### ❌ All Config Files - **CUSTOM**
- Project-specific configuration
- Not defined by ADK

Files:
- `pyproject.toml`
- `poetry.lock`
- `.env.example`
- `.gitignore`

### Package Initialization Files

#### ✅ `__init__.py` files - **STANDARD PYTHON**
- Required by Python, not ADK-specific
- But necessary for ADK module structure

## Key Findings

### What's Actually ADK Standard:
1. **Agent Classes**: `Agent`, `LlmAgent` from `google.adk.agents`
2. **Workflow Agents**: `SequentialAgent`, `ParallelAgent`, `LoopAgent` (not used in VANA)
3. **Tool Wrapper**: `FunctionTool` from `google.adk.tools`
4. **Tool Context**: `ToolContext` for stateful tools (not used in VANA)
5. **Pydantic Integration**: `output_schema` parameter
6. **6-Tool Limit**: Architectural constraint

### What's VANA Custom:
1. **All tool implementations** (file operations, search, etc.)
2. **FastAPI integration** and web API layer
3. **Custom routing logic** (enhanced_orchestrator.py)
4. **Metrics and monitoring** systems
5. **Memory service** implementation
6. **Specialist context** management
7. **All specialist-specific tools**
8. **Web search** implementations
9. **Logging and formatting** utilities

## Recommendations for New Repository

### Minimal ADK-Compliant Approach:
1. Use ADK's native `SequentialAgent` and `ParallelAgent` instead of custom orchestrator
2. Replace custom routing with ADK's built-in agent selection
3. Use ADK's session management instead of custom memory service
4. Simplify to use `Runner` class instead of FastAPI (or clearly separate concerns)

### Files to Potentially Exclude:
- `enhanced_orchestrator.py` - Replace with ADK patterns
- `orchestrator_metrics.py` - Use ADK callbacks instead
- `base_agents.py` - Use direct `root_agent` pattern
- Most of `lib/` - These are all custom implementations

### True Minimal ADK-Native Setup:
- Direct agent definitions with `root_agent`
- Tools wrapped with `FunctionTool`
- Use ADK's workflow agents
- Minimal custom code