
function calculate(a, b) {
    const result = a + b;
    console.log('Result:', result;  // Missing closing parenthesis
    return result
}

const value = calculate(5, 10;  // Missing closing parenthesis

if (value > 10 {  // Missing closing parenthesis
    console.log('Large value');
}
        