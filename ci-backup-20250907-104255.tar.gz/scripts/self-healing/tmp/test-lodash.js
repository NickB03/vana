
            try {
                const _ = require('lodash');
                console.log('Lodash loaded successfully');
            } catch (error) {
                console.error('ERROR:', error.message);
                process.exit(1);
            }
        